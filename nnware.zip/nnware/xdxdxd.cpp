#include "xdxdxd.h"
bool menu_open;