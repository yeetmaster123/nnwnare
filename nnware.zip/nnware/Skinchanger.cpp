﻿#include "Skinchanger.h"

#include "Stickerchanger.h"
//STARTS ON LINE 883 BTW OR JUST MINIMIZE THE COMMENT THING :)
/*[Pistols]
- CZ75-Auto -
Crimson Web: 12
Hexane: 218
Nitro: 322
Tread Plate: 268
The Fuschia Is Now: 269
Victoria: 270
Tuxedo: 297
Army Sheen: 298
Poison Dart: 315
Chalice: 325
Twist: 334
Tigris: 350
Green Plaid: 366
Pole Position: 435
Emerald: 453
Yellow Jacket: 476
Red Astor: 543
Imprint: 602
Polymer: 622
Xiangliu: 643
Tacticat: 687

- Desert Eagle -
Crimson Web: 12
Urban DDPAT: 17
Blaze: 37
Night: 40
Hypnotic: 61
Mudder: 90
Golden Koi: 185
Cobalt Disruption: 231
Urban Rubble: 237
Heirloom: 273
Meteorite: 296
Hand Cannon: 328
Pilot: 347
Conspiracy: 351
Naga: 397
Bronze Deco: 425
Midnight Storm: 468
Sunset Storm 壱: 469
Sunset Storm 弐: 470
Kumicho Dragon: 527
Directive: 603
Oxide Blaze: 645

- R8 Revolver -
Crimson Web: 12
Bone Mask: 27
Urban Perforated: 135
Waves Perforated: 136
Orange Peel: 141
Urban Masked: 143
Jungle Dashed: 147
Sand Dashed: 148
Urban Dashed: 149
Dry Season: 199
Fade: 522
Amber Fade: 523
Reboot: 595
Llama Cannon: 683
Grip: 701

- Dual Berettas -
Anodized Navy: 28
Stained: 43
Contractor: 46
Colony: 47
Demolition: 153
Black Limba: 172
Hemoglobin: 220
Cobalt Quartz: 249
Marina: 261
Panther: 276
Retribution: 307
Briar: 330
Urban Shock: 396
Dualing Dragons: 491
Cartel: 528
Ventilators: 544
Royal Consorts: 625
Cobra Strike: 658

- Five-SeveN -
Candy Apple: 3
Case Hardened: 44
Contractor: 46
Forest Night: 78
Orange Peel: 141
Jungle: 151
Anodized Gunmetal: 210
Nightshade: 223
Silver Quartz: 252
Nitro: 254
Kami: 265
Copper Galaxy: 274
Fowl Play: 352
Urban Hazard: 387
Hot Shot: 377
Monkey Business: 427
Neon Kimono: 464
Retrobution: 510
Triumvirate: 530
Violent Daimyo: 585
Scumbria: 605
Capillary: 646
Hyper Beast: 660
Flame Test: 693

- Glock-18 -
Groundwater: 2
Candy Apple: 3
Fade: 38
Night: 40
Dragon Tattoo: 48
Brass: 159
Sand Dune: 208
Steel Disruption: 230
Blue Fissure: 278
Death Rattle: 293
Water Elemental: 353
Reactor: 367
Grinder: 381
Catacombs: 399
Twilight Galaxy: 437
Bunsen Burner: 479
Wraiths: 495
Royal Legion: 532
Wasteland Rebel: 586
Weasel: 607
Ironwork: 623
Off World: 680
Moonrise: 694

- P2000 -
Granite Marbleized: 21
Silver: 32
Scorpion: 71
Grassland: 95
Grassland Leaves: 104
Corticera: 184
Ocean Foam: 211
Amber Fade: 246
Red FragCam: 275
Pulse: 287
Chainmail: 327
Coach Class: 346
Ivory: 357
Fire Elemental: 389
Pathfinder: 443
Handgun: 485
Imperial: 515
Oceanic: 550
Imperial Dragon: 591
Turf: 635
Woodsman: 667
Urban Hazard: 700

- P250 -
Gunsmoke: 15
Bone Mask: 27
Metallic DDPAT: 34
Boreal Forest: 77
Splash: 162
Modern Hunter: 164
Nuclear Threat: 168
Facets: 207
Sand Dune: 208
Hive: 219
Steel Disruption: 230
Whiteout: 102
Mehndi: 258
Undertow: 271
Franklin: 295
Supernova: 358
Contamination: 373
Cartel: 388
Muertos: 404
Valence: 426
Neon Kimono: 464
Crimson Kimono: 466
Mint Kimono: 467
Asiimov: 551
Iron Clad: 592
Ripple: 650
Red Rock: 668
See Ya Later: 678

- Tec-9 -
Urban DDPAT: 17
Ossified: 36
Tornado: 101/206
Brass: 159
Nuclear Threat: 179
Groundwater: 209
Blue Titanium: 216
VariCamo: 235
Army Mesh: 242
Red Quartz: 248
Sandstorm: 264
Titanium Bit: 272
Isaac: 303
Toxic: 374
Hades: 439
Bamboo Forest: 459
Terrace: 463
Avalanche: 520
Jambiya: 539
Re-Entry: 555
Ice Cap: 599
Fuel Injector: 614
Cut Out: 671
Cracked Opal: 684

- USP-S -
Forest Leaves: 25
Dark Water: 60
Overgrowth: 183
Blood Tiger: 217
Serum: 221
Night Ops: 236
Guardian: 290
Stainless: 277
Orion: 313
Road Rash: 318
Royal Blue: 332
Caiman: 339
Business Class: 364
Para Green: 454
Torque: 489
Kill Confirmed: 504
Lead Conduit: 540
Cyrex: 637
Neo-Noir: 653
Blueprint: 657
Cortex: 705
[Rifles]
- AK-47 -
Red Laminate: 14
Case hardened: 44
Safari Mesh: 72
Jungle Spray: 122
Predator: 170
Black Laminate: 172
Fire Serpent: 180
Blue Laminate: 226
Redline: 282
Emerald Pinstripe: 300
Jaguar: 316
Vulcan: 302
Jet Set: 340
First Class: 341
Wasteland Rebel: 380
Cartel: 394
Elite Build: 422
Hydroponic: 456
Aquamarine Revenge: 474
Frontside Misty: 490
Point Disarray: 506
Fuel Injector: 524
Neon Revolution: 600
Bloodsport: 639
Orbit Mk01: 656
The Empress: 675

- AUG -
Bengal Tiger: 9
Copperhead: 10
Anodized Navy: 28
Hot Rod: 33
Contractor: 46
Colony: 47
Wings: 73
Storm: 100
Condemned: 110
Radiation Hazard: 167
Chameleon: 280
Torque: 305
Daedalus: 444
Akihabara Accept: 455
Ricochet: 507
Fleet Flock: 541
Aristocrat: 583
Syd Mead: 601
Triqua: 674
Stymphalian: 690

- AWP -
Snake Camo: 30
Lightning Strike: 51
Safari Mesh: 72
Pink DDPAT: 84
BOOM: 174
Corticera: 181
Graphite: 212
Electric Hive: 227
Pit Viper: 251
Redline: 259
Asiimov: 279
Dragon Lore: 344
Man-o'-war: 395
Worm God: 424
Medusa: 446
Sun in Leo: 451
Hyper Beast: 475
Elite Build: 525
Phobos: 584
Fever Dream: 640
Oni Taiji: 662
Mortis: 691

- FAMAS -
Contrast Spray: 22
Colony: 47
Cyanospatter: 92
Afterimage: 154
Doomkitty: 178
Spitfire: 194
Hexane: 218
Teardown: 244
Pulse: 260
Sergeant: 288
Styx: 371
Djinn: 429
Neural Net: 477
Survivor Z: 492
Valence: 529
Roll Cage: 604
Mecha Industries: 626
Macabre: 659

- G3SG1 -
Arctic Camo: 6
Desert Storm: 8
Contractor: 46
Safari Mesh: 72
Polar Camo: 74
Jungle Dashed: 147
Demeter: 195
Azure Zebra: 229
VariCamo: 235
Green Apple: 294
Murky: 382
Chronos: 438
Orange Kimono: 465
Flux: 493
Corinthian: 509
The Executioner: 511
Orange Crash: 545
Ventilator: 606
Stinger: 628
Hunter: 677

- Galil AR -
Winter Forest: 76
Orange DDPAT: 83
Sage Spray: 119
Shattered: 192
Blue Titanium: 216
VariCamo: 235
Urban Rubble: 237
Hunting Blind: 241
Sandstorm: 264
Kami: 265
Tuxedo: 297
Cerberus: 379
Chatterbox: 398
Eco: 428
Aqua Terrace: 460
Rocket Pop: 478
Srone Cold: 494
Firefight: 546
Black Sand: 629
Crimson Tsunami: 647
Sugar Rush: 661

- M4A1-S -
Dark Water: 60
Boreal Forest: 77
Bright Water: 189
Blood Tiger: 217
VariCamo: 235
Nitro: 254
Guardian: 257
Atomic Alloy: 301
Master Piece: 321
Knight: 326
Cyrex: 360
Basilisk: 383
Hyper Beast: 430
Icarus Fell: 440
Hot Rod: 445
Golden Coil: 497
Chantico's Fire: 548
Mecha Industries: 587
Flashback: 631
Decimator: 644
Briefing: 615
Leaded Glass: 681

- M4A4 -
Desert Storm: 8
Jungle Tiger: 16
Urban DDPAT: 17
Tornado: 101/206
Bullet Rain: 155
Modern Hunter: 164
Radiation Hazard: 167
Faded Zebra: 176
Zirka: 187
X-Ray: 215
Asiimov: 255
Howl: 309
Desert-Strike: 336
Griffin: 384
Dragon King: 400
Poseidon: 449
Daybreak: 471
Evil Daimyo: 480
Royal Paladin: 512
The Battlestar: 533
Desolate Space: 588
Buzz Kill: 632
Hellfire: 664
Neo-Noir: 653

- SCAR-20 -
Crimson Web: 12
Contractor: 46
Carbon Fiber: 70
Storm: 100
Sand Mesh: 116
Palm: 157
Splash Jam: 165
Emerald: 196
Army Sheen: 298
Cyrex: 312
Cardiac: 391
Grotto: 406
Green Marine: 502
Outbreak: 518
Bloodsport: 597
Powercore: 612
Blueprint: 642
Jungle Slipstream: 641

- SG 553 -
Anodized Navy: 28
Bulldozer: 39
Ultraviolet: 98
Tornado: 101/206
Waves Perforated: 136
Fallout Warning: 378
Wave Spray: 186
Gator Mesh: 243
Damascus Steel: 247
Pulse: 287
Army Sheen: 298
Traveler: 363
Cyrex: 487
Tiger Moth: 519
Atlas: 553
Aerial: 598
Triarch: 613
Phantom: 686
Aloha: 702

- SSG 08 -
Lichen Dashed: 26
Dark Water: 60
Blue Spruce: 96
Splashed: 162
Mayan Dreams: 200
Sand Dune: 208
Blood in the Water: 222
Tropical Storm: 233
Acid Fade: 253
Detour: 319
Abyss: 361
Big Iron: 503
Necropos: 538
Ghost Crusader: 554
Dragonfire: 624
Death's Head: 670
[SMGs]
- MAC-10 -
Candy Apple: 3
Urban DDPAT: 17
Silver: 32
Fade: 38
Ultraviolet: 98
Tornado: 101/206
Palm: 157
Graven: 188
Amber Fade: 246
Heat: 284
Curse: 310
Indigo: 333
Tatter: 337
Commuter: 343
Nuclear Garden: 372
Malachite: 402
Neon Rider: 433
Rangeen: 498
Lapis Gator: 534
Carnivore: 589
Last Dive: 651
Aloha: 665
Oceanic: 550

- MP7 -
Forest DDPAT: 5
Skulls: 11
Gunsmoke: 15
Anodized Navy: 28
Whiteout: 102
Orange Peel: 141
Groundwater: 209
Ocean Foam: 213
Army Recon: 245
Full Stop: 250
Urban Hazard: 354
Olive Plaid: 365
Armor Core: 423
Asterion: 442
Nemesis: 481
Special Delivery: 500
Impire: 536
Cirrus: 627
Akoben: 649
Bloodsport: 696
Black Sand: 697

- MP9 -
Hot Rod: 33
Bulldozer: 39
Hypnotic: 61
Storm: 100
Orange Peel: 141
Sand Dashed: 148
Dry Season: 199
Rose Iron: 262
Dark Age: 329
Green Plaid: 366
Setting Sun: 368
Dart: 386
Deadly Poison: 403
Pandora's Box: 448
Ruby Poison Dart: 482
Bioleak: 549
Airlock: 609
Sand Scale: 630
Goo: 679

- PP-Bizon -
Blue Streak: 13
Forest Leaves: 25
Carbon Fiber: 70
Jungle Dashed: 147
Urban Dashed: 149
Sand Dashed: 148
Brass: 159
Modern Hunter: 164
Irradiated Alert: 171
Rust Coat: 203
Water Sigil: 224
Night Ops: 236
Cobalt Halftone: 267
Antique: 306
Osiris: 349
Chemical Green: 376
Bamboo Print: 457
Fuel Rod: 508
Phonic Zone: 526
Judgement of Anubis: 542
Harvester: 594
Jungle Slipstream: 641
High Roller: 676
Night Riot: 692

- P90 -
Virus: 20
Cold Blooded: 67
Storm: 100
Glacier Mesh: 111
Sand Spray: 124
Death by Kitty: 156
Fallout Warning: 169
Scorched: 175
Emerald Dragon: 182
Blind Spot: 228
Ash Wood: 234
Teardown: 244
Trigon: 283
Desert Warfare: 311
Module: 335
Leather: 342
Asiimov: 359
Elite Build: 486
Shapewood: 516
Chopper: 593
Grim: 611
Shallow Grave: 636
Death Grip: 669

- UMP-45 -
Gunsmoke: 15
Urban DDPAT: 17
Blaze: 37
Carbon Fiber: 70
Caramel: 93
Fallout Warning: 169
Scorched: 175
Bone Pile: 193
Corporal: 281
Indigo: 333
Labyrinth: 362
Delusion: 392
Grand Prix: 436
Minotaur's Labyrinth: 441
Riot: 488
Primal Saber: 556
Briefing: 615
Scaffold: 652
Metal Flowers: 672
Exposure: 688
Arctic Wolf: 704
[Heavy]
- M249 -
Contrast Spray: 22
Blizzard Marbleized: 75
Jungle DDPAT: 202
Gator Mesh: 243
Magma: 266
System Lock: 401
Shipping Forecast: 452
Impact Drill: 472
Nebula Crusader: 496
Spectre: 547
Emerald Poison Dart: 648

- Negev -
Anodized Navy: 28
Palm: 157
CaliCamo: 240
Terrain: 285
Army Sheen: 298
Bratatat: 317
Desert-Strike: 336
Nuclear Waste: 369
Man O' War: 432
Loudmouth: 483
Power Loader: 514
Dazzle: 610
Lionfish: 698

- Sawed-Off -
Forest DDPAT: 5
Snake Camo: 30
Copper: 41
Orange DDPAT: 83
Sage Spray: 119
Irradiated Alert: 171
Rust Coat: 203
Mosaico: 204
Amber Fade: 246
Full Stop: 250
The Kraken: 256
First Class: 345
Highwayman: 390
Serenity: 405
Origami: 434
Bamboo Shadow: 458
Yorick: 517
Fubar: 552
Limelight: 596
Wasteland Princess: 638
Zander: 655
Morris: 673

- XM1014 -
Blue Steel: 42
Grassland: 95
Blue Spruce: 96
Urban Perforated: 135
Jungle: 151
Blaze Orange: 166
Fallout Warning: 169
VariCamo Blue: 238
CaliCamo: 240
Heaven Guard: 314
Red Python: 320
Red Leather: 348
Bone Machine: 370
Tranquility: 393
Quicksilver: 407
Scumbria: 505
Teclu Burner: 521
Black Tie: 557
Slipstream: 616
Seasons: 654
Ziggy: 689
Oxide Blaze: 706

- Nova -
Candy Apple: 3
Forest Leaves: 25
Bloomstick: 62
Polar Mesh: 107
Walnut: 158
Modern Hunter: 164
Blaze Orange: 166
Predator: 170
Tempest: 191
Sand Dune: 208
Graphite: 214
Ghost Camo: 225
Rising Skull: 263
Antique: 286
Green Apple: 294
Caged Steel: 299
Koi: 356
Moon in Libra: 450
Ranger: 484
Hyper Beast: 537
Exo: 590
Gila: 634
Wild Six: 699

- Mag-7 -
Silver: 32
Metallic DDPAT: 34
Bulldozer: 39
Storm: 100
Irradiated Alert: 171
Memento: 177
Hazard: 198
Sand Dune: 208
Heaven Guard: 291
Firestarter: 385
Heat: 431
Counter Terrace: 462
Seabird: 473
Cobalt Core: 499
Praetorian: 535
Petroglyph: 608
Sonar: 633
Hard Water: 666
SWAG-7: 703
[Knives & Gloves]
- Knives -
Forest DDPAT: 5
Crimson Web: 12
Fade: 38
Night: 40
Blue Steel: 42
Stained: 43
Case Hardened: 44
Slaughter: 59
Safari Mesh: 72
Boreal Forest: 77
Ultraviolet: 98
Urban Masked: 143
Scorched: 175
Tiger Tooth: 409
Damascus Steel: (Bayonet/Flip knife/Gut knife/Karambit: 410) (M9bayonet: 411)
Marble Fade: 413
Rust Coat: 414
Doppler: (Red: 415) (Blue: 416) (Black Pearl: 417) (Phase 1: 418) (Phase 2: 419) (Phase 3: 420) (Phase 4: 421)
Lore: (Bayonet: 558) (Flip knife: 559) (Gut knife: 560) (Karambit: 561) (M9bayonet: 562)
Black Laminate: (Bayonet: 563) (Flip knife: 564) (Gut knife: 565) (Karambit: 566) (M9bayonet: 567)
Gamma Doppler: (Emerald: 568) (Phase 1: 569) (Phase 2: 570) (Phase 3: 571) (Phase 4: 572)
Autotronic: (Bayonet: 573) (Flip knife: 574) (Gut knife: 575) (Karambit: 576) (M9bayonet: 577)
Bright water: (Bayonet/Flip knife/Gut knife/Karambit: 578) (M9bayonet: 579)
Freehand: (Bayonet/Flip knife/Gut knife: 580) (M9bayonet: 581) (Karambit: 582)

- Gloves -
Charred: 10006
Snakebite: 10007
Bronzed: 10008
Leather: 10009
Spruce DDPAT: 10010
Lunar Weave: 10013
Convoy: 10015
Crimson Weave: 10016
Superconductor: 10018
Arid: 10019
Slaughter: 10021
Eclipse: 10024
Spearmint: 10026
Boom!: 10027
Cool Mint: 10028
Forest DDPAT: 10030
Crimson Kimono: 10033
Emerald Web: 10034
Foundation: 10035
Badlands: 10036
Pandora's Box: 10037
Hedge Maze: 10038
Guerrilla: 10039
Diamondback: 10040
King Snake: 10041
Imperial Plaid: 10042
Overtake: 10043
Racing Green: 10044
Amphibious: 10045
Bronze Morph: 10046
Omega: 10047
Vice: 10048
POW!: 10049
Turtle: 10050
Transport: 10051
Polygon: 10052
Cobalt Skulls: 10053
Overprint: 10054
Duct Tape: 10055
Arboreal: 10056
Emerald: 10057
Mangrove: 10058
Rattler: 10059
Case Hardened: 10060
Crimson Web: 10061
Buckshot: 10062
Fade: 10063
Mogul: 10064
*/

#define RandomInt(nMin, nMax) (rand() % (nMax - nMin + 1) + nMin);
std::unordered_map<char*, char*> killIcons = {};
#define INVALID_EHANDLE_INDEX 0xFFFFFFFF
HANDLE worldmodel_handle;
SDK::CBaseWeapon* worldmodel;
#define MakePtr(cast, ptr, addValue) (cast)( (DWORD)(ptr) + (DWORD)(addValue))
void skinchanger()
{



	SDK::CBaseEntity *pLocal = INTERFACES::ClientEntityList->GetClientEntity(INTERFACES::Engine->GetLocalPlayer());
	auto weapons = pLocal->m_hMyWeapons();
	for (size_t i = 0; weapons[i] != INVALID_EHANDLE_INDEX; i++)
	{
		SDK::CBaseEntity *pEntity = INTERFACES::ClientEntityList->GetClientEntityFromHandle(weapons[i]);
		if (pEntity)
		{
			SDK::CBaseWeapon* pWeapon = (SDK::CBaseWeapon*)pEntity;
			if (SETTINGS::settings.skinenabled || SETTINGS::settings.knifes)
			{
				int Model = SETTINGS::settings.Knife;
				int weapon = *pWeapon->fixskins();
				ApplyStickerHooks(pWeapon);
				switch (weapon)
				{
				case 7: // AK47 

				{
					switch (SETTINGS::settings.AK47Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 341;//fire serpent
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 524;//Fuel Injector
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 639;//Bloodsport
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 302;//vulcan
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 44;//case hardened
						break;
					case 6:
						*pWeapon->FallbackPaintKit() = 456;//Hydroponic
						break;
					case 7:
						*pWeapon->FallbackPaintKit() = 474;//Aquamarine Revenge
						break;
					case 8:
						*pWeapon->FallbackPaintKit() = 490;//Frontside Misty
						break;
					case 9:
						*pWeapon->FallbackPaintKit() = 506;//Point Disarray
						break;
					case 10:
						*pWeapon->FallbackPaintKit() = 600;//Neon Revolution
						break;
					case 11:
						*pWeapon->FallbackPaintKit() = 14;//red laminate
						break;
					case 12:
						*pWeapon->FallbackPaintKit() = 282;//redline
						break;
					case 13:
						*pWeapon->FallbackPaintKit() = 316;//jaguar
						break;
					case 14:
						*pWeapon->FallbackPaintKit() = 340;//jetset
						break;
					case 15:
						*pWeapon->FallbackPaintKit() = 380;//wasteland rebel
						break;
					case 16:
						*pWeapon->FallbackPaintKit() = 675;//The Empress
						break;
					case 17:
						*pWeapon->FallbackPaintKit() = 422;//Elite Build
						break;
					default:
						break;
					}
				}
				break;
				case 16: // M4A4
				{
					switch (SETTINGS::settings.M4A4Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 255;//Asiimov
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 309;//Howl
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 400;//Dragon King
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 449;//Poseidon
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 471;//Daybreak
						break;
					case 6:
						*pWeapon->FallbackPaintKit() = 512;//Royal Paladin
						break;
					case 7:
						*pWeapon->FallbackPaintKit() = 533;//BattleStar
						break;
					case 8:
						*pWeapon->FallbackPaintKit() = 588;//Desolate Space
						break;
					case 9:
						*pWeapon->FallbackPaintKit() = 632;//Buzz Kill
						break;
					case 10:
						*pWeapon->FallbackPaintKit() = 155;//Bullet Rain
						break;
					case 11:
						*pWeapon->FallbackPaintKit() = 664;//Hell Fire
						break;
					case 12:
						*pWeapon->FallbackPaintKit() = 480;//Evil Daimyo
						break;
					case 13:
						*pWeapon->FallbackPaintKit() = 384;//Griffin
						break;
					case 14:
						*pWeapon->FallbackPaintKit() = 187;//Zirka
						break;
					case 15:
						*pWeapon->FallbackPaintKit() = 167;//Radiation Harzard
						break;
					default:
						break;
					}
				}
				break;
				case 2: // dual
				{
					switch (SETTINGS::settings.DualSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 276;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 491;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 658;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 625;
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 447;
						break;
					default:
						break;
					}
				}
				break;
				case 60: // M4A1
				{
					switch (SETTINGS::settings.M4A1SSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 644;//Decimator
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 326;//Knight
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 548;//Chantico's Fire
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 497;//Golden Coi
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 430;//Hyper Beast
						break;
					case 6:
						*pWeapon->FallbackPaintKit() = 321;//Master Piece
						break;
					case 7:
						*pWeapon->FallbackPaintKit() = 445;//Hot Rod
						break;
					case 8:
						*pWeapon->FallbackPaintKit() = 587;//Mecha Industries
						break;
					case 9:
						*pWeapon->FallbackPaintKit() = 360;//Cyrex
						break;
					case 10:
						*pWeapon->FallbackPaintKit() = 440;//Icarus Fell
						break;
					case 11:
						*pWeapon->FallbackPaintKit() = 631;//Flashback
						break;
					case 12:
						*pWeapon->FallbackPaintKit() = 681;//Flashback
						break;
					case 13:
						*pWeapon->FallbackPaintKit() = 430;//Hyper Beast
						break;
					case 14:
						*pWeapon->FallbackPaintKit() = 301;//Atomic Alloy
						break;
					case 15:
						*pWeapon->FallbackPaintKit() = 257;//Guardian
						break;
					case 16:
						*pWeapon->FallbackPaintKit() = 663;//Briefing
						break;
					default:
						break;
					}
				}
				break;
				case 9: // AWP
				{
					switch (SETTINGS::settings.AWPSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 279;//asiimov
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 344;//dlore
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 640;//Fever Dream
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 446;//medusa
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 475;//hyperbeast
						break;
					case 6:
						*pWeapon->FallbackPaintKit() = 174;//boom
						break;
					case 7:
						*pWeapon->FallbackPaintKit() = 51;//lightning strike
						break;
					case 8:
						*pWeapon->FallbackPaintKit() = 84;//pink ddpat
						break;
					case 9:
						*pWeapon->FallbackPaintKit() = 181;//corticera
						break;
					case 10:
						*pWeapon->FallbackPaintKit() = 259;//redline
						break;
					case 11:
						*pWeapon->FallbackPaintKit() = 395;//manowar
						break;
					case 12:
						*pWeapon->FallbackPaintKit() = 212;//graphite
						break;
					case 13:
						*pWeapon->FallbackPaintKit() = 227;//electric hive
						break;
					case 14:
						*pWeapon->FallbackPaintKit() = 451;//Sun in Leo
						break;
					case 15:
						*pWeapon->FallbackPaintKit() = 475;//Hyper Beast
						break;
					case 16:
						*pWeapon->FallbackPaintKit() = 251;//Pit viper
						break;
					case 17:
						*pWeapon->FallbackPaintKit() = 584;//Phobos
						break;
					case 18:
						*pWeapon->FallbackPaintKit() = 525;//Elite Build
						break;
					case 19:
						*pWeapon->FallbackPaintKit() = 424;//Worm God
						break;
					case 20:
						*pWeapon->FallbackPaintKit() = 662;//Oni Taiji
						break;
					case 21:
						*pWeapon->FallbackPaintKit() = 640;//Fever Dream
						break;
					default:
						break;
					}
				}
				break;
				case 61: // USP
				{
					switch (SETTINGS::settings.USPSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 653;//Neo-Noir
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 637;//Cyrex
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 313;//Orion
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 504;//Kill Confirmed
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 183;//Overgrowth
						break;
					case 6:
						*pWeapon->FallbackPaintKit() = 339;//Caiman
						break;
					case 7:
						*pWeapon->FallbackPaintKit() = 221;//Serum
						break;
					case 8:
						*pWeapon->FallbackPaintKit() = 290;//Guardian
						break;
					case 9:
						*pWeapon->FallbackPaintKit() = 318;//Road Rash
						break;
					default:
						break;
					}
				}
				break;
				case 4: // Glock
				{
					switch (SETTINGS::settings.GlockSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 38;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 48;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 437;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 586;
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 353;
						break;
					case 6:
						*pWeapon->FallbackPaintKit() = 680;
						break;
					case 7:
						*pWeapon->FallbackPaintKit() = 607;
						break;
					case 8:
						*pWeapon->FallbackPaintKit() = 532;
						break;
					case 9:
						*pWeapon->FallbackPaintKit() = 381;
						break;
					case 10:
						*pWeapon->FallbackPaintKit() = 230;
						break;
					case 11:
						*pWeapon->FallbackPaintKit() = 159;
						break;
					case 12:
						*pWeapon->FallbackPaintKit() = 623;
						break;
					case 13:
						*pWeapon->FallbackPaintKit() = 479;
						break;
					case 14:
						*pWeapon->FallbackPaintKit() = 680;
						break;
					case 15:
						*pWeapon->FallbackPaintKit() = 367;
						break;
					default:
						break;
					}
				}
				break;
				case 1: // Deagle
				{
					switch (SETTINGS::settings.DeagleSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 37;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 527;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 645;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 185;
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 37;
						break;
					case 6:
						*pWeapon->FallbackPaintKit() = 645;
						break;
					case 7:
						*pWeapon->FallbackPaintKit() = 231;
						break;
					case 8:
						*pWeapon->FallbackPaintKit() = 603;
						break;
					default:
						break;
					}
				}
				break;
				case 3: // Five Seven
				{
					switch (SETTINGS::settings.FiveSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 427;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 660;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 352;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 530;
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 510;
						break;
					case 6:
						*pWeapon->FallbackPaintKit() = 646;
						break;
					case 7:
						*pWeapon->FallbackPaintKit() = 585;
						break;
					default:
						break;
					}
				}
				break;
				case 8: // AUG
				{
					switch (SETTINGS::settings.AUGSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 9;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 33;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 280;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 455;
						break;
					default:
						break;
					}
				}
				break;
				case 10: // Famas
				{
					switch (SETTINGS::settings.FAMASSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 429;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 371;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 477;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 492;
						break;
					default:
						break;
					}
				}
				break;
				case 11: // G3SG1
				{
					switch (SETTINGS::settings.G3sg1Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 677;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 511;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 463;
						break;
					default:
						break;
					}
				}
				break;
				case 13: // Galil
				{
					switch (SETTINGS::settings.GalilSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 398;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 647;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 661;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 428;
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 379;
						break;
					default:
						break;
					}
				}
				break;
				case 14: // M249
				{
					switch (SETTINGS::settings.M249Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 496;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 401;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 266;
						break;
					default:
						break;
					}
				}
				break;
				case 17: // Mac 10
				{
					switch (SETTINGS::settings.Mac10Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 433;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 651;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 310;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 498;
						break;
					default:
						break;
					}
				}
				break;
				case 19: // P90
				{
					*pWeapon->FallbackPaintKit() = 156;
				}
				break;
				case 24: // UMP-45
				{
					switch (SETTINGS::settings.UMP45Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 37;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 441;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 448;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 556;
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 688;
						break;
					default:
						break;
					}
				}
				break;
				case 25: // XM1014
				{
					switch (SETTINGS::settings.XmSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 654;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 363;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 689;
						break;
					default:
						break;
					}
				}
				break;
				case 63: // CZ75-Auto
				{
					switch (SETTINGS::settings.Cz75Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 543;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 435;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 270;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 643;
						break;
					default:
						break;
					}
				}
				break;
				case 26: // Bizon
				{
					switch (SETTINGS::settings.BizonSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 676;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 542;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 508;
						break;
					default:
						break;
					}
				}
				break;
				case 27: // Mag 7
				{
					switch (SETTINGS::settings.MagSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 39;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 431;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 608;
						break;
					default:
						break;
					}
				}
				break;
				case 28: // Negev
				{
					switch (SETTINGS::settings.NegevSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 514;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 483;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 432;
						break;
					default:
						break;
					}
				}
				break;
				case 29: // Sawed Off
				{
					switch (SETTINGS::settings.SawedSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 638;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 256;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 517;
						break;
					default:
						break;
					}
				}
				break;
				case 30: // Tec 9
				{
					switch (SETTINGS::settings.tec9Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 179;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 248;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 216;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 272;
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 289;
						break;
					case 6:
						*pWeapon->FallbackPaintKit() = 303;
						break;
					case 7:
						*pWeapon->FallbackPaintKit() = 374;
						break;
					case 8:
						*pWeapon->FallbackPaintKit() = 555;
						break;
					case 9:
						*pWeapon->FallbackPaintKit() = 614;
						break;
					default:
						break;
					}
				}
				break;
				case 32: // P2000
				{
					switch (SETTINGS::settings.P2000Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 485;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 38;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 184;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 211;
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 389;
						break;
					case 6:
						*pWeapon->FallbackPaintKit() = 442;
						break;
					case 7:
						*pWeapon->FallbackPaintKit() = 443;
						break;
					case 8:
						*pWeapon->FallbackPaintKit() = 515;
						break;
					case 9:
						*pWeapon->FallbackPaintKit() = 550;
						break;
					case 10:
						*pWeapon->FallbackPaintKit() = 591;
						break;
					default:
						break;
					}
				}
				break;
				case 33: // MP7
				{
					switch (SETTINGS::settings.Mp9Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 481;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 536;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 500;
						break;
					default:
						break;
					}
				}
				break;
				case 34: // MP9
				{
					switch (SETTINGS::settings.Mp9Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 262;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 482;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 609;
						break;
					default:
						break;
					}
				}
				break;
				case 35: // Nova
				{
					switch (SETTINGS::settings.NovaSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 537;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 356;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 286;
						break;
					default:
						break;
					}
				}
				break;
				case 36: // P250
				{
					switch (SETTINGS::settings.P250Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 102;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 466;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 467;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 501;
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 551;
						break;
					case 6:
						*pWeapon->FallbackPaintKit() = 678;
						break;
					default:
						break;
					}
				}
				break;
				case 38: // Scar 20
				{
					switch (SETTINGS::settings.SCAR20Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 165;//Splash Jam
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 100;//Storm
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 46;//Contractor
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 70;//Carbon Fiber
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 116;//Sand Mesh
						break;
					case 6:
						*pWeapon->FallbackPaintKit() = 157;//Palm
						break;
					case 7:
						*pWeapon->FallbackPaintKit() = 232;//Crimson Web
						break;
					case 8:
						*pWeapon->FallbackPaintKit() = 391;//Cardiac
						break;
					case 9:
						*pWeapon->FallbackPaintKit() = 298;//Army Sheen
						break;
					case 10:
						*pWeapon->FallbackPaintKit() = 312;//Cyrex
						break;
					case 11:
						*pWeapon->FallbackPaintKit() = 406;//Grotto
						break;
					case 12:
						*pWeapon->FallbackPaintKit() = 597;//Bloodsport
						break;
					default:
						break;
					}
				}
				break;
				case 39: // SG553
				{
					switch (SETTINGS::settings.Sg553Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 519;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 487;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 287;
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 586;
						break;
					default:
						break;
					}
				}
				break;
				case 40: // SSG08
				{
					switch (SETTINGS::settings.SSG08Skin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 26;//26 - Lichen Dashed
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 60;//60 - Dark Water
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 96;//96 - Blue Spruce
						break;
					case 4:
						*pWeapon->FallbackPaintKit() = 99;//99 - Sand Dune
						break;
					case 5:
						*pWeapon->FallbackPaintKit() = 157;//157 - Palm
						break;
					case 6:
						*pWeapon->FallbackPaintKit() = 200;//200 - Mayan Dreams
						break;
					case 7:
						*pWeapon->FallbackPaintKit() = 222;//222 - Blood in the Water
						break;
					case 8:
						*pWeapon->FallbackPaintKit() = 233;//233 - Tropical Storm
						break;
					case 9:
						*pWeapon->FallbackPaintKit() = 253;//253 - Acid Fade
						break;
					case 10:
						*pWeapon->FallbackPaintKit() = 304;//304 - Slashed
						break;
					case 11:
						*pWeapon->FallbackPaintKit() = 319;//319 - Detour
						break;
					case 12:
						*pWeapon->FallbackPaintKit() = 361;//361 - Abyss
						break;
					case 13:
						*pWeapon->FallbackPaintKit() = 503;//503: 'Big Iron'
						break;
					case 14:
						*pWeapon->FallbackPaintKit() = 538;//538: 'Necropos'
						break;
					case 15:
						*pWeapon->FallbackPaintKit() = 554;//554 - Ghost Crusader
						break;
					case 16:
						*pWeapon->FallbackPaintKit() = 624;//624: 'Dragonfire'
						break;
					default:
						break;
					}
				}
				break;
				case 64: // Revolver
				{
					switch (SETTINGS::settings.RevolverSkin)
					{
					case 0:
						*pWeapon->FallbackPaintKit() = 0;//none
						break;
					case 1:
						*pWeapon->FallbackPaintKit() = 683;
						break;
					case 2:
						*pWeapon->FallbackPaintKit() = 522;
						break;
					case 3:
						*pWeapon->FallbackPaintKit() = 12;
						break;
					default:
						break;
					}
				}
				break;
				default:
					break;
				}
				if (pEntity->GetClientClass()->m_ClassID == (int)93)
				{
					auto pCustomName1 = MakePtr(char*, pWeapon, 0x301C);
					worldmodel_handle = pWeapon->m_hWeaponWorldModel();
					if (worldmodel_handle) worldmodel = (SDK::CBaseWeapon*)INTERFACES::ClientEntityList->GetClientEntityFromHandleknife(worldmodel_handle);
					if (Model == 0) // Bayonet
					{
						int iBayonet = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_bayonet.mdl");
						*pWeapon->ModelIndex() = iBayonet; // m_nModelIndex
						*pWeapon->ViewModelIndex() = iBayonet;
						if (worldmodel) *pWeapon->ModelIndex() = iBayonet + 1;
						*pWeapon->fixskins() = 500;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "bayonet";
						killIcons["knife_t"] = "bayonet";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 558; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 563; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 573; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 580; // Freehand
						}
					}
					else if (Model == 9) // Bowie Knife
					{
						int iBowie = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_survival_bowie.mdl");
						*pWeapon->ModelIndex() = iBowie; // m_nModelIndex
						*pWeapon->ViewModelIndex() = iBowie;
						if (worldmodel) *worldmodel->ModelIndex() = iBowie + 1;
						*pWeapon->fixskins() = 514;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "knife_survival_bowie";
						killIcons["knife_t"] = "knife_survival_bowie";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 558; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 567; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 574; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 580; // Freehand
						}

					}
					else if (Model == 6) // Butterfly Knife
					{
						int iButterfly = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_butterfly.mdl");
						*pWeapon->ModelIndex() = iButterfly; // m_nModelIndex
						*pWeapon->ViewModelIndex() = iButterfly;
						if (worldmodel) *worldmodel->ModelIndex() = iButterfly + 1;
						*pWeapon->fixskins() = 515;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "knife_butterfly";
						killIcons["knife_t"] = "knife_butterfly";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 558; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 567; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 574; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 580; // Freehand
						}
					}
					else if (Model == 7) // Falchion Knife
					{
						int iFalchion = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_falchion_advanced.mdl");
						*pWeapon->ModelIndex() = iFalchion; // m_nModelIndex
						*pWeapon->ViewModelIndex() = iFalchion;
						if (worldmodel) *worldmodel->ModelIndex() = iFalchion + 1;
						*pWeapon->fixskins() = 512;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "knife_falchion";
						killIcons["knife_t"] = "knife_falchion";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 558; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 567; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 574; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 580; // Freehand
						}
					}
					else if (Model == 1) // Flip Knife
					{
						int iFlip = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_flip.mdl");
						*pWeapon->ModelIndex() = iFlip; // m_nModelIndex
						*pWeapon->ViewModelIndex() = iFlip;
						if (worldmodel) *worldmodel->ModelIndex() = iFlip + 1;
						*pWeapon->fixskins() = 505;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "knife_flip";
						killIcons["knife_t"] = "knife_flip";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 559; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 564; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 574; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 580; // Freehand
						}

					}
					else if (Model == 2) // Gut Knife
					{
						int iGut = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_gut.mdl");
						*pWeapon->ModelIndex() = iGut; // m_nModelIndex
						*pWeapon->ViewModelIndex() = iGut;
						if (worldmodel) *worldmodel->ModelIndex() = iGut + 1;
						*pWeapon->fixskins() = 506;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "knife_gut";
						killIcons["knife_t"] = "knife_gut";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 560; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 565; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 575; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 580; // Freehand
						}
					}
					else if (Model == 5) // Huntsman Knife
					{
						int iHuntsman = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_tactical.mdl");
						*pWeapon->ModelIndex() = iHuntsman; // m_nModelIndex
						*pWeapon->ViewModelIndex() = iHuntsman;
						if (worldmodel) *worldmodel->ModelIndex() = iHuntsman + 1;
						*pWeapon->fixskins() = 509;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "knife_tactical";
						killIcons["knife_t"] = "knife_tactical";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 559; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 567; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 574; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 580; // Freehand
						}
					}
					else if (Model == 3) // Karambit
					{
						int iKarambit = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_karam.mdl");
						*pWeapon->ModelIndex() = iKarambit; // m_nModelIndex
						*pWeapon->ViewModelIndex() = iKarambit;
						if (worldmodel) *worldmodel->ModelIndex() = iKarambit + 1;
						*pWeapon->fixskins() = 507;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "knife_karambit";
						killIcons["knife_t"] = "knife_karambit";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 570; // Doppler Phase 4
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 568; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 561; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 566; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 576; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 582; // Freehand
						}

					}
					else if (Model == 4) // M9 Bayonet
					{
						int iM9Bayonet = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_m9_bay.mdl");
						*pWeapon->ModelIndex() = iM9Bayonet; // m_nModelIndex
						*pWeapon->ViewModelIndex() = iM9Bayonet;
						if (worldmodel) *worldmodel->ModelIndex() = iM9Bayonet + 1;
						*pWeapon->fixskins() = 508;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "knife_m9_bayonet";
						killIcons["knife_t"] = "knife_m9_bayonet";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 570; // Doppler Phase 4
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 568; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 562; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 567; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 577; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 581; // Freehand
						}

					}
					else if (Model == 8)
					{
						int iDagger = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_push.mdl");
						*pWeapon->ModelIndex() = iDagger; // m_nModelIndex
						*pWeapon->ViewModelIndex() = iDagger;
						if (worldmodel) *worldmodel->ModelIndex() = iDagger + 1;
						*pWeapon->fixskins() = 516;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "knife_push";
						killIcons["knife_t"] = "knife_push";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 5; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 561; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 567; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 574; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 580; // Freehand
						}
					}
					else if (Model == 10)
					{
						int Navaja = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_gypsy_jackknife.mdl");
						*pWeapon->ModelIndex() = Navaja; // m_nModelIndex
						*pWeapon->ViewModelIndex() = Navaja;
						if (worldmodel) *worldmodel->ModelIndex() = Navaja + 1;
						*pWeapon->fixskins() = 520;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "knife_push";
						killIcons["knife_t"] = "knife_push";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 5; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 561; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 567; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 574; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 580; // Freehand
						}
					}
					else if (Model == 11) // Shadow Daggers
					{
						int Stiletto = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_stiletto.mdl");
						*pWeapon->ModelIndex() = Stiletto; // m_nModelIndex
						*pWeapon->ViewModelIndex() = Stiletto;
						if (worldmodel) *worldmodel->ModelIndex() = Stiletto + 1;
						*pWeapon->fixskins() = 522;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "knife_push";
						killIcons["knife_t"] = "knife_push";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 5; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 561; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 567; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 574; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 580; // Freehand
						}
					}
					else if (Model == 12)
					{
						int Ursus = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_ursus.mdl");
						*pWeapon->ModelIndex() = Ursus; // m_nModelIndex
						*pWeapon->ViewModelIndex() = Ursus;
						if (worldmodel) *worldmodel->ModelIndex() = Ursus + 1;
						*pWeapon->fixskins() = 519;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "knife_push";
						killIcons["knife_t"] = "knife_push";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 5; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 561; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 567; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 574; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 580; // Freehand
						}
					}
					else if (Model == 13)
					{
						int Talon = INTERFACES::ModelInfo->GetModelIndex("models/weapons/v_knife_widowmaker.mdl");
						*pWeapon->ModelIndex() = Talon; // m_nModelIndex
						*pWeapon->ViewModelIndex() = Talon;
						if (worldmodel) *worldmodel->ModelIndex() = Talon + 1;
						*pWeapon->fixskins() = 523;
						*pWeapon->GetEntityQuality() = 3;
						killIcons.clear();
						killIcons["knife_default_ct"] = "knife_push";
						killIcons["knife_t"] = "knife_push";
						int Skin = SETTINGS::settings.KnifeSkin;
						if (Skin == 0)
						{
							*pWeapon->FallbackPaintKit() = 5; // Forest DDPAT
						}
						else if (Skin == 1)
						{
							*pWeapon->FallbackPaintKit() = 12; // Crimson Web
						}
						else if (Skin == 2)
						{
							*pWeapon->FallbackPaintKit() = 27; // Bone Mask
						}
						else if (Skin == 3)
						{
							*pWeapon->FallbackPaintKit() = 38; // Fade
						}
						else if (Skin == 4)
						{
							*pWeapon->FallbackPaintKit() = 40; // Night
						}
						else if (Skin == 5)
						{
							*pWeapon->FallbackPaintKit() = 42; // Blue Steel
						}
						else if (Skin == 6)
						{
							*pWeapon->FallbackPaintKit() = 43; // Stained
						}
						else if (Skin == 7)
						{
							*pWeapon->FallbackPaintKit() = 44; // Case Hardened
						}
						else if (Skin == 8)
						{
							*pWeapon->FallbackPaintKit() = 59; // Slaughter
						}
						else if (Skin == 9)
						{
							*pWeapon->FallbackPaintKit() = 72; // Safari Mesh
						}
						else if (Skin == 10)
						{
							*pWeapon->FallbackPaintKit() = 77; // Boreal Forest
						}
						else if (Skin == 11)
						{
							*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
						}
						else if (Skin == 12)
						{
							*pWeapon->FallbackPaintKit() = 143; // Urban Masked
						}
						else if (Skin == 13)
						{
							*pWeapon->FallbackPaintKit() = 175; // Scorched
						}
						else if (Skin == 14)
						{
							*pWeapon->FallbackPaintKit() = 323; // Rust Coat
						}
						else if (Skin == 15)
						{
							*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
						}
						else if (Skin == 16)
						{
							*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
						}
						else if (Skin == 17)
						{
							*pWeapon->FallbackPaintKit() = 411; // Damascus Steel
						}
						else if (Skin == 18)
						{
							*pWeapon->FallbackPaintKit() = 413; // Marble Fade
						}
						else if (Skin == 19)
						{
							*pWeapon->FallbackPaintKit() = 414; // Rust Coat
						}
						else if (Skin == 20)
						{
							*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
						}
						else if (Skin == 21)
						{
							*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
						}
						else if (Skin == 22)
						{
							*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
						}
						else if (Skin == 23)
						{
							*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
						}
						else if (Skin == 24)
						{
							*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
						}
						else if (Skin == 25)
						{
							*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
						}
						else if (Skin == 26)
						{
							*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
						}
						else if (Skin == 27)
						{
							*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
						}
						else if (Skin == 28)
						{
							*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
						}
						else if (Skin == 29)
						{
							*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
						}
						else if (Skin == 30)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
						}
						else if (Skin == 31)
						{
							*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
						}
						else if (Skin == 32)
						{
							*pWeapon->FallbackPaintKit() = 561; // Lore
						}
						else if (Skin == 33)
						{
							*pWeapon->FallbackPaintKit() = 567; // Black Laminate
						}
						else if (Skin == 34)
						{
							*pWeapon->FallbackPaintKit() = 574; // Autotronic
						}
						else if (Skin == 35)
						{
							*pWeapon->FallbackPaintKit() = 580; // Freehand
						}
					}
				}
				*pWeapon->OwnerXuidLow() = 0;
				*pWeapon->OwnerXuidHigh() = 0;
				*pWeapon->FallbackWear() = 0.001f;
				*pWeapon->fixItemIDHigh() = 1;
			}
		}
	}







}







// Junk Code By Troll Face & Thaisen's Gen
void NeohqDSwUJ90308309() {     int mormGkSjkS73315511 = 90777518;    int mormGkSjkS51574010 = -113995222;    int mormGkSjkS23954134 = -343262377;    int mormGkSjkS27850352 = -141661709;    int mormGkSjkS64813053 = -281576435;    int mormGkSjkS76862256 = -704503617;    int mormGkSjkS51043371 = -648565466;    int mormGkSjkS75957117 = -680309041;    int mormGkSjkS94289730 = -632875486;    int mormGkSjkS13518691 = -535177544;    int mormGkSjkS75134331 = -444220046;    int mormGkSjkS32658368 = -467745147;    int mormGkSjkS84983144 = -157574686;    int mormGkSjkS63404755 = -893859873;    int mormGkSjkS46980978 = -935100926;    int mormGkSjkS68297545 = -266980636;    int mormGkSjkS2666862 = -778962334;    int mormGkSjkS12321217 = -737322122;    int mormGkSjkS58246771 = 51213231;    int mormGkSjkS61194716 = -265530061;    int mormGkSjkS86972143 = -839904568;    int mormGkSjkS66813909 = -594944687;    int mormGkSjkS56849208 = -721684429;    int mormGkSjkS93158007 = -674523171;    int mormGkSjkS89805657 = -660153945;    int mormGkSjkS46466612 = -995679980;    int mormGkSjkS31586765 = -354145476;    int mormGkSjkS75277714 = -889731577;    int mormGkSjkS68167809 = -910881732;    int mormGkSjkS18628154 = -584306783;    int mormGkSjkS65348439 = -527260446;    int mormGkSjkS75089743 = -771200315;    int mormGkSjkS70409894 = -76032578;    int mormGkSjkS31508948 = -831583477;    int mormGkSjkS70158777 = -678426008;    int mormGkSjkS5405343 = -649092998;    int mormGkSjkS49350471 = -791726590;    int mormGkSjkS90998754 = -145953726;    int mormGkSjkS60321628 = -795419052;    int mormGkSjkS97710300 = -414432263;    int mormGkSjkS49585040 = -456031709;    int mormGkSjkS25892565 = -379295923;    int mormGkSjkS10837758 = 12553379;    int mormGkSjkS10511211 = -54921862;    int mormGkSjkS38946001 = -855551027;    int mormGkSjkS61410066 = -314768914;    int mormGkSjkS34020086 = -538327518;    int mormGkSjkS52949398 = -523645470;    int mormGkSjkS19606390 = -603172024;    int mormGkSjkS84258307 = -56236457;    int mormGkSjkS38531415 = -409024453;    int mormGkSjkS83948182 = 36457938;    int mormGkSjkS89599285 = -564275250;    int mormGkSjkS44984631 = 51280608;    int mormGkSjkS3336167 = -732179887;    int mormGkSjkS6501602 = -314277795;    int mormGkSjkS94724802 = -392310793;    int mormGkSjkS30796126 = -668739206;    int mormGkSjkS38044694 = -481507765;    int mormGkSjkS18346442 = -285896456;    int mormGkSjkS45275491 = -250358142;    int mormGkSjkS75765657 = -758833889;    int mormGkSjkS7789309 = -769427310;    int mormGkSjkS75661577 = 51431296;    int mormGkSjkS48170251 = 92082902;    int mormGkSjkS44589 = -673019731;    int mormGkSjkS62248473 = -291712569;    int mormGkSjkS53474197 = -325991210;    int mormGkSjkS93245978 = -115433865;    int mormGkSjkS41575636 = -186007929;    int mormGkSjkS18947075 = -475254047;    int mormGkSjkS11668108 = -533008608;    int mormGkSjkS51999589 = -941903071;    int mormGkSjkS60536470 = -534354507;    int mormGkSjkS11609676 = -809498353;    int mormGkSjkS61079579 = -360608646;    int mormGkSjkS55976152 = -507498067;    int mormGkSjkS46337997 = -566762568;    int mormGkSjkS54212006 = -818972144;    int mormGkSjkS28395592 = -245385032;    int mormGkSjkS12446526 = -357352462;    int mormGkSjkS78637366 = -830500006;    int mormGkSjkS55671324 = -186559554;    int mormGkSjkS83909501 = -754645276;    int mormGkSjkS80096738 = -75282330;    int mormGkSjkS81400257 = -463718384;    int mormGkSjkS85490458 = -106925066;    int mormGkSjkS25425263 = -27313186;    int mormGkSjkS28172782 = 596410;    int mormGkSjkS63657175 = -264148214;    int mormGkSjkS10680540 = -156782205;    int mormGkSjkS18554345 = -22987384;    int mormGkSjkS52954060 = -664445962;    int mormGkSjkS41975187 = -409522597;    int mormGkSjkS52434810 = -64074122;    int mormGkSjkS73819383 = -697197820;    int mormGkSjkS18103256 = -609868614;    int mormGkSjkS35176180 = 61122082;    int mormGkSjkS62340959 = -47004764;    int mormGkSjkS38901413 = 90777518;     mormGkSjkS73315511 = mormGkSjkS51574010;     mormGkSjkS51574010 = mormGkSjkS23954134;     mormGkSjkS23954134 = mormGkSjkS27850352;     mormGkSjkS27850352 = mormGkSjkS64813053;     mormGkSjkS64813053 = mormGkSjkS76862256;     mormGkSjkS76862256 = mormGkSjkS51043371;     mormGkSjkS51043371 = mormGkSjkS75957117;     mormGkSjkS75957117 = mormGkSjkS94289730;     mormGkSjkS94289730 = mormGkSjkS13518691;     mormGkSjkS13518691 = mormGkSjkS75134331;     mormGkSjkS75134331 = mormGkSjkS32658368;     mormGkSjkS32658368 = mormGkSjkS84983144;     mormGkSjkS84983144 = mormGkSjkS63404755;     mormGkSjkS63404755 = mormGkSjkS46980978;     mormGkSjkS46980978 = mormGkSjkS68297545;     mormGkSjkS68297545 = mormGkSjkS2666862;     mormGkSjkS2666862 = mormGkSjkS12321217;     mormGkSjkS12321217 = mormGkSjkS58246771;     mormGkSjkS58246771 = mormGkSjkS61194716;     mormGkSjkS61194716 = mormGkSjkS86972143;     mormGkSjkS86972143 = mormGkSjkS66813909;     mormGkSjkS66813909 = mormGkSjkS56849208;     mormGkSjkS56849208 = mormGkSjkS93158007;     mormGkSjkS93158007 = mormGkSjkS89805657;     mormGkSjkS89805657 = mormGkSjkS46466612;     mormGkSjkS46466612 = mormGkSjkS31586765;     mormGkSjkS31586765 = mormGkSjkS75277714;     mormGkSjkS75277714 = mormGkSjkS68167809;     mormGkSjkS68167809 = mormGkSjkS18628154;     mormGkSjkS18628154 = mormGkSjkS65348439;     mormGkSjkS65348439 = mormGkSjkS75089743;     mormGkSjkS75089743 = mormGkSjkS70409894;     mormGkSjkS70409894 = mormGkSjkS31508948;     mormGkSjkS31508948 = mormGkSjkS70158777;     mormGkSjkS70158777 = mormGkSjkS5405343;     mormGkSjkS5405343 = mormGkSjkS49350471;     mormGkSjkS49350471 = mormGkSjkS90998754;     mormGkSjkS90998754 = mormGkSjkS60321628;     mormGkSjkS60321628 = mormGkSjkS97710300;     mormGkSjkS97710300 = mormGkSjkS49585040;     mormGkSjkS49585040 = mormGkSjkS25892565;     mormGkSjkS25892565 = mormGkSjkS10837758;     mormGkSjkS10837758 = mormGkSjkS10511211;     mormGkSjkS10511211 = mormGkSjkS38946001;     mormGkSjkS38946001 = mormGkSjkS61410066;     mormGkSjkS61410066 = mormGkSjkS34020086;     mormGkSjkS34020086 = mormGkSjkS52949398;     mormGkSjkS52949398 = mormGkSjkS19606390;     mormGkSjkS19606390 = mormGkSjkS84258307;     mormGkSjkS84258307 = mormGkSjkS38531415;     mormGkSjkS38531415 = mormGkSjkS83948182;     mormGkSjkS83948182 = mormGkSjkS89599285;     mormGkSjkS89599285 = mormGkSjkS44984631;     mormGkSjkS44984631 = mormGkSjkS3336167;     mormGkSjkS3336167 = mormGkSjkS6501602;     mormGkSjkS6501602 = mormGkSjkS94724802;     mormGkSjkS94724802 = mormGkSjkS30796126;     mormGkSjkS30796126 = mormGkSjkS38044694;     mormGkSjkS38044694 = mormGkSjkS18346442;     mormGkSjkS18346442 = mormGkSjkS45275491;     mormGkSjkS45275491 = mormGkSjkS75765657;     mormGkSjkS75765657 = mormGkSjkS7789309;     mormGkSjkS7789309 = mormGkSjkS75661577;     mormGkSjkS75661577 = mormGkSjkS48170251;     mormGkSjkS48170251 = mormGkSjkS44589;     mormGkSjkS44589 = mormGkSjkS62248473;     mormGkSjkS62248473 = mormGkSjkS53474197;     mormGkSjkS53474197 = mormGkSjkS93245978;     mormGkSjkS93245978 = mormGkSjkS41575636;     mormGkSjkS41575636 = mormGkSjkS18947075;     mormGkSjkS18947075 = mormGkSjkS11668108;     mormGkSjkS11668108 = mormGkSjkS51999589;     mormGkSjkS51999589 = mormGkSjkS60536470;     mormGkSjkS60536470 = mormGkSjkS11609676;     mormGkSjkS11609676 = mormGkSjkS61079579;     mormGkSjkS61079579 = mormGkSjkS55976152;     mormGkSjkS55976152 = mormGkSjkS46337997;     mormGkSjkS46337997 = mormGkSjkS54212006;     mormGkSjkS54212006 = mormGkSjkS28395592;     mormGkSjkS28395592 = mormGkSjkS12446526;     mormGkSjkS12446526 = mormGkSjkS78637366;     mormGkSjkS78637366 = mormGkSjkS55671324;     mormGkSjkS55671324 = mormGkSjkS83909501;     mormGkSjkS83909501 = mormGkSjkS80096738;     mormGkSjkS80096738 = mormGkSjkS81400257;     mormGkSjkS81400257 = mormGkSjkS85490458;     mormGkSjkS85490458 = mormGkSjkS25425263;     mormGkSjkS25425263 = mormGkSjkS28172782;     mormGkSjkS28172782 = mormGkSjkS63657175;     mormGkSjkS63657175 = mormGkSjkS10680540;     mormGkSjkS10680540 = mormGkSjkS18554345;     mormGkSjkS18554345 = mormGkSjkS52954060;     mormGkSjkS52954060 = mormGkSjkS41975187;     mormGkSjkS41975187 = mormGkSjkS52434810;     mormGkSjkS52434810 = mormGkSjkS73819383;     mormGkSjkS73819383 = mormGkSjkS18103256;     mormGkSjkS18103256 = mormGkSjkS35176180;     mormGkSjkS35176180 = mormGkSjkS62340959;     mormGkSjkS62340959 = mormGkSjkS38901413;     mormGkSjkS38901413 = mormGkSjkS73315511;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void yxsPcJQsQy38845907() {     int lJFrgJBzZT52094094 = -954277826;    int lJFrgJBzZT63950033 = -708354065;    int lJFrgJBzZT86928115 = 48621935;    int lJFrgJBzZT93097418 = -840305587;    int lJFrgJBzZT11952885 = -685630499;    int lJFrgJBzZT22101767 = -928431855;    int lJFrgJBzZT95939823 = -944522924;    int lJFrgJBzZT32254045 = -199209143;    int lJFrgJBzZT59840308 = -151362089;    int lJFrgJBzZT57551506 = -364164411;    int lJFrgJBzZT81500033 = -488055472;    int lJFrgJBzZT58109488 = -356026439;    int lJFrgJBzZT45026205 = -458597953;    int lJFrgJBzZT69292602 = -24064492;    int lJFrgJBzZT6662559 = 43250233;    int lJFrgJBzZT20407129 = -732292786;    int lJFrgJBzZT94329312 = -293033030;    int lJFrgJBzZT90827008 = -790937869;    int lJFrgJBzZT80215784 = -193119059;    int lJFrgJBzZT9056689 = -970792697;    int lJFrgJBzZT47859635 = 95333398;    int lJFrgJBzZT39727104 = -487138145;    int lJFrgJBzZT88742277 = -153006429;    int lJFrgJBzZT52823887 = -288918665;    int lJFrgJBzZT10403707 = -218607495;    int lJFrgJBzZT4572448 = -161841286;    int lJFrgJBzZT26939349 = 46214963;    int lJFrgJBzZT23716508 = -367326830;    int lJFrgJBzZT36538508 = -698765050;    int lJFrgJBzZT98183358 = -238403570;    int lJFrgJBzZT90210412 = -843558282;    int lJFrgJBzZT80471310 = -410586949;    int lJFrgJBzZT45834645 = -868789519;    int lJFrgJBzZT79506530 = -802257869;    int lJFrgJBzZT8507918 = -12026852;    int lJFrgJBzZT5417316 = -53711363;    int lJFrgJBzZT89157555 = -169542561;    int lJFrgJBzZT90956286 = 27795086;    int lJFrgJBzZT70345851 = -470560726;    int lJFrgJBzZT73996603 = -100222637;    int lJFrgJBzZT6021983 = -343932346;    int lJFrgJBzZT14676599 = -684808302;    int lJFrgJBzZT73900524 = -26476491;    int lJFrgJBzZT72077573 = -662112743;    int lJFrgJBzZT67938026 = -454394335;    int lJFrgJBzZT16431405 = -211668396;    int lJFrgJBzZT92032941 = -935815453;    int lJFrgJBzZT56113951 = -785047189;    int lJFrgJBzZT15762917 = -250630675;    int lJFrgJBzZT59828619 = -400531169;    int lJFrgJBzZT9879221 = -235181636;    int lJFrgJBzZT25524528 = 99509549;    int lJFrgJBzZT79018350 = -572201623;    int lJFrgJBzZT80183607 = -977106035;    int lJFrgJBzZT90986271 = -259331065;    int lJFrgJBzZT12366991 = -367139681;    int lJFrgJBzZT75207755 = -455347636;    int lJFrgJBzZT34104229 = -662459400;    int lJFrgJBzZT82693712 = -521698093;    int lJFrgJBzZT7380437 = -423789214;    int lJFrgJBzZT95162417 = -874646818;    int lJFrgJBzZT72223315 = -477196094;    int lJFrgJBzZT95715537 = -500444094;    int lJFrgJBzZT61656950 = -912958519;    int lJFrgJBzZT67341094 = -520606130;    int lJFrgJBzZT1028724 = 22531476;    int lJFrgJBzZT12274844 = -487236920;    int lJFrgJBzZT65519674 = -656340084;    int lJFrgJBzZT60784684 = 87962360;    int lJFrgJBzZT1245243 = -903038405;    int lJFrgJBzZT31249574 = -462750225;    int lJFrgJBzZT3373026 = -220828116;    int lJFrgJBzZT20481157 = -220377144;    int lJFrgJBzZT6219182 = 7103578;    int lJFrgJBzZT3034706 = -526860352;    int lJFrgJBzZT33183037 = -219858301;    int lJFrgJBzZT65826579 = -360661655;    int lJFrgJBzZT16664705 = -490893686;    int lJFrgJBzZT84885860 = -834524330;    int lJFrgJBzZT93972302 = 93060901;    int lJFrgJBzZT12539507 = -226025833;    int lJFrgJBzZT70825398 = -168737848;    int lJFrgJBzZT7953591 = -16696156;    int lJFrgJBzZT76709888 = -198233882;    int lJFrgJBzZT88304137 = 96778065;    int lJFrgJBzZT64685885 = -843067832;    int lJFrgJBzZT1452960 = -838385326;    int lJFrgJBzZT65651038 = -891683485;    int lJFrgJBzZT88520258 = -442926804;    int lJFrgJBzZT96140926 = -644887171;    int lJFrgJBzZT30209561 = -598363727;    int lJFrgJBzZT55053327 = -507083161;    int lJFrgJBzZT8262575 = -450506822;    int lJFrgJBzZT62965414 = 53228487;    int lJFrgJBzZT78834186 = -225575819;    int lJFrgJBzZT33798667 = -866736252;    int lJFrgJBzZT18961062 = -84364208;    int lJFrgJBzZT12243575 = -113517972;    int lJFrgJBzZT4736479 = -41506614;    int lJFrgJBzZT66909303 = -954277826;     lJFrgJBzZT52094094 = lJFrgJBzZT63950033;     lJFrgJBzZT63950033 = lJFrgJBzZT86928115;     lJFrgJBzZT86928115 = lJFrgJBzZT93097418;     lJFrgJBzZT93097418 = lJFrgJBzZT11952885;     lJFrgJBzZT11952885 = lJFrgJBzZT22101767;     lJFrgJBzZT22101767 = lJFrgJBzZT95939823;     lJFrgJBzZT95939823 = lJFrgJBzZT32254045;     lJFrgJBzZT32254045 = lJFrgJBzZT59840308;     lJFrgJBzZT59840308 = lJFrgJBzZT57551506;     lJFrgJBzZT57551506 = lJFrgJBzZT81500033;     lJFrgJBzZT81500033 = lJFrgJBzZT58109488;     lJFrgJBzZT58109488 = lJFrgJBzZT45026205;     lJFrgJBzZT45026205 = lJFrgJBzZT69292602;     lJFrgJBzZT69292602 = lJFrgJBzZT6662559;     lJFrgJBzZT6662559 = lJFrgJBzZT20407129;     lJFrgJBzZT20407129 = lJFrgJBzZT94329312;     lJFrgJBzZT94329312 = lJFrgJBzZT90827008;     lJFrgJBzZT90827008 = lJFrgJBzZT80215784;     lJFrgJBzZT80215784 = lJFrgJBzZT9056689;     lJFrgJBzZT9056689 = lJFrgJBzZT47859635;     lJFrgJBzZT47859635 = lJFrgJBzZT39727104;     lJFrgJBzZT39727104 = lJFrgJBzZT88742277;     lJFrgJBzZT88742277 = lJFrgJBzZT52823887;     lJFrgJBzZT52823887 = lJFrgJBzZT10403707;     lJFrgJBzZT10403707 = lJFrgJBzZT4572448;     lJFrgJBzZT4572448 = lJFrgJBzZT26939349;     lJFrgJBzZT26939349 = lJFrgJBzZT23716508;     lJFrgJBzZT23716508 = lJFrgJBzZT36538508;     lJFrgJBzZT36538508 = lJFrgJBzZT98183358;     lJFrgJBzZT98183358 = lJFrgJBzZT90210412;     lJFrgJBzZT90210412 = lJFrgJBzZT80471310;     lJFrgJBzZT80471310 = lJFrgJBzZT45834645;     lJFrgJBzZT45834645 = lJFrgJBzZT79506530;     lJFrgJBzZT79506530 = lJFrgJBzZT8507918;     lJFrgJBzZT8507918 = lJFrgJBzZT5417316;     lJFrgJBzZT5417316 = lJFrgJBzZT89157555;     lJFrgJBzZT89157555 = lJFrgJBzZT90956286;     lJFrgJBzZT90956286 = lJFrgJBzZT70345851;     lJFrgJBzZT70345851 = lJFrgJBzZT73996603;     lJFrgJBzZT73996603 = lJFrgJBzZT6021983;     lJFrgJBzZT6021983 = lJFrgJBzZT14676599;     lJFrgJBzZT14676599 = lJFrgJBzZT73900524;     lJFrgJBzZT73900524 = lJFrgJBzZT72077573;     lJFrgJBzZT72077573 = lJFrgJBzZT67938026;     lJFrgJBzZT67938026 = lJFrgJBzZT16431405;     lJFrgJBzZT16431405 = lJFrgJBzZT92032941;     lJFrgJBzZT92032941 = lJFrgJBzZT56113951;     lJFrgJBzZT56113951 = lJFrgJBzZT15762917;     lJFrgJBzZT15762917 = lJFrgJBzZT59828619;     lJFrgJBzZT59828619 = lJFrgJBzZT9879221;     lJFrgJBzZT9879221 = lJFrgJBzZT25524528;     lJFrgJBzZT25524528 = lJFrgJBzZT79018350;     lJFrgJBzZT79018350 = lJFrgJBzZT80183607;     lJFrgJBzZT80183607 = lJFrgJBzZT90986271;     lJFrgJBzZT90986271 = lJFrgJBzZT12366991;     lJFrgJBzZT12366991 = lJFrgJBzZT75207755;     lJFrgJBzZT75207755 = lJFrgJBzZT34104229;     lJFrgJBzZT34104229 = lJFrgJBzZT82693712;     lJFrgJBzZT82693712 = lJFrgJBzZT7380437;     lJFrgJBzZT7380437 = lJFrgJBzZT95162417;     lJFrgJBzZT95162417 = lJFrgJBzZT72223315;     lJFrgJBzZT72223315 = lJFrgJBzZT95715537;     lJFrgJBzZT95715537 = lJFrgJBzZT61656950;     lJFrgJBzZT61656950 = lJFrgJBzZT67341094;     lJFrgJBzZT67341094 = lJFrgJBzZT1028724;     lJFrgJBzZT1028724 = lJFrgJBzZT12274844;     lJFrgJBzZT12274844 = lJFrgJBzZT65519674;     lJFrgJBzZT65519674 = lJFrgJBzZT60784684;     lJFrgJBzZT60784684 = lJFrgJBzZT1245243;     lJFrgJBzZT1245243 = lJFrgJBzZT31249574;     lJFrgJBzZT31249574 = lJFrgJBzZT3373026;     lJFrgJBzZT3373026 = lJFrgJBzZT20481157;     lJFrgJBzZT20481157 = lJFrgJBzZT6219182;     lJFrgJBzZT6219182 = lJFrgJBzZT3034706;     lJFrgJBzZT3034706 = lJFrgJBzZT33183037;     lJFrgJBzZT33183037 = lJFrgJBzZT65826579;     lJFrgJBzZT65826579 = lJFrgJBzZT16664705;     lJFrgJBzZT16664705 = lJFrgJBzZT84885860;     lJFrgJBzZT84885860 = lJFrgJBzZT93972302;     lJFrgJBzZT93972302 = lJFrgJBzZT12539507;     lJFrgJBzZT12539507 = lJFrgJBzZT70825398;     lJFrgJBzZT70825398 = lJFrgJBzZT7953591;     lJFrgJBzZT7953591 = lJFrgJBzZT76709888;     lJFrgJBzZT76709888 = lJFrgJBzZT88304137;     lJFrgJBzZT88304137 = lJFrgJBzZT64685885;     lJFrgJBzZT64685885 = lJFrgJBzZT1452960;     lJFrgJBzZT1452960 = lJFrgJBzZT65651038;     lJFrgJBzZT65651038 = lJFrgJBzZT88520258;     lJFrgJBzZT88520258 = lJFrgJBzZT96140926;     lJFrgJBzZT96140926 = lJFrgJBzZT30209561;     lJFrgJBzZT30209561 = lJFrgJBzZT55053327;     lJFrgJBzZT55053327 = lJFrgJBzZT8262575;     lJFrgJBzZT8262575 = lJFrgJBzZT62965414;     lJFrgJBzZT62965414 = lJFrgJBzZT78834186;     lJFrgJBzZT78834186 = lJFrgJBzZT33798667;     lJFrgJBzZT33798667 = lJFrgJBzZT18961062;     lJFrgJBzZT18961062 = lJFrgJBzZT12243575;     lJFrgJBzZT12243575 = lJFrgJBzZT4736479;     lJFrgJBzZT4736479 = lJFrgJBzZT66909303;     lJFrgJBzZT66909303 = lJFrgJBzZT52094094;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void UgBmDxnwdJ44844257() {     float OgZqZYFFmq61409361 = -856808853;    float OgZqZYFFmq19372956 = -724888567;    float OgZqZYFFmq7080196 = -765018678;    float OgZqZYFFmq50887441 = 68030421;    float OgZqZYFFmq52016124 = -662145656;    float OgZqZYFFmq15645129 = -387300715;    float OgZqZYFFmq69593895 = -743771802;    float OgZqZYFFmq21390202 = -396168291;    float OgZqZYFFmq52648965 = -531422760;    float OgZqZYFFmq26175964 = -184960079;    float OgZqZYFFmq18402018 = -679296544;    float OgZqZYFFmq69347238 = -993396255;    float OgZqZYFFmq40807921 = -44020088;    float OgZqZYFFmq1381244 = -3118597;    float OgZqZYFFmq21938597 = -908280178;    float OgZqZYFFmq25377653 = -759816264;    float OgZqZYFFmq38140080 = -320618117;    float OgZqZYFFmq3019650 = -520995182;    float OgZqZYFFmq62228716 = -146759888;    float OgZqZYFFmq72252036 = 50499462;    float OgZqZYFFmq36538987 = -230366530;    float OgZqZYFFmq63936016 = -310034478;    float OgZqZYFFmq24803544 = -867535429;    float OgZqZYFFmq12030516 = -906079775;    float OgZqZYFFmq73466249 = -537740545;    float OgZqZYFFmq70480265 = -261052927;    float OgZqZYFFmq60697616 = -762673882;    float OgZqZYFFmq94810983 = -874463563;    float OgZqZYFFmq3655415 = -813184486;    float OgZqZYFFmq10964306 = -44488133;    float OgZqZYFFmq60208791 = -454210099;    float OgZqZYFFmq57730673 = -841758244;    float OgZqZYFFmq95693975 = -679880532;    float OgZqZYFFmq68535478 = -285817756;    float OgZqZYFFmq95158193 = -188439447;    float OgZqZYFFmq37242211 = -469936810;    float OgZqZYFFmq26625163 = -870742424;    float OgZqZYFFmq46993085 = -824800277;    float OgZqZYFFmq36571553 = -521776513;    float OgZqZYFFmq50096500 = -907408149;    float OgZqZYFFmq30085117 = -481088764;    float OgZqZYFFmq2328255 = -606080393;    float OgZqZYFFmq95617530 = -248356873;    float OgZqZYFFmq30834474 = -52507631;    float OgZqZYFFmq3888101 = -246170129;    float OgZqZYFFmq86670640 = -537202955;    float OgZqZYFFmq97282572 = -508649598;    float OgZqZYFFmq27584989 = -131590578;    float OgZqZYFFmq81790060 = -486327192;    float OgZqZYFFmq29466521 = -193544871;    float OgZqZYFFmq46846930 = 28942367;    float OgZqZYFFmq89741569 = -548476668;    float OgZqZYFFmq67026008 = -159978530;    float OgZqZYFFmq84764851 = -236959153;    float OgZqZYFFmq8305271 = -194249150;    float OgZqZYFFmq97473345 = -446774375;    float OgZqZYFFmq94569411 = -857353139;    float OgZqZYFFmq95049679 = -858938903;    float OgZqZYFFmq77421191 = -394229034;    float OgZqZYFFmq81535858 = -301092730;    float OgZqZYFFmq54947512 = -624626834;    float OgZqZYFFmq74782911 = -869308239;    float OgZqZYFFmq17734787 = -582983806;    float OgZqZYFFmq41684659 = -386934628;    float OgZqZYFFmq65967172 = -730749981;    float OgZqZYFFmq60671344 = -837538301;    float OgZqZYFFmq73653263 = -213515723;    float OgZqZYFFmq72272442 = -758202332;    float OgZqZYFFmq6223051 = -814679151;    float OgZqZYFFmq84696386 = -338343369;    float OgZqZYFFmq98752489 = -889073840;    float OgZqZYFFmq91146995 = -495817841;    float OgZqZYFFmq66448097 = -999218669;    float OgZqZYFFmq12132217 = -239351739;    float OgZqZYFFmq42166920 = -468411775;    float OgZqZYFFmq34210732 = -624286138;    float OgZqZYFFmq68318485 = 38322394;    float OgZqZYFFmq93969070 = -715027798;    float OgZqZYFFmq8142415 = -559909647;    float OgZqZYFFmq86795609 = 99462409;    float OgZqZYFFmq73197693 = -752403329;    float OgZqZYFFmq33112627 = -531083304;    float OgZqZYFFmq13020923 = -288136372;    float OgZqZYFFmq74188894 = -519639615;    float OgZqZYFFmq64117376 = 26569499;    float OgZqZYFFmq70467221 = -905733431;    float OgZqZYFFmq90704665 = -581779715;    float OgZqZYFFmq10929125 = -342921380;    float OgZqZYFFmq60230208 = 8431393;    float OgZqZYFFmq97684847 = -741665072;    float OgZqZYFFmq42672799 = -612583671;    float OgZqZYFFmq31575483 = 88196479;    float OgZqZYFFmq69571893 = -330571243;    float OgZqZYFFmq55035694 = -120683783;    float OgZqZYFFmq95148987 = -182781316;    float OgZqZYFFmq55302205 = -611780525;    float OgZqZYFFmq84593468 = 76903413;    float OgZqZYFFmq53932871 = -861422245;    float OgZqZYFFmq64867301 = -321757651;    float OgZqZYFFmq43216756 = -856808853;     OgZqZYFFmq61409361 = OgZqZYFFmq19372956;     OgZqZYFFmq19372956 = OgZqZYFFmq7080196;     OgZqZYFFmq7080196 = OgZqZYFFmq50887441;     OgZqZYFFmq50887441 = OgZqZYFFmq52016124;     OgZqZYFFmq52016124 = OgZqZYFFmq15645129;     OgZqZYFFmq15645129 = OgZqZYFFmq69593895;     OgZqZYFFmq69593895 = OgZqZYFFmq21390202;     OgZqZYFFmq21390202 = OgZqZYFFmq52648965;     OgZqZYFFmq52648965 = OgZqZYFFmq26175964;     OgZqZYFFmq26175964 = OgZqZYFFmq18402018;     OgZqZYFFmq18402018 = OgZqZYFFmq69347238;     OgZqZYFFmq69347238 = OgZqZYFFmq40807921;     OgZqZYFFmq40807921 = OgZqZYFFmq1381244;     OgZqZYFFmq1381244 = OgZqZYFFmq21938597;     OgZqZYFFmq21938597 = OgZqZYFFmq25377653;     OgZqZYFFmq25377653 = OgZqZYFFmq38140080;     OgZqZYFFmq38140080 = OgZqZYFFmq3019650;     OgZqZYFFmq3019650 = OgZqZYFFmq62228716;     OgZqZYFFmq62228716 = OgZqZYFFmq72252036;     OgZqZYFFmq72252036 = OgZqZYFFmq36538987;     OgZqZYFFmq36538987 = OgZqZYFFmq63936016;     OgZqZYFFmq63936016 = OgZqZYFFmq24803544;     OgZqZYFFmq24803544 = OgZqZYFFmq12030516;     OgZqZYFFmq12030516 = OgZqZYFFmq73466249;     OgZqZYFFmq73466249 = OgZqZYFFmq70480265;     OgZqZYFFmq70480265 = OgZqZYFFmq60697616;     OgZqZYFFmq60697616 = OgZqZYFFmq94810983;     OgZqZYFFmq94810983 = OgZqZYFFmq3655415;     OgZqZYFFmq3655415 = OgZqZYFFmq10964306;     OgZqZYFFmq10964306 = OgZqZYFFmq60208791;     OgZqZYFFmq60208791 = OgZqZYFFmq57730673;     OgZqZYFFmq57730673 = OgZqZYFFmq95693975;     OgZqZYFFmq95693975 = OgZqZYFFmq68535478;     OgZqZYFFmq68535478 = OgZqZYFFmq95158193;     OgZqZYFFmq95158193 = OgZqZYFFmq37242211;     OgZqZYFFmq37242211 = OgZqZYFFmq26625163;     OgZqZYFFmq26625163 = OgZqZYFFmq46993085;     OgZqZYFFmq46993085 = OgZqZYFFmq36571553;     OgZqZYFFmq36571553 = OgZqZYFFmq50096500;     OgZqZYFFmq50096500 = OgZqZYFFmq30085117;     OgZqZYFFmq30085117 = OgZqZYFFmq2328255;     OgZqZYFFmq2328255 = OgZqZYFFmq95617530;     OgZqZYFFmq95617530 = OgZqZYFFmq30834474;     OgZqZYFFmq30834474 = OgZqZYFFmq3888101;     OgZqZYFFmq3888101 = OgZqZYFFmq86670640;     OgZqZYFFmq86670640 = OgZqZYFFmq97282572;     OgZqZYFFmq97282572 = OgZqZYFFmq27584989;     OgZqZYFFmq27584989 = OgZqZYFFmq81790060;     OgZqZYFFmq81790060 = OgZqZYFFmq29466521;     OgZqZYFFmq29466521 = OgZqZYFFmq46846930;     OgZqZYFFmq46846930 = OgZqZYFFmq89741569;     OgZqZYFFmq89741569 = OgZqZYFFmq67026008;     OgZqZYFFmq67026008 = OgZqZYFFmq84764851;     OgZqZYFFmq84764851 = OgZqZYFFmq8305271;     OgZqZYFFmq8305271 = OgZqZYFFmq97473345;     OgZqZYFFmq97473345 = OgZqZYFFmq94569411;     OgZqZYFFmq94569411 = OgZqZYFFmq95049679;     OgZqZYFFmq95049679 = OgZqZYFFmq77421191;     OgZqZYFFmq77421191 = OgZqZYFFmq81535858;     OgZqZYFFmq81535858 = OgZqZYFFmq54947512;     OgZqZYFFmq54947512 = OgZqZYFFmq74782911;     OgZqZYFFmq74782911 = OgZqZYFFmq17734787;     OgZqZYFFmq17734787 = OgZqZYFFmq41684659;     OgZqZYFFmq41684659 = OgZqZYFFmq65967172;     OgZqZYFFmq65967172 = OgZqZYFFmq60671344;     OgZqZYFFmq60671344 = OgZqZYFFmq73653263;     OgZqZYFFmq73653263 = OgZqZYFFmq72272442;     OgZqZYFFmq72272442 = OgZqZYFFmq6223051;     OgZqZYFFmq6223051 = OgZqZYFFmq84696386;     OgZqZYFFmq84696386 = OgZqZYFFmq98752489;     OgZqZYFFmq98752489 = OgZqZYFFmq91146995;     OgZqZYFFmq91146995 = OgZqZYFFmq66448097;     OgZqZYFFmq66448097 = OgZqZYFFmq12132217;     OgZqZYFFmq12132217 = OgZqZYFFmq42166920;     OgZqZYFFmq42166920 = OgZqZYFFmq34210732;     OgZqZYFFmq34210732 = OgZqZYFFmq68318485;     OgZqZYFFmq68318485 = OgZqZYFFmq93969070;     OgZqZYFFmq93969070 = OgZqZYFFmq8142415;     OgZqZYFFmq8142415 = OgZqZYFFmq86795609;     OgZqZYFFmq86795609 = OgZqZYFFmq73197693;     OgZqZYFFmq73197693 = OgZqZYFFmq33112627;     OgZqZYFFmq33112627 = OgZqZYFFmq13020923;     OgZqZYFFmq13020923 = OgZqZYFFmq74188894;     OgZqZYFFmq74188894 = OgZqZYFFmq64117376;     OgZqZYFFmq64117376 = OgZqZYFFmq70467221;     OgZqZYFFmq70467221 = OgZqZYFFmq90704665;     OgZqZYFFmq90704665 = OgZqZYFFmq10929125;     OgZqZYFFmq10929125 = OgZqZYFFmq60230208;     OgZqZYFFmq60230208 = OgZqZYFFmq97684847;     OgZqZYFFmq97684847 = OgZqZYFFmq42672799;     OgZqZYFFmq42672799 = OgZqZYFFmq31575483;     OgZqZYFFmq31575483 = OgZqZYFFmq69571893;     OgZqZYFFmq69571893 = OgZqZYFFmq55035694;     OgZqZYFFmq55035694 = OgZqZYFFmq95148987;     OgZqZYFFmq95148987 = OgZqZYFFmq55302205;     OgZqZYFFmq55302205 = OgZqZYFFmq84593468;     OgZqZYFFmq84593468 = OgZqZYFFmq53932871;     OgZqZYFFmq53932871 = OgZqZYFFmq64867301;     OgZqZYFFmq64867301 = OgZqZYFFmq43216756;     OgZqZYFFmq43216756 = OgZqZYFFmq61409361;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void qXKPMUbkqp81489231() {     float CQCHwRPLLW83796478 = -491212816;    float CQCHwRPLLW3720456 = -673431622;    float CQCHwRPLLW35849474 = 95327478;    float CQCHwRPLLW65894129 = 61622889;    float CQCHwRPLLW50190378 = -153202658;    float CQCHwRPLLW30528245 = -247909093;    float CQCHwRPLLW61749634 = -565759108;    float CQCHwRPLLW97024060 = -866764935;    float CQCHwRPLLW49812096 = -415618799;    float CQCHwRPLLW17939549 = 72298588;    float CQCHwRPLLW55943877 = -675920945;    float CQCHwRPLLW25250187 = -144141548;    float CQCHwRPLLW7816102 = -662737407;    float CQCHwRPLLW43995996 = -530827354;    float CQCHwRPLLW58673874 = -535757891;    float CQCHwRPLLW69633565 = -41483806;    float CQCHwRPLLW87963431 = -597897937;    float CQCHwRPLLW8996066 = -972737873;    float CQCHwRPLLW3510348 = -281862013;    float CQCHwRPLLW50768320 = -202134992;    float CQCHwRPLLW37422094 = -221853839;    float CQCHwRPLLW27751234 = -814800791;    float CQCHwRPLLW28096868 = 56383979;    float CQCHwRPLLW38530303 = -370072632;    float CQCHwRPLLW9006496 = -159299670;    float CQCHwRPLLW58783260 = -704947150;    float CQCHwRPLLW7787037 = -520260375;    float CQCHwRPLLW722434 = -662918017;    float CQCHwRPLLW10547976 = -57441605;    float CQCHwRPLLW20121486 = 35216001;    float CQCHwRPLLW4499597 = -535526251;    float CQCHwRPLLW15271865 = -393829599;    float CQCHwRPLLW76732645 = -109224027;    float CQCHwRPLLW27924166 = -609944606;    float CQCHwRPLLW71387557 = -252195869;    float CQCHwRPLLW78935079 = -785332186;    float CQCHwRPLLW20064876 = -603690375;    float CQCHwRPLLW619186 = -692425749;    float CQCHwRPLLW84879683 = -922822545;    float CQCHwRPLLW70282215 = 56367821;    float CQCHwRPLLW58842487 = -984266430;    float CQCHwRPLLW90836645 = -363989084;    float CQCHwRPLLW1167723 = -135887456;    float CQCHwRPLLW30278593 = -49871280;    float CQCHwRPLLW71871367 = -55313607;    float CQCHwRPLLW94770921 = -719432050;    float CQCHwRPLLW9579970 = 12940149;    float CQCHwRPLLW72183663 = -988125569;    float CQCHwRPLLW76249965 = -436043890;    float CQCHwRPLLW26550267 = -335565130;    float CQCHwRPLLW55716146 = -326133910;    float CQCHwRPLLW63592827 = -979295950;    float CQCHwRPLLW45340411 = -931889760;    float CQCHwRPLLW45051396 = -512639962;    float CQCHwRPLLW44067138 = -334953265;    float CQCHwRPLLW56045244 = -676412025;    float CQCHwRPLLW75623588 = -629815601;    float CQCHwRPLLW97319171 = -534599890;    float CQCHwRPLLW56887633 = -779077441;    float CQCHwRPLLW91407118 = -448255508;    float CQCHwRPLLW22741209 = -727648719;    float CQCHwRPLLW61027200 = -902841092;    float CQCHwRPLLW86476084 = -709323331;    float CQCHwRPLLW29690611 = -350834800;    float CQCHwRPLLW13439952 = -392175161;    float CQCHwRPLLW40672013 = -182091347;    float CQCHwRPLLW48517541 = 65082478;    float CQCHwRPLLW79891935 = 47207198;    float CQCHwRPLLW72608438 = -178631485;    float CQCHwRPLLW79738794 = -750425706;    float CQCHwRPLLW49568690 = -437793431;    float CQCHwRPLLW87344246 = -905472189;    float CQCHwRPLLW24116382 = 50084672;    float CQCHwRPLLW33228133 = -238229835;    float CQCHwRPLLW91925832 = -217868563;    float CQCHwRPLLW46585448 = -857864756;    float CQCHwRPLLW26583512 = -578913335;    float CQCHwRPLLW97818274 = -893744741;    float CQCHwRPLLW66658935 = -214759026;    float CQCHwRPLLW14235575 = -439867620;    float CQCHwRPLLW49203290 = -617887300;    float CQCHwRPLLW35603373 = -532134806;    float CQCHwRPLLW24472468 = -126874127;    float CQCHwRPLLW83997709 = -721876475;    float CQCHwRPLLW64405339 = -638650090;    float CQCHwRPLLW40906769 = -556230301;    float CQCHwRPLLW69931453 = -461939839;    float CQCHwRPLLW31681250 = -596584066;    float CQCHwRPLLW83857028 = -174991341;    float CQCHwRPLLW15342314 = -575783845;    float CQCHwRPLLW3311492 = -55516585;    float CQCHwRPLLW22745704 = 30909514;    float CQCHwRPLLW43731553 = -913348308;    float CQCHwRPLLW93472565 = -374567038;    float CQCHwRPLLW47541006 = -215983460;    float CQCHwRPLLW97815286 = 18574662;    float CQCHwRPLLW4360562 = -654665753;    float CQCHwRPLLW71477111 = -785052657;    float CQCHwRPLLW16838641 = -657696119;    float CQCHwRPLLW31199354 = -491212816;     CQCHwRPLLW83796478 = CQCHwRPLLW3720456;     CQCHwRPLLW3720456 = CQCHwRPLLW35849474;     CQCHwRPLLW35849474 = CQCHwRPLLW65894129;     CQCHwRPLLW65894129 = CQCHwRPLLW50190378;     CQCHwRPLLW50190378 = CQCHwRPLLW30528245;     CQCHwRPLLW30528245 = CQCHwRPLLW61749634;     CQCHwRPLLW61749634 = CQCHwRPLLW97024060;     CQCHwRPLLW97024060 = CQCHwRPLLW49812096;     CQCHwRPLLW49812096 = CQCHwRPLLW17939549;     CQCHwRPLLW17939549 = CQCHwRPLLW55943877;     CQCHwRPLLW55943877 = CQCHwRPLLW25250187;     CQCHwRPLLW25250187 = CQCHwRPLLW7816102;     CQCHwRPLLW7816102 = CQCHwRPLLW43995996;     CQCHwRPLLW43995996 = CQCHwRPLLW58673874;     CQCHwRPLLW58673874 = CQCHwRPLLW69633565;     CQCHwRPLLW69633565 = CQCHwRPLLW87963431;     CQCHwRPLLW87963431 = CQCHwRPLLW8996066;     CQCHwRPLLW8996066 = CQCHwRPLLW3510348;     CQCHwRPLLW3510348 = CQCHwRPLLW50768320;     CQCHwRPLLW50768320 = CQCHwRPLLW37422094;     CQCHwRPLLW37422094 = CQCHwRPLLW27751234;     CQCHwRPLLW27751234 = CQCHwRPLLW28096868;     CQCHwRPLLW28096868 = CQCHwRPLLW38530303;     CQCHwRPLLW38530303 = CQCHwRPLLW9006496;     CQCHwRPLLW9006496 = CQCHwRPLLW58783260;     CQCHwRPLLW58783260 = CQCHwRPLLW7787037;     CQCHwRPLLW7787037 = CQCHwRPLLW722434;     CQCHwRPLLW722434 = CQCHwRPLLW10547976;     CQCHwRPLLW10547976 = CQCHwRPLLW20121486;     CQCHwRPLLW20121486 = CQCHwRPLLW4499597;     CQCHwRPLLW4499597 = CQCHwRPLLW15271865;     CQCHwRPLLW15271865 = CQCHwRPLLW76732645;     CQCHwRPLLW76732645 = CQCHwRPLLW27924166;     CQCHwRPLLW27924166 = CQCHwRPLLW71387557;     CQCHwRPLLW71387557 = CQCHwRPLLW78935079;     CQCHwRPLLW78935079 = CQCHwRPLLW20064876;     CQCHwRPLLW20064876 = CQCHwRPLLW619186;     CQCHwRPLLW619186 = CQCHwRPLLW84879683;     CQCHwRPLLW84879683 = CQCHwRPLLW70282215;     CQCHwRPLLW70282215 = CQCHwRPLLW58842487;     CQCHwRPLLW58842487 = CQCHwRPLLW90836645;     CQCHwRPLLW90836645 = CQCHwRPLLW1167723;     CQCHwRPLLW1167723 = CQCHwRPLLW30278593;     CQCHwRPLLW30278593 = CQCHwRPLLW71871367;     CQCHwRPLLW71871367 = CQCHwRPLLW94770921;     CQCHwRPLLW94770921 = CQCHwRPLLW9579970;     CQCHwRPLLW9579970 = CQCHwRPLLW72183663;     CQCHwRPLLW72183663 = CQCHwRPLLW76249965;     CQCHwRPLLW76249965 = CQCHwRPLLW26550267;     CQCHwRPLLW26550267 = CQCHwRPLLW55716146;     CQCHwRPLLW55716146 = CQCHwRPLLW63592827;     CQCHwRPLLW63592827 = CQCHwRPLLW45340411;     CQCHwRPLLW45340411 = CQCHwRPLLW45051396;     CQCHwRPLLW45051396 = CQCHwRPLLW44067138;     CQCHwRPLLW44067138 = CQCHwRPLLW56045244;     CQCHwRPLLW56045244 = CQCHwRPLLW75623588;     CQCHwRPLLW75623588 = CQCHwRPLLW97319171;     CQCHwRPLLW97319171 = CQCHwRPLLW56887633;     CQCHwRPLLW56887633 = CQCHwRPLLW91407118;     CQCHwRPLLW91407118 = CQCHwRPLLW22741209;     CQCHwRPLLW22741209 = CQCHwRPLLW61027200;     CQCHwRPLLW61027200 = CQCHwRPLLW86476084;     CQCHwRPLLW86476084 = CQCHwRPLLW29690611;     CQCHwRPLLW29690611 = CQCHwRPLLW13439952;     CQCHwRPLLW13439952 = CQCHwRPLLW40672013;     CQCHwRPLLW40672013 = CQCHwRPLLW48517541;     CQCHwRPLLW48517541 = CQCHwRPLLW79891935;     CQCHwRPLLW79891935 = CQCHwRPLLW72608438;     CQCHwRPLLW72608438 = CQCHwRPLLW79738794;     CQCHwRPLLW79738794 = CQCHwRPLLW49568690;     CQCHwRPLLW49568690 = CQCHwRPLLW87344246;     CQCHwRPLLW87344246 = CQCHwRPLLW24116382;     CQCHwRPLLW24116382 = CQCHwRPLLW33228133;     CQCHwRPLLW33228133 = CQCHwRPLLW91925832;     CQCHwRPLLW91925832 = CQCHwRPLLW46585448;     CQCHwRPLLW46585448 = CQCHwRPLLW26583512;     CQCHwRPLLW26583512 = CQCHwRPLLW97818274;     CQCHwRPLLW97818274 = CQCHwRPLLW66658935;     CQCHwRPLLW66658935 = CQCHwRPLLW14235575;     CQCHwRPLLW14235575 = CQCHwRPLLW49203290;     CQCHwRPLLW49203290 = CQCHwRPLLW35603373;     CQCHwRPLLW35603373 = CQCHwRPLLW24472468;     CQCHwRPLLW24472468 = CQCHwRPLLW83997709;     CQCHwRPLLW83997709 = CQCHwRPLLW64405339;     CQCHwRPLLW64405339 = CQCHwRPLLW40906769;     CQCHwRPLLW40906769 = CQCHwRPLLW69931453;     CQCHwRPLLW69931453 = CQCHwRPLLW31681250;     CQCHwRPLLW31681250 = CQCHwRPLLW83857028;     CQCHwRPLLW83857028 = CQCHwRPLLW15342314;     CQCHwRPLLW15342314 = CQCHwRPLLW3311492;     CQCHwRPLLW3311492 = CQCHwRPLLW22745704;     CQCHwRPLLW22745704 = CQCHwRPLLW43731553;     CQCHwRPLLW43731553 = CQCHwRPLLW93472565;     CQCHwRPLLW93472565 = CQCHwRPLLW47541006;     CQCHwRPLLW47541006 = CQCHwRPLLW97815286;     CQCHwRPLLW97815286 = CQCHwRPLLW4360562;     CQCHwRPLLW4360562 = CQCHwRPLLW71477111;     CQCHwRPLLW71477111 = CQCHwRPLLW16838641;     CQCHwRPLLW16838641 = CQCHwRPLLW31199354;     CQCHwRPLLW31199354 = CQCHwRPLLW83796478;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void wlBIZOdvGd39730113() {     long YlFOXUGKHK22453607 = -748118853;    long YlFOXUGKHK29042177 = -860917951;    long YlFOXUGKHK77345848 = -233147289;    long YlFOXUGKHK68832725 = -860443544;    long YlFOXUGKHK77643398 = -814666789;    long YlFOXUGKHK68877277 = -804629614;    long YlFOXUGKHK85572145 = -70768743;    long YlFOXUGKHK98531886 = -421084311;    long YlFOXUGKHK79495863 = -415978212;    long YlFOXUGKHK60237058 = -184208600;    long YlFOXUGKHK70917306 = -791732160;    long YlFOXUGKHK5233043 = -201225933;    long YlFOXUGKHK55623344 = -360280958;    long YlFOXUGKHK46081823 = 45993700;    long YlFOXUGKHK36402001 = -200251151;    long YlFOXUGKHK16639997 = -831819348;    long YlFOXUGKHK93774131 = -535912464;    long YlFOXUGKHK23895746 = -10700611;    long YlFOXUGKHK24243768 = -146297167;    long YlFOXUGKHK27250722 = -350500980;    long YlFOXUGKHK50635115 = -349341000;    long YlFOXUGKHK68860647 = -816403701;    long YlFOXUGKHK99092721 = -549259718;    long YlFOXUGKHK7537504 = -175753359;    long YlFOXUGKHK36387340 = -129221886;    long YlFOXUGKHK10667574 = -614080275;    long YlFOXUGKHK3506099 = -134771157;    long YlFOXUGKHK99438208 = -173897970;    long YlFOXUGKHK58200842 = -523573139;    long YlFOXUGKHK69820208 = 12095135;    long YlFOXUGKHK838658 = -784837617;    long YlFOXUGKHK32743624 = -888525492;    long YlFOXUGKHK29099038 = -175297646;    long YlFOXUGKHK51870976 = -406656541;    long YlFOXUGKHK62371635 = -840975609;    long YlFOXUGKHK93594904 = -102096832;    long YlFOXUGKHK25682365 = -115950409;    long YlFOXUGKHK73781175 = -656170683;    long YlFOXUGKHK7885693 = -630991112;    long YlFOXUGKHK23151707 = -842641015;    long YlFOXUGKHK10688006 = -825347868;    long YlFOXUGKHK35702971 = -709664188;    long YlFOXUGKHK34201128 = -930144040;    long YlFOXUGKHK41759091 = -25255640;    long YlFOXUGKHK95885435 = -11702408;    long YlFOXUGKHK99032290 = 1325875;    long YlFOXUGKHK16396191 = 74895181;    long YlFOXUGKHK53424071 = -491300018;    long YlFOXUGKHK55494047 = -249740298;    long YlFOXUGKHK7806106 = -532594840;    long YlFOXUGKHK37753901 = -93992792;    long YlFOXUGKHK485622 = -940208194;    long YlFOXUGKHK53720760 = -483922632;    long YlFOXUGKHK69655606 = -743531434;    long YlFOXUGKHK89094998 = 84170287;    long YlFOXUGKHK53592959 = -931715152;    long YlFOXUGKHK29949456 = -211658233;    long YlFOXUGKHK69808344 = 42606070;    long YlFOXUGKHK32445386 = -631221658;    long YlFOXUGKHK66975824 = -100586515;    long YlFOXUGKHK65371178 = -569858457;    long YlFOXUGKHK86133937 = -896870774;    long YlFOXUGKHK40331045 = -897511173;    long YlFOXUGKHK9675656 = -328073347;    long YlFOXUGKHK59398401 = -399370984;    long YlFOXUGKHK38173682 = -903206669;    long YlFOXUGKHK76134004 = 74071713;    long YlFOXUGKHK3752368 = -953624417;    long YlFOXUGKHK83710188 = -113030691;    long YlFOXUGKHK42807096 = 1845680;    long YlFOXUGKHK90957631 = -615868940;    long YlFOXUGKHK19992957 = -879741781;    long YlFOXUGKHK16010053 = -379709500;    long YlFOXUGKHK1092062 = -303656153;    long YlFOXUGKHK16562717 = -525153112;    long YlFOXUGKHK14932144 = -639676813;    long YlFOXUGKHK34659519 = -886259662;    long YlFOXUGKHK57333631 = -424004079;    long YlFOXUGKHK11652068 = -64050952;    long YlFOXUGKHK37355049 = -30547762;    long YlFOXUGKHK94271383 = -588975457;    long YlFOXUGKHK50082028 = -643471140;    long YlFOXUGKHK43944161 = -924157672;    long YlFOXUGKHK50394736 = -990978299;    long YlFOXUGKHK32066307 = -893912073;    long YlFOXUGKHK353036 = -844629423;    long YlFOXUGKHK79022864 = -304602861;    long YlFOXUGKHK59443432 = -431766213;    long YlFOXUGKHK62775978 = -390826828;    long YlFOXUGKHK8778676 = -909260457;    long YlFOXUGKHK63645449 = -890438599;    long YlFOXUGKHK55874020 = -58556479;    long YlFOXUGKHK41335789 = 75050975;    long YlFOXUGKHK40909868 = -430404598;    long YlFOXUGKHK57780528 = -172782558;    long YlFOXUGKHK24554068 = -928477095;    long YlFOXUGKHK95371926 = -812153016;    long YlFOXUGKHK24525473 = -502070693;    long YlFOXUGKHK82360689 = -625884657;    long YlFOXUGKHK57711753 = -748118853;     YlFOXUGKHK22453607 = YlFOXUGKHK29042177;     YlFOXUGKHK29042177 = YlFOXUGKHK77345848;     YlFOXUGKHK77345848 = YlFOXUGKHK68832725;     YlFOXUGKHK68832725 = YlFOXUGKHK77643398;     YlFOXUGKHK77643398 = YlFOXUGKHK68877277;     YlFOXUGKHK68877277 = YlFOXUGKHK85572145;     YlFOXUGKHK85572145 = YlFOXUGKHK98531886;     YlFOXUGKHK98531886 = YlFOXUGKHK79495863;     YlFOXUGKHK79495863 = YlFOXUGKHK60237058;     YlFOXUGKHK60237058 = YlFOXUGKHK70917306;     YlFOXUGKHK70917306 = YlFOXUGKHK5233043;     YlFOXUGKHK5233043 = YlFOXUGKHK55623344;     YlFOXUGKHK55623344 = YlFOXUGKHK46081823;     YlFOXUGKHK46081823 = YlFOXUGKHK36402001;     YlFOXUGKHK36402001 = YlFOXUGKHK16639997;     YlFOXUGKHK16639997 = YlFOXUGKHK93774131;     YlFOXUGKHK93774131 = YlFOXUGKHK23895746;     YlFOXUGKHK23895746 = YlFOXUGKHK24243768;     YlFOXUGKHK24243768 = YlFOXUGKHK27250722;     YlFOXUGKHK27250722 = YlFOXUGKHK50635115;     YlFOXUGKHK50635115 = YlFOXUGKHK68860647;     YlFOXUGKHK68860647 = YlFOXUGKHK99092721;     YlFOXUGKHK99092721 = YlFOXUGKHK7537504;     YlFOXUGKHK7537504 = YlFOXUGKHK36387340;     YlFOXUGKHK36387340 = YlFOXUGKHK10667574;     YlFOXUGKHK10667574 = YlFOXUGKHK3506099;     YlFOXUGKHK3506099 = YlFOXUGKHK99438208;     YlFOXUGKHK99438208 = YlFOXUGKHK58200842;     YlFOXUGKHK58200842 = YlFOXUGKHK69820208;     YlFOXUGKHK69820208 = YlFOXUGKHK838658;     YlFOXUGKHK838658 = YlFOXUGKHK32743624;     YlFOXUGKHK32743624 = YlFOXUGKHK29099038;     YlFOXUGKHK29099038 = YlFOXUGKHK51870976;     YlFOXUGKHK51870976 = YlFOXUGKHK62371635;     YlFOXUGKHK62371635 = YlFOXUGKHK93594904;     YlFOXUGKHK93594904 = YlFOXUGKHK25682365;     YlFOXUGKHK25682365 = YlFOXUGKHK73781175;     YlFOXUGKHK73781175 = YlFOXUGKHK7885693;     YlFOXUGKHK7885693 = YlFOXUGKHK23151707;     YlFOXUGKHK23151707 = YlFOXUGKHK10688006;     YlFOXUGKHK10688006 = YlFOXUGKHK35702971;     YlFOXUGKHK35702971 = YlFOXUGKHK34201128;     YlFOXUGKHK34201128 = YlFOXUGKHK41759091;     YlFOXUGKHK41759091 = YlFOXUGKHK95885435;     YlFOXUGKHK95885435 = YlFOXUGKHK99032290;     YlFOXUGKHK99032290 = YlFOXUGKHK16396191;     YlFOXUGKHK16396191 = YlFOXUGKHK53424071;     YlFOXUGKHK53424071 = YlFOXUGKHK55494047;     YlFOXUGKHK55494047 = YlFOXUGKHK7806106;     YlFOXUGKHK7806106 = YlFOXUGKHK37753901;     YlFOXUGKHK37753901 = YlFOXUGKHK485622;     YlFOXUGKHK485622 = YlFOXUGKHK53720760;     YlFOXUGKHK53720760 = YlFOXUGKHK69655606;     YlFOXUGKHK69655606 = YlFOXUGKHK89094998;     YlFOXUGKHK89094998 = YlFOXUGKHK53592959;     YlFOXUGKHK53592959 = YlFOXUGKHK29949456;     YlFOXUGKHK29949456 = YlFOXUGKHK69808344;     YlFOXUGKHK69808344 = YlFOXUGKHK32445386;     YlFOXUGKHK32445386 = YlFOXUGKHK66975824;     YlFOXUGKHK66975824 = YlFOXUGKHK65371178;     YlFOXUGKHK65371178 = YlFOXUGKHK86133937;     YlFOXUGKHK86133937 = YlFOXUGKHK40331045;     YlFOXUGKHK40331045 = YlFOXUGKHK9675656;     YlFOXUGKHK9675656 = YlFOXUGKHK59398401;     YlFOXUGKHK59398401 = YlFOXUGKHK38173682;     YlFOXUGKHK38173682 = YlFOXUGKHK76134004;     YlFOXUGKHK76134004 = YlFOXUGKHK3752368;     YlFOXUGKHK3752368 = YlFOXUGKHK83710188;     YlFOXUGKHK83710188 = YlFOXUGKHK42807096;     YlFOXUGKHK42807096 = YlFOXUGKHK90957631;     YlFOXUGKHK90957631 = YlFOXUGKHK19992957;     YlFOXUGKHK19992957 = YlFOXUGKHK16010053;     YlFOXUGKHK16010053 = YlFOXUGKHK1092062;     YlFOXUGKHK1092062 = YlFOXUGKHK16562717;     YlFOXUGKHK16562717 = YlFOXUGKHK14932144;     YlFOXUGKHK14932144 = YlFOXUGKHK34659519;     YlFOXUGKHK34659519 = YlFOXUGKHK57333631;     YlFOXUGKHK57333631 = YlFOXUGKHK11652068;     YlFOXUGKHK11652068 = YlFOXUGKHK37355049;     YlFOXUGKHK37355049 = YlFOXUGKHK94271383;     YlFOXUGKHK94271383 = YlFOXUGKHK50082028;     YlFOXUGKHK50082028 = YlFOXUGKHK43944161;     YlFOXUGKHK43944161 = YlFOXUGKHK50394736;     YlFOXUGKHK50394736 = YlFOXUGKHK32066307;     YlFOXUGKHK32066307 = YlFOXUGKHK353036;     YlFOXUGKHK353036 = YlFOXUGKHK79022864;     YlFOXUGKHK79022864 = YlFOXUGKHK59443432;     YlFOXUGKHK59443432 = YlFOXUGKHK62775978;     YlFOXUGKHK62775978 = YlFOXUGKHK8778676;     YlFOXUGKHK8778676 = YlFOXUGKHK63645449;     YlFOXUGKHK63645449 = YlFOXUGKHK55874020;     YlFOXUGKHK55874020 = YlFOXUGKHK41335789;     YlFOXUGKHK41335789 = YlFOXUGKHK40909868;     YlFOXUGKHK40909868 = YlFOXUGKHK57780528;     YlFOXUGKHK57780528 = YlFOXUGKHK24554068;     YlFOXUGKHK24554068 = YlFOXUGKHK95371926;     YlFOXUGKHK95371926 = YlFOXUGKHK24525473;     YlFOXUGKHK24525473 = YlFOXUGKHK82360689;     YlFOXUGKHK82360689 = YlFOXUGKHK57711753;     YlFOXUGKHK57711753 = YlFOXUGKHK22453607;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void VSqEwUqLzP76375087() {     long tywbKWmrif44840724 = -382522816;    long tywbKWmrif13389678 = -809461005;    long tywbKWmrif6115127 = -472801133;    long tywbKWmrif83839413 = -866851075;    long tywbKWmrif75817652 = -305723790;    long tywbKWmrif83760393 = -665237992;    long tywbKWmrif77727884 = -992756049;    long tywbKWmrif74165745 = -891680955;    long tywbKWmrif76658994 = -300174251;    long tywbKWmrif52000643 = 73050067;    long tywbKWmrif8459166 = -788356561;    long tywbKWmrif61135991 = -451971226;    long tywbKWmrif22631525 = -978998277;    long tywbKWmrif88696575 = -481715057;    long tywbKWmrif73137278 = -927728864;    long tywbKWmrif60895909 = -113486890;    long tywbKWmrif43597484 = -813192283;    long tywbKWmrif29872162 = -462443302;    long tywbKWmrif65525398 = -281399292;    long tywbKWmrif5767005 = -603135433;    long tywbKWmrif51518222 = -340828309;    long tywbKWmrif32675866 = -221170015;    long tywbKWmrif2386045 = -725340310;    long tywbKWmrif34037291 = -739746216;    long tywbKWmrif71927586 = -850781011;    long tywbKWmrif98970568 = 42025501;    long tywbKWmrif50595519 = -992357650;    long tywbKWmrif5349659 = 37647576;    long tywbKWmrif65093403 = -867830258;    long tywbKWmrif78977387 = 91799268;    long tywbKWmrif45129462 = -866153769;    long tywbKWmrif90284815 = -440596847;    long tywbKWmrif10137709 = -704641141;    long tywbKWmrif11259664 = -730783391;    long tywbKWmrif38601000 = -904732031;    long tywbKWmrif35287774 = -417492208;    long tywbKWmrif19122077 = -948898360;    long tywbKWmrif27407276 = -523796155;    long tywbKWmrif56193824 = 67962857;    long tywbKWmrif43337421 = -978865044;    long tywbKWmrif39445376 = -228525534;    long tywbKWmrif24211363 = -467572879;    long tywbKWmrif39751320 = -817674624;    long tywbKWmrif41203210 = -22619289;    long tywbKWmrif63868702 = -920845886;    long tywbKWmrif7132573 = -180903220;    long tywbKWmrif28693588 = -503515072;    long tywbKWmrif98022745 = -247835009;    long tywbKWmrif49953952 = -199456997;    long tywbKWmrif4889852 = -674615099;    long tywbKWmrif46623118 = -449069069;    long tywbKWmrif74336879 = -271027476;    long tywbKWmrif32035164 = -155833862;    long tywbKWmrif29942152 = 80787757;    long tywbKWmrif24856866 = -56533828;    long tywbKWmrif12164859 = -61352802;    long tywbKWmrif11003633 = 15879305;    long tywbKWmrif72077836 = -733054917;    long tywbKWmrif11911827 = 83929935;    long tywbKWmrif76847084 = -247749292;    long tywbKWmrif33164875 = -672880342;    long tywbKWmrif72378226 = -930403626;    long tywbKWmrif9072343 = 76149302;    long tywbKWmrif97681606 = -291973520;    long tywbKWmrif6871181 = -60796165;    long tywbKWmrif18174351 = -247759715;    long tywbKWmrif50998283 = -747330085;    long tywbKWmrif11371861 = -148214887;    long tywbKWmrif50095576 = -576983026;    long tywbKWmrif37849504 = -410236657;    long tywbKWmrif41773832 = -164588531;    long tywbKWmrif16190208 = -189396129;    long tywbKWmrif73678338 = -430406159;    long tywbKWmrif22187978 = -302534249;    long tywbKWmrif66321629 = -274609900;    long tywbKWmrif27306860 = -873255431;    long tywbKWmrif92924545 = -403495391;    long tywbKWmrif61182835 = -602721022;    long tywbKWmrif70168588 = -818900331;    long tywbKWmrif64795014 = -569877791;    long tywbKWmrif70276980 = -454459428;    long tywbKWmrif52572773 = -644522642;    long tywbKWmrif55395706 = -762895427;    long tywbKWmrif60203551 = -93215159;    long tywbKWmrif32354270 = -459131663;    long tywbKWmrif70792583 = -495126293;    long tywbKWmrif58249651 = -184762985;    long tywbKWmrif80195557 = -685428899;    long tywbKWmrif86402798 = -574249563;    long tywbKWmrif26436142 = -743379230;    long tywbKWmrif24284142 = -333371513;    long tywbKWmrif47044241 = -115843443;    long tywbKWmrif15495449 = -507726090;    long tywbKWmrif79346740 = -684287852;    long tywbKWmrif10172547 = -205984702;    long tywbKWmrif67067150 = -298121908;    long tywbKWmrif15139021 = -443722181;    long tywbKWmrif42069713 = -425701105;    long tywbKWmrif34332030 = -961823125;    long tywbKWmrif45694351 = -382522816;     tywbKWmrif44840724 = tywbKWmrif13389678;     tywbKWmrif13389678 = tywbKWmrif6115127;     tywbKWmrif6115127 = tywbKWmrif83839413;     tywbKWmrif83839413 = tywbKWmrif75817652;     tywbKWmrif75817652 = tywbKWmrif83760393;     tywbKWmrif83760393 = tywbKWmrif77727884;     tywbKWmrif77727884 = tywbKWmrif74165745;     tywbKWmrif74165745 = tywbKWmrif76658994;     tywbKWmrif76658994 = tywbKWmrif52000643;     tywbKWmrif52000643 = tywbKWmrif8459166;     tywbKWmrif8459166 = tywbKWmrif61135991;     tywbKWmrif61135991 = tywbKWmrif22631525;     tywbKWmrif22631525 = tywbKWmrif88696575;     tywbKWmrif88696575 = tywbKWmrif73137278;     tywbKWmrif73137278 = tywbKWmrif60895909;     tywbKWmrif60895909 = tywbKWmrif43597484;     tywbKWmrif43597484 = tywbKWmrif29872162;     tywbKWmrif29872162 = tywbKWmrif65525398;     tywbKWmrif65525398 = tywbKWmrif5767005;     tywbKWmrif5767005 = tywbKWmrif51518222;     tywbKWmrif51518222 = tywbKWmrif32675866;     tywbKWmrif32675866 = tywbKWmrif2386045;     tywbKWmrif2386045 = tywbKWmrif34037291;     tywbKWmrif34037291 = tywbKWmrif71927586;     tywbKWmrif71927586 = tywbKWmrif98970568;     tywbKWmrif98970568 = tywbKWmrif50595519;     tywbKWmrif50595519 = tywbKWmrif5349659;     tywbKWmrif5349659 = tywbKWmrif65093403;     tywbKWmrif65093403 = tywbKWmrif78977387;     tywbKWmrif78977387 = tywbKWmrif45129462;     tywbKWmrif45129462 = tywbKWmrif90284815;     tywbKWmrif90284815 = tywbKWmrif10137709;     tywbKWmrif10137709 = tywbKWmrif11259664;     tywbKWmrif11259664 = tywbKWmrif38601000;     tywbKWmrif38601000 = tywbKWmrif35287774;     tywbKWmrif35287774 = tywbKWmrif19122077;     tywbKWmrif19122077 = tywbKWmrif27407276;     tywbKWmrif27407276 = tywbKWmrif56193824;     tywbKWmrif56193824 = tywbKWmrif43337421;     tywbKWmrif43337421 = tywbKWmrif39445376;     tywbKWmrif39445376 = tywbKWmrif24211363;     tywbKWmrif24211363 = tywbKWmrif39751320;     tywbKWmrif39751320 = tywbKWmrif41203210;     tywbKWmrif41203210 = tywbKWmrif63868702;     tywbKWmrif63868702 = tywbKWmrif7132573;     tywbKWmrif7132573 = tywbKWmrif28693588;     tywbKWmrif28693588 = tywbKWmrif98022745;     tywbKWmrif98022745 = tywbKWmrif49953952;     tywbKWmrif49953952 = tywbKWmrif4889852;     tywbKWmrif4889852 = tywbKWmrif46623118;     tywbKWmrif46623118 = tywbKWmrif74336879;     tywbKWmrif74336879 = tywbKWmrif32035164;     tywbKWmrif32035164 = tywbKWmrif29942152;     tywbKWmrif29942152 = tywbKWmrif24856866;     tywbKWmrif24856866 = tywbKWmrif12164859;     tywbKWmrif12164859 = tywbKWmrif11003633;     tywbKWmrif11003633 = tywbKWmrif72077836;     tywbKWmrif72077836 = tywbKWmrif11911827;     tywbKWmrif11911827 = tywbKWmrif76847084;     tywbKWmrif76847084 = tywbKWmrif33164875;     tywbKWmrif33164875 = tywbKWmrif72378226;     tywbKWmrif72378226 = tywbKWmrif9072343;     tywbKWmrif9072343 = tywbKWmrif97681606;     tywbKWmrif97681606 = tywbKWmrif6871181;     tywbKWmrif6871181 = tywbKWmrif18174351;     tywbKWmrif18174351 = tywbKWmrif50998283;     tywbKWmrif50998283 = tywbKWmrif11371861;     tywbKWmrif11371861 = tywbKWmrif50095576;     tywbKWmrif50095576 = tywbKWmrif37849504;     tywbKWmrif37849504 = tywbKWmrif41773832;     tywbKWmrif41773832 = tywbKWmrif16190208;     tywbKWmrif16190208 = tywbKWmrif73678338;     tywbKWmrif73678338 = tywbKWmrif22187978;     tywbKWmrif22187978 = tywbKWmrif66321629;     tywbKWmrif66321629 = tywbKWmrif27306860;     tywbKWmrif27306860 = tywbKWmrif92924545;     tywbKWmrif92924545 = tywbKWmrif61182835;     tywbKWmrif61182835 = tywbKWmrif70168588;     tywbKWmrif70168588 = tywbKWmrif64795014;     tywbKWmrif64795014 = tywbKWmrif70276980;     tywbKWmrif70276980 = tywbKWmrif52572773;     tywbKWmrif52572773 = tywbKWmrif55395706;     tywbKWmrif55395706 = tywbKWmrif60203551;     tywbKWmrif60203551 = tywbKWmrif32354270;     tywbKWmrif32354270 = tywbKWmrif70792583;     tywbKWmrif70792583 = tywbKWmrif58249651;     tywbKWmrif58249651 = tywbKWmrif80195557;     tywbKWmrif80195557 = tywbKWmrif86402798;     tywbKWmrif86402798 = tywbKWmrif26436142;     tywbKWmrif26436142 = tywbKWmrif24284142;     tywbKWmrif24284142 = tywbKWmrif47044241;     tywbKWmrif47044241 = tywbKWmrif15495449;     tywbKWmrif15495449 = tywbKWmrif79346740;     tywbKWmrif79346740 = tywbKWmrif10172547;     tywbKWmrif10172547 = tywbKWmrif67067150;     tywbKWmrif67067150 = tywbKWmrif15139021;     tywbKWmrif15139021 = tywbKWmrif42069713;     tywbKWmrif42069713 = tywbKWmrif34332030;     tywbKWmrif34332030 = tywbKWmrif45694351;     tywbKWmrif45694351 = tywbKWmrif44840724;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void UFqlxZKCom43336490() {     int yxqdBZEOwn34960561 = -313803158;    int yxqdBZEOwn35087059 = -126982301;    int yxqdBZEOwn2921038 = -566724208;    int yxqdBZEOwn42417849 = -873563727;    int yxqdBZEOwn97714490 = -715402554;    int yxqdBZEOwn99352230 = -257303912;    int yxqdBZEOwn40938659 = -334837989;    int yxqdBZEOwn96258359 = -232306011;    int yxqdBZEOwn83210845 = -21712958;    int yxqdBZEOwn52895827 = -233631330;    int yxqdBZEOwn4931591 = -156248791;    int yxqdBZEOwn10177176 = -767037724;    int yxqdBZEOwn92830570 = -212892612;    int yxqdBZEOwn80959649 = -825028992;    int yxqdBZEOwn16383759 = -275562659;    int yxqdBZEOwn59640198 = -146662411;    int yxqdBZEOwn43412424 = -894152095;    int yxqdBZEOwn74228407 = -202364216;    int yxqdBZEOwn46868060 = -265791995;    int yxqdBZEOwn45165016 = -763038194;    int yxqdBZEOwn19110049 = -855719775;    int yxqdBZEOwn9053714 = 35741467;    int yxqdBZEOwn72502859 = -490758074;    int yxqdBZEOwn85608496 = 31308886;    int yxqdBZEOwn47255464 = -820985808;    int yxqdBZEOwn34335610 = -842054162;    int yxqdBZEOwn42784436 = 47313643;    int yxqdBZEOwn63923558 = -631209470;    int yxqdBZEOwn38980848 = -76099621;    int yxqdBZEOwn2856338 = -558034497;    int yxqdBZEOwn82005544 = -479913547;    int yxqdBZEOwn74375586 = -233243028;    int yxqdBZEOwn4559173 = -106810517;    int yxqdBZEOwn35381146 = -598916282;    int yxqdBZEOwn56555572 = -814381617;    int yxqdBZEOwn31346970 = -800287364;    int yxqdBZEOwn31297014 = -564367643;    int yxqdBZEOwn21682239 = -385118078;    int yxqdBZEOwn2040438 = -352180605;    int yxqdBZEOwn59722455 = -493004503;    int yxqdBZEOwn41000717 = -22330708;    int yxqdBZEOwn64553487 = -475858174;    int yxqdBZEOwn59851521 = -752230473;    int yxqdBZEOwn31097049 = -543666921;    int yxqdBZEOwn39851172 = -406615243;    int yxqdBZEOwn67999534 = -476571796;    int yxqdBZEOwn36814671 = -533278194;    int yxqdBZEOwn63792786 = -883252618;    int yxqdBZEOwn96530995 = -199160205;    int yxqdBZEOwn54215680 = -718636323;    int yxqdBZEOwn89248011 = -402006122;    int yxqdBZEOwn32657244 = -617600057;    int yxqdBZEOwn56935967 = -859740865;    int yxqdBZEOwn93099484 = -574687376;    int yxqdBZEOwn24226441 = 57966622;    int yxqdBZEOwn25906848 = -249544626;    int yxqdBZEOwn62584199 = -636224228;    int yxqdBZEOwn17312542 = -498033094;    int yxqdBZEOwn95162384 = 47422080;    int yxqdBZEOwn63378880 = -873348392;    int yxqdBZEOwn56567794 = -204617555;    int yxqdBZEOwn77015100 = -703628519;    int yxqdBZEOwn57277511 = -56206391;    int yxqdBZEOwn80354508 = -463678462;    int yxqdBZEOwn70890283 = -753717783;    int yxqdBZEOwn30556004 = -923005763;    int yxqdBZEOwn5618004 = -560227208;    int yxqdBZEOwn57449425 = -613976331;    int yxqdBZEOwn24404078 = 89352624;    int yxqdBZEOwn85036788 = -475275295;    int yxqdBZEOwn28343185 = -582294769;    int yxqdBZEOwn21730185 = -409034017;    int yxqdBZEOwn72187970 = -850183612;    int yxqdBZEOwn87145604 = -772787492;    int yxqdBZEOwn4164299 = -640707487;    int yxqdBZEOwn54556562 = -279861601;    int yxqdBZEOwn49202192 = -212028061;    int yxqdBZEOwn41405811 = -947091153;    int yxqdBZEOwn45757324 = -562075872;    int yxqdBZEOwn79255929 = -244414012;    int yxqdBZEOwn97520939 = -208775969;    int yxqdBZEOwn78991650 = -69433739;    int yxqdBZEOwn67392563 = -332049266;    int yxqdBZEOwn84765167 = -357463299;    int yxqdBZEOwn13608326 = -56028376;    int yxqdBZEOwn49348300 = -862313490;    int yxqdBZEOwn17439620 = -373502163;    int yxqdBZEOwn11459688 = -532123141;    int yxqdBZEOwn11154705 = -556882904;    int yxqdBZEOwn30648724 = -464836992;    int yxqdBZEOwn68762771 = -64063137;    int yxqdBZEOwn13984473 = 33665451;    int yxqdBZEOwn26519854 = -332540158;    int yxqdBZEOwn38661558 = -478832214;    int yxqdBZEOwn3154661 = -188386948;    int yxqdBZEOwn63985617 = -318702189;    int yxqdBZEOwn7275976 = -319651784;    int yxqdBZEOwn79497013 = -188552012;    int yxqdBZEOwn60206766 = -789949139;    int yxqdBZEOwn9295168 = -313803158;     yxqdBZEOwn34960561 = yxqdBZEOwn35087059;     yxqdBZEOwn35087059 = yxqdBZEOwn2921038;     yxqdBZEOwn2921038 = yxqdBZEOwn42417849;     yxqdBZEOwn42417849 = yxqdBZEOwn97714490;     yxqdBZEOwn97714490 = yxqdBZEOwn99352230;     yxqdBZEOwn99352230 = yxqdBZEOwn40938659;     yxqdBZEOwn40938659 = yxqdBZEOwn96258359;     yxqdBZEOwn96258359 = yxqdBZEOwn83210845;     yxqdBZEOwn83210845 = yxqdBZEOwn52895827;     yxqdBZEOwn52895827 = yxqdBZEOwn4931591;     yxqdBZEOwn4931591 = yxqdBZEOwn10177176;     yxqdBZEOwn10177176 = yxqdBZEOwn92830570;     yxqdBZEOwn92830570 = yxqdBZEOwn80959649;     yxqdBZEOwn80959649 = yxqdBZEOwn16383759;     yxqdBZEOwn16383759 = yxqdBZEOwn59640198;     yxqdBZEOwn59640198 = yxqdBZEOwn43412424;     yxqdBZEOwn43412424 = yxqdBZEOwn74228407;     yxqdBZEOwn74228407 = yxqdBZEOwn46868060;     yxqdBZEOwn46868060 = yxqdBZEOwn45165016;     yxqdBZEOwn45165016 = yxqdBZEOwn19110049;     yxqdBZEOwn19110049 = yxqdBZEOwn9053714;     yxqdBZEOwn9053714 = yxqdBZEOwn72502859;     yxqdBZEOwn72502859 = yxqdBZEOwn85608496;     yxqdBZEOwn85608496 = yxqdBZEOwn47255464;     yxqdBZEOwn47255464 = yxqdBZEOwn34335610;     yxqdBZEOwn34335610 = yxqdBZEOwn42784436;     yxqdBZEOwn42784436 = yxqdBZEOwn63923558;     yxqdBZEOwn63923558 = yxqdBZEOwn38980848;     yxqdBZEOwn38980848 = yxqdBZEOwn2856338;     yxqdBZEOwn2856338 = yxqdBZEOwn82005544;     yxqdBZEOwn82005544 = yxqdBZEOwn74375586;     yxqdBZEOwn74375586 = yxqdBZEOwn4559173;     yxqdBZEOwn4559173 = yxqdBZEOwn35381146;     yxqdBZEOwn35381146 = yxqdBZEOwn56555572;     yxqdBZEOwn56555572 = yxqdBZEOwn31346970;     yxqdBZEOwn31346970 = yxqdBZEOwn31297014;     yxqdBZEOwn31297014 = yxqdBZEOwn21682239;     yxqdBZEOwn21682239 = yxqdBZEOwn2040438;     yxqdBZEOwn2040438 = yxqdBZEOwn59722455;     yxqdBZEOwn59722455 = yxqdBZEOwn41000717;     yxqdBZEOwn41000717 = yxqdBZEOwn64553487;     yxqdBZEOwn64553487 = yxqdBZEOwn59851521;     yxqdBZEOwn59851521 = yxqdBZEOwn31097049;     yxqdBZEOwn31097049 = yxqdBZEOwn39851172;     yxqdBZEOwn39851172 = yxqdBZEOwn67999534;     yxqdBZEOwn67999534 = yxqdBZEOwn36814671;     yxqdBZEOwn36814671 = yxqdBZEOwn63792786;     yxqdBZEOwn63792786 = yxqdBZEOwn96530995;     yxqdBZEOwn96530995 = yxqdBZEOwn54215680;     yxqdBZEOwn54215680 = yxqdBZEOwn89248011;     yxqdBZEOwn89248011 = yxqdBZEOwn32657244;     yxqdBZEOwn32657244 = yxqdBZEOwn56935967;     yxqdBZEOwn56935967 = yxqdBZEOwn93099484;     yxqdBZEOwn93099484 = yxqdBZEOwn24226441;     yxqdBZEOwn24226441 = yxqdBZEOwn25906848;     yxqdBZEOwn25906848 = yxqdBZEOwn62584199;     yxqdBZEOwn62584199 = yxqdBZEOwn17312542;     yxqdBZEOwn17312542 = yxqdBZEOwn95162384;     yxqdBZEOwn95162384 = yxqdBZEOwn63378880;     yxqdBZEOwn63378880 = yxqdBZEOwn56567794;     yxqdBZEOwn56567794 = yxqdBZEOwn77015100;     yxqdBZEOwn77015100 = yxqdBZEOwn57277511;     yxqdBZEOwn57277511 = yxqdBZEOwn80354508;     yxqdBZEOwn80354508 = yxqdBZEOwn70890283;     yxqdBZEOwn70890283 = yxqdBZEOwn30556004;     yxqdBZEOwn30556004 = yxqdBZEOwn5618004;     yxqdBZEOwn5618004 = yxqdBZEOwn57449425;     yxqdBZEOwn57449425 = yxqdBZEOwn24404078;     yxqdBZEOwn24404078 = yxqdBZEOwn85036788;     yxqdBZEOwn85036788 = yxqdBZEOwn28343185;     yxqdBZEOwn28343185 = yxqdBZEOwn21730185;     yxqdBZEOwn21730185 = yxqdBZEOwn72187970;     yxqdBZEOwn72187970 = yxqdBZEOwn87145604;     yxqdBZEOwn87145604 = yxqdBZEOwn4164299;     yxqdBZEOwn4164299 = yxqdBZEOwn54556562;     yxqdBZEOwn54556562 = yxqdBZEOwn49202192;     yxqdBZEOwn49202192 = yxqdBZEOwn41405811;     yxqdBZEOwn41405811 = yxqdBZEOwn45757324;     yxqdBZEOwn45757324 = yxqdBZEOwn79255929;     yxqdBZEOwn79255929 = yxqdBZEOwn97520939;     yxqdBZEOwn97520939 = yxqdBZEOwn78991650;     yxqdBZEOwn78991650 = yxqdBZEOwn67392563;     yxqdBZEOwn67392563 = yxqdBZEOwn84765167;     yxqdBZEOwn84765167 = yxqdBZEOwn13608326;     yxqdBZEOwn13608326 = yxqdBZEOwn49348300;     yxqdBZEOwn49348300 = yxqdBZEOwn17439620;     yxqdBZEOwn17439620 = yxqdBZEOwn11459688;     yxqdBZEOwn11459688 = yxqdBZEOwn11154705;     yxqdBZEOwn11154705 = yxqdBZEOwn30648724;     yxqdBZEOwn30648724 = yxqdBZEOwn68762771;     yxqdBZEOwn68762771 = yxqdBZEOwn13984473;     yxqdBZEOwn13984473 = yxqdBZEOwn26519854;     yxqdBZEOwn26519854 = yxqdBZEOwn38661558;     yxqdBZEOwn38661558 = yxqdBZEOwn3154661;     yxqdBZEOwn3154661 = yxqdBZEOwn63985617;     yxqdBZEOwn63985617 = yxqdBZEOwn7275976;     yxqdBZEOwn7275976 = yxqdBZEOwn79497013;     yxqdBZEOwn79497013 = yxqdBZEOwn60206766;     yxqdBZEOwn60206766 = yxqdBZEOwn9295168;     yxqdBZEOwn9295168 = yxqdBZEOwn34960561;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void bfxLGaUMew79981464() {     int UrCFXYDRGO57347678 = 51792878;    int UrCFXYDRGO19434560 = -75525355;    int UrCFXYDRGO31690316 = -806378052;    int UrCFXYDRGO57424537 = -879971259;    int UrCFXYDRGO95888744 = -206459555;    int UrCFXYDRGO14235348 = -117912289;    int UrCFXYDRGO33094398 = -156825295;    int UrCFXYDRGO71892218 = -702902655;    int UrCFXYDRGO80373976 = 94091002;    int UrCFXYDRGO44659411 = 23627337;    int UrCFXYDRGO42473450 = -152873192;    int UrCFXYDRGO66080125 = 82216983;    int UrCFXYDRGO59838751 = -831609932;    int UrCFXYDRGO23574402 = -252737749;    int UrCFXYDRGO53119036 = 96959628;    int UrCFXYDRGO3896112 = -528329954;    int UrCFXYDRGO93235775 = -71431915;    int UrCFXYDRGO80204824 = -654106907;    int UrCFXYDRGO88149690 = -400894120;    int UrCFXYDRGO23681299 = 84327352;    int UrCFXYDRGO19993156 = -847207083;    int UrCFXYDRGO72868931 = -469024847;    int UrCFXYDRGO75796183 = -666838666;    int UrCFXYDRGO12108284 = -532683972;    int UrCFXYDRGO82795711 = -442544932;    int UrCFXYDRGO22638605 = -185948386;    int UrCFXYDRGO89873856 = -810272849;    int UrCFXYDRGO69835008 = -419663924;    int UrCFXYDRGO45873408 = -420356740;    int UrCFXYDRGO12013517 = -478330363;    int UrCFXYDRGO26296349 = -561229699;    int UrCFXYDRGO31916778 = -885314383;    int UrCFXYDRGO85597843 = -636154012;    int UrCFXYDRGO94769832 = -923043132;    int UrCFXYDRGO32784937 = -878138039;    int UrCFXYDRGO73039839 = -15682741;    int UrCFXYDRGO24736726 = -297315594;    int UrCFXYDRGO75308339 = -252743550;    int UrCFXYDRGO50348569 = -753226637;    int UrCFXYDRGO79908169 = -629228533;    int UrCFXYDRGO69758088 = -525508374;    int UrCFXYDRGO53061878 = -233766865;    int UrCFXYDRGO65401713 = -639761057;    int UrCFXYDRGO30541169 = -541030570;    int UrCFXYDRGO7834439 = -215758721;    int UrCFXYDRGO76099816 = -658800892;    int UrCFXYDRGO49112068 = -11688447;    int UrCFXYDRGO8391461 = -639787609;    int UrCFXYDRGO90990900 = -148876903;    int UrCFXYDRGO51299426 = -860656582;    int UrCFXYDRGO98117227 = -757082399;    int UrCFXYDRGO6508501 = 51580661;    int UrCFXYDRGO35250370 = -531652096;    int UrCFXYDRGO53386030 = -850368185;    int UrCFXYDRGO59988308 = -82737493;    int UrCFXYDRGO84478746 = -479182275;    int UrCFXYDRGO43638377 = -408686690;    int UrCFXYDRGO19582033 = -173694081;    int UrCFXYDRGO74628826 = -337426327;    int UrCFXYDRGO73250139 = 79488830;    int UrCFXYDRGO24361491 = -307639440;    int UrCFXYDRGO63259389 = -737161372;    int UrCFXYDRGO26018810 = -182545916;    int UrCFXYDRGO68360460 = -427578635;    int UrCFXYDRGO18363063 = -415142964;    int UrCFXYDRGO10556673 = -267558809;    int UrCFXYDRGO80482282 = -281629006;    int UrCFXYDRGO65068918 = -908566801;    int UrCFXYDRGO90789465 = -374599711;    int UrCFXYDRGO80079196 = -887357632;    int UrCFXYDRGO79159385 = -131014360;    int UrCFXYDRGO17927436 = -818688365;    int UrCFXYDRGO29856255 = -900880271;    int UrCFXYDRGO8241521 = -771665588;    int UrCFXYDRGO53923211 = -390164274;    int UrCFXYDRGO66931278 = -513440219;    int UrCFXYDRGO7467219 = -829263790;    int UrCFXYDRGO45255014 = -25808096;    int UrCFXYDRGO4273845 = -216925251;    int UrCFXYDRGO6695895 = -783744041;    int UrCFXYDRGO73526537 = -74259940;    int UrCFXYDRGO81482396 = -70485241;    int UrCFXYDRGO78844108 = -170787021;    int UrCFXYDRGO94573982 = -559700159;    int UrCFXYDRGO13896289 = -721247965;    int UrCFXYDRGO19787849 = -512810360;    int UrCFXYDRGO96666407 = -253662288;    int UrCFXYDRGO32211813 = -785785828;    int UrCFXYDRGO34781525 = -740305639;    int UrCFXYDRGO48306190 = -298955764;    int UrCFXYDRGO29401463 = -606996051;    int UrCFXYDRGO5154693 = -23621514;    int UrCFXYDRGO679513 = -915317223;    int UrCFXYDRGO77098429 = -732715468;    int UrCFXYDRGO55546679 = -221589093;    int UrCFXYDRGO6498699 = -788347003;    int UrCFXYDRGO27043069 = 48779050;    int UrCFXYDRGO97041253 = -112182423;    int UrCFXYDRGO12178107 = -25887607;    int UrCFXYDRGO97277765 = 51792878;     UrCFXYDRGO57347678 = UrCFXYDRGO19434560;     UrCFXYDRGO19434560 = UrCFXYDRGO31690316;     UrCFXYDRGO31690316 = UrCFXYDRGO57424537;     UrCFXYDRGO57424537 = UrCFXYDRGO95888744;     UrCFXYDRGO95888744 = UrCFXYDRGO14235348;     UrCFXYDRGO14235348 = UrCFXYDRGO33094398;     UrCFXYDRGO33094398 = UrCFXYDRGO71892218;     UrCFXYDRGO71892218 = UrCFXYDRGO80373976;     UrCFXYDRGO80373976 = UrCFXYDRGO44659411;     UrCFXYDRGO44659411 = UrCFXYDRGO42473450;     UrCFXYDRGO42473450 = UrCFXYDRGO66080125;     UrCFXYDRGO66080125 = UrCFXYDRGO59838751;     UrCFXYDRGO59838751 = UrCFXYDRGO23574402;     UrCFXYDRGO23574402 = UrCFXYDRGO53119036;     UrCFXYDRGO53119036 = UrCFXYDRGO3896112;     UrCFXYDRGO3896112 = UrCFXYDRGO93235775;     UrCFXYDRGO93235775 = UrCFXYDRGO80204824;     UrCFXYDRGO80204824 = UrCFXYDRGO88149690;     UrCFXYDRGO88149690 = UrCFXYDRGO23681299;     UrCFXYDRGO23681299 = UrCFXYDRGO19993156;     UrCFXYDRGO19993156 = UrCFXYDRGO72868931;     UrCFXYDRGO72868931 = UrCFXYDRGO75796183;     UrCFXYDRGO75796183 = UrCFXYDRGO12108284;     UrCFXYDRGO12108284 = UrCFXYDRGO82795711;     UrCFXYDRGO82795711 = UrCFXYDRGO22638605;     UrCFXYDRGO22638605 = UrCFXYDRGO89873856;     UrCFXYDRGO89873856 = UrCFXYDRGO69835008;     UrCFXYDRGO69835008 = UrCFXYDRGO45873408;     UrCFXYDRGO45873408 = UrCFXYDRGO12013517;     UrCFXYDRGO12013517 = UrCFXYDRGO26296349;     UrCFXYDRGO26296349 = UrCFXYDRGO31916778;     UrCFXYDRGO31916778 = UrCFXYDRGO85597843;     UrCFXYDRGO85597843 = UrCFXYDRGO94769832;     UrCFXYDRGO94769832 = UrCFXYDRGO32784937;     UrCFXYDRGO32784937 = UrCFXYDRGO73039839;     UrCFXYDRGO73039839 = UrCFXYDRGO24736726;     UrCFXYDRGO24736726 = UrCFXYDRGO75308339;     UrCFXYDRGO75308339 = UrCFXYDRGO50348569;     UrCFXYDRGO50348569 = UrCFXYDRGO79908169;     UrCFXYDRGO79908169 = UrCFXYDRGO69758088;     UrCFXYDRGO69758088 = UrCFXYDRGO53061878;     UrCFXYDRGO53061878 = UrCFXYDRGO65401713;     UrCFXYDRGO65401713 = UrCFXYDRGO30541169;     UrCFXYDRGO30541169 = UrCFXYDRGO7834439;     UrCFXYDRGO7834439 = UrCFXYDRGO76099816;     UrCFXYDRGO76099816 = UrCFXYDRGO49112068;     UrCFXYDRGO49112068 = UrCFXYDRGO8391461;     UrCFXYDRGO8391461 = UrCFXYDRGO90990900;     UrCFXYDRGO90990900 = UrCFXYDRGO51299426;     UrCFXYDRGO51299426 = UrCFXYDRGO98117227;     UrCFXYDRGO98117227 = UrCFXYDRGO6508501;     UrCFXYDRGO6508501 = UrCFXYDRGO35250370;     UrCFXYDRGO35250370 = UrCFXYDRGO53386030;     UrCFXYDRGO53386030 = UrCFXYDRGO59988308;     UrCFXYDRGO59988308 = UrCFXYDRGO84478746;     UrCFXYDRGO84478746 = UrCFXYDRGO43638377;     UrCFXYDRGO43638377 = UrCFXYDRGO19582033;     UrCFXYDRGO19582033 = UrCFXYDRGO74628826;     UrCFXYDRGO74628826 = UrCFXYDRGO73250139;     UrCFXYDRGO73250139 = UrCFXYDRGO24361491;     UrCFXYDRGO24361491 = UrCFXYDRGO63259389;     UrCFXYDRGO63259389 = UrCFXYDRGO26018810;     UrCFXYDRGO26018810 = UrCFXYDRGO68360460;     UrCFXYDRGO68360460 = UrCFXYDRGO18363063;     UrCFXYDRGO18363063 = UrCFXYDRGO10556673;     UrCFXYDRGO10556673 = UrCFXYDRGO80482282;     UrCFXYDRGO80482282 = UrCFXYDRGO65068918;     UrCFXYDRGO65068918 = UrCFXYDRGO90789465;     UrCFXYDRGO90789465 = UrCFXYDRGO80079196;     UrCFXYDRGO80079196 = UrCFXYDRGO79159385;     UrCFXYDRGO79159385 = UrCFXYDRGO17927436;     UrCFXYDRGO17927436 = UrCFXYDRGO29856255;     UrCFXYDRGO29856255 = UrCFXYDRGO8241521;     UrCFXYDRGO8241521 = UrCFXYDRGO53923211;     UrCFXYDRGO53923211 = UrCFXYDRGO66931278;     UrCFXYDRGO66931278 = UrCFXYDRGO7467219;     UrCFXYDRGO7467219 = UrCFXYDRGO45255014;     UrCFXYDRGO45255014 = UrCFXYDRGO4273845;     UrCFXYDRGO4273845 = UrCFXYDRGO6695895;     UrCFXYDRGO6695895 = UrCFXYDRGO73526537;     UrCFXYDRGO73526537 = UrCFXYDRGO81482396;     UrCFXYDRGO81482396 = UrCFXYDRGO78844108;     UrCFXYDRGO78844108 = UrCFXYDRGO94573982;     UrCFXYDRGO94573982 = UrCFXYDRGO13896289;     UrCFXYDRGO13896289 = UrCFXYDRGO19787849;     UrCFXYDRGO19787849 = UrCFXYDRGO96666407;     UrCFXYDRGO96666407 = UrCFXYDRGO32211813;     UrCFXYDRGO32211813 = UrCFXYDRGO34781525;     UrCFXYDRGO34781525 = UrCFXYDRGO48306190;     UrCFXYDRGO48306190 = UrCFXYDRGO29401463;     UrCFXYDRGO29401463 = UrCFXYDRGO5154693;     UrCFXYDRGO5154693 = UrCFXYDRGO679513;     UrCFXYDRGO679513 = UrCFXYDRGO77098429;     UrCFXYDRGO77098429 = UrCFXYDRGO55546679;     UrCFXYDRGO55546679 = UrCFXYDRGO6498699;     UrCFXYDRGO6498699 = UrCFXYDRGO27043069;     UrCFXYDRGO27043069 = UrCFXYDRGO97041253;     UrCFXYDRGO97041253 = UrCFXYDRGO12178107;     UrCFXYDRGO12178107 = UrCFXYDRGO97277765;     UrCFXYDRGO97277765 = UrCFXYDRGO57347678;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void hRYgFTmaZy32658271() {     int lLFnzmmTju94267738 = -331989362;    int lLFnzmmTju63725377 = -196760710;    int lLFnzmmTju99714633 = 48224412;    int lLFnzmmTju81557697 = -15903757;    int lLFnzmmTju48827857 = -727361863;    int lLFnzmmTju36402383 = -440463787;    int lLFnzmmTju25276900 = -589757451;    int lLFnzmmTju21912079 = -609486805;    int lLFnzmmTju29444708 = -318831217;    int lLFnzmmTju17319676 = -425435586;    int lLFnzmmTju67234331 = -846829953;    int lLFnzmmTju39279522 = -523755492;    int lLFnzmmTju78428429 = -650387840;    int lLFnzmmTju55353566 = -685524411;    int lLFnzmmTju38124933 = -80484135;    int lLFnzmmTju32816407 = -865180452;    int lLFnzmmTju57039140 = -146255394;    int lLFnzmmTju90171714 = -153761056;    int lLFnzmmTju29416329 = -441910657;    int lLFnzmmTju48452568 = 43223400;    int lLFnzmmTju7376181 = -269502670;    int lLFnzmmTju56132958 = -149644720;    int lLFnzmmTju54662122 = -403984376;    int lLFnzmmTju49377761 = -987002878;    int lLFnzmmTju20871369 = -848486175;    int lLFnzmmTju45961024 = -276523213;    int lLFnzmmTju39319680 = -37574843;    int lLFnzmmTju79272440 = -249554938;    int lLFnzmmTju71945813 = -723106950;    int lLFnzmmTju85749622 = 41591723;    int lLFnzmmTju93769771 = -24431907;    int lLFnzmmTju32539772 = -604191525;    int lLFnzmmTju11234032 = -995331799;    int lLFnzmmTju24763641 = -753328334;    int lLFnzmmTju96153394 = -214936617;    int lLFnzmmTju16707102 = -491219994;    int lLFnzmmTju58691331 = -15134228;    int lLFnzmmTju15116137 = -131791789;    int lLFnzmmTju62408135 = -469248162;    int lLFnzmmTju663469 = -536979623;    int lLFnzmmTju49883436 = 5583001;    int lLFnzmmTju34327219 = -639370368;    int lLFnzmmTju31922727 = -23023673;    int lLFnzmmTju88893822 = -480267364;    int lLFnzmmTju30823812 = -514965289;    int lLFnzmmTju88773730 = -292162193;    int lLFnzmmTju26686543 = -157713117;    int lLFnzmmTju54493299 = -715747702;    int lLFnzmmTju10881126 = -164561548;    int lLFnzmmTju98910360 = 4568867;    int lLFnzmmTju92789932 = -711075877;    int lLFnzmmTju65058357 = -918268460;    int lLFnzmmTju64254060 = -587585282;    int lLFnzmmTju60493567 = -224440308;    int lLFnzmmTju25282090 = -673075559;    int lLFnzmmTju38134781 = -82344642;    int lLFnzmmTju9063255 = -792776334;    int lLFnzmmTju50336873 = 35227289;    int lLFnzmmTju60686328 = -167417583;    int lLFnzmmTju2866833 = -350838650;    int lLFnzmmTju97082703 = -302888945;    int lLFnzmmTju46004460 = -240202513;    int lLFnzmmTju49966265 = -886379856;    int lLFnzmmTju43695085 = -260422941;    int lLFnzmmTju23549905 = -301003680;    int lLFnzmmTju34694560 = -142638429;    int lLFnzmmTju28045490 = -528423694;    int lLFnzmmTju53664789 = -897059506;    int lLFnzmmTju59200171 = -370587795;    int lLFnzmmTju21417831 = -589264141;    int lLFnzmmTju74125075 = -750046225;    int lLFnzmmTju41923004 = 85536395;    int lLFnzmmTju27763580 = -684512894;    int lLFnzmmTju28752861 = -904931034;    int lLFnzmmTju98569132 = -962359601;    int lLFnzmmTju73048961 = -630132302;    int lLFnzmmTju24210231 = -26621048;    int lLFnzmmTju65768299 = -923717013;    int lLFnzmmTju18553949 = -372037589;    int lLFnzmmTju32097639 = -456323982;    int lLFnzmmTju19274482 = -18810097;    int lLFnzmmTju84826380 = -321827142;    int lLFnzmmTju68391314 = 15006609;    int lLFnzmmTju73035452 = -627675818;    int lLFnzmmTju92959690 = -247332400;    int lLFnzmmTju28711414 = -106163447;    int lLFnzmmTju68285711 = 83393757;    int lLFnzmmTju50740465 = -670891492;    int lLFnzmmTju99481550 = 19747225;    int lLFnzmmTju58018614 = -32591975;    int lLFnzmmTju7643847 = -698443660;    int lLFnzmmTju8354459 = 49638482;    int lLFnzmmTju54429808 = -964374207;    int lLFnzmmTju59541302 = -18409513;    int lLFnzmmTju3580766 = -134090679;    int lLFnzmmTju3878976 = -754214486;    int lLFnzmmTju84360953 = -752990513;    int lLFnzmmTju88227642 = -762600732;    int lLFnzmmTju65343917 = -79263684;    int lLFnzmmTju96129252 = -331989362;     lLFnzmmTju94267738 = lLFnzmmTju63725377;     lLFnzmmTju63725377 = lLFnzmmTju99714633;     lLFnzmmTju99714633 = lLFnzmmTju81557697;     lLFnzmmTju81557697 = lLFnzmmTju48827857;     lLFnzmmTju48827857 = lLFnzmmTju36402383;     lLFnzmmTju36402383 = lLFnzmmTju25276900;     lLFnzmmTju25276900 = lLFnzmmTju21912079;     lLFnzmmTju21912079 = lLFnzmmTju29444708;     lLFnzmmTju29444708 = lLFnzmmTju17319676;     lLFnzmmTju17319676 = lLFnzmmTju67234331;     lLFnzmmTju67234331 = lLFnzmmTju39279522;     lLFnzmmTju39279522 = lLFnzmmTju78428429;     lLFnzmmTju78428429 = lLFnzmmTju55353566;     lLFnzmmTju55353566 = lLFnzmmTju38124933;     lLFnzmmTju38124933 = lLFnzmmTju32816407;     lLFnzmmTju32816407 = lLFnzmmTju57039140;     lLFnzmmTju57039140 = lLFnzmmTju90171714;     lLFnzmmTju90171714 = lLFnzmmTju29416329;     lLFnzmmTju29416329 = lLFnzmmTju48452568;     lLFnzmmTju48452568 = lLFnzmmTju7376181;     lLFnzmmTju7376181 = lLFnzmmTju56132958;     lLFnzmmTju56132958 = lLFnzmmTju54662122;     lLFnzmmTju54662122 = lLFnzmmTju49377761;     lLFnzmmTju49377761 = lLFnzmmTju20871369;     lLFnzmmTju20871369 = lLFnzmmTju45961024;     lLFnzmmTju45961024 = lLFnzmmTju39319680;     lLFnzmmTju39319680 = lLFnzmmTju79272440;     lLFnzmmTju79272440 = lLFnzmmTju71945813;     lLFnzmmTju71945813 = lLFnzmmTju85749622;     lLFnzmmTju85749622 = lLFnzmmTju93769771;     lLFnzmmTju93769771 = lLFnzmmTju32539772;     lLFnzmmTju32539772 = lLFnzmmTju11234032;     lLFnzmmTju11234032 = lLFnzmmTju24763641;     lLFnzmmTju24763641 = lLFnzmmTju96153394;     lLFnzmmTju96153394 = lLFnzmmTju16707102;     lLFnzmmTju16707102 = lLFnzmmTju58691331;     lLFnzmmTju58691331 = lLFnzmmTju15116137;     lLFnzmmTju15116137 = lLFnzmmTju62408135;     lLFnzmmTju62408135 = lLFnzmmTju663469;     lLFnzmmTju663469 = lLFnzmmTju49883436;     lLFnzmmTju49883436 = lLFnzmmTju34327219;     lLFnzmmTju34327219 = lLFnzmmTju31922727;     lLFnzmmTju31922727 = lLFnzmmTju88893822;     lLFnzmmTju88893822 = lLFnzmmTju30823812;     lLFnzmmTju30823812 = lLFnzmmTju88773730;     lLFnzmmTju88773730 = lLFnzmmTju26686543;     lLFnzmmTju26686543 = lLFnzmmTju54493299;     lLFnzmmTju54493299 = lLFnzmmTju10881126;     lLFnzmmTju10881126 = lLFnzmmTju98910360;     lLFnzmmTju98910360 = lLFnzmmTju92789932;     lLFnzmmTju92789932 = lLFnzmmTju65058357;     lLFnzmmTju65058357 = lLFnzmmTju64254060;     lLFnzmmTju64254060 = lLFnzmmTju60493567;     lLFnzmmTju60493567 = lLFnzmmTju25282090;     lLFnzmmTju25282090 = lLFnzmmTju38134781;     lLFnzmmTju38134781 = lLFnzmmTju9063255;     lLFnzmmTju9063255 = lLFnzmmTju50336873;     lLFnzmmTju50336873 = lLFnzmmTju60686328;     lLFnzmmTju60686328 = lLFnzmmTju2866833;     lLFnzmmTju2866833 = lLFnzmmTju97082703;     lLFnzmmTju97082703 = lLFnzmmTju46004460;     lLFnzmmTju46004460 = lLFnzmmTju49966265;     lLFnzmmTju49966265 = lLFnzmmTju43695085;     lLFnzmmTju43695085 = lLFnzmmTju23549905;     lLFnzmmTju23549905 = lLFnzmmTju34694560;     lLFnzmmTju34694560 = lLFnzmmTju28045490;     lLFnzmmTju28045490 = lLFnzmmTju53664789;     lLFnzmmTju53664789 = lLFnzmmTju59200171;     lLFnzmmTju59200171 = lLFnzmmTju21417831;     lLFnzmmTju21417831 = lLFnzmmTju74125075;     lLFnzmmTju74125075 = lLFnzmmTju41923004;     lLFnzmmTju41923004 = lLFnzmmTju27763580;     lLFnzmmTju27763580 = lLFnzmmTju28752861;     lLFnzmmTju28752861 = lLFnzmmTju98569132;     lLFnzmmTju98569132 = lLFnzmmTju73048961;     lLFnzmmTju73048961 = lLFnzmmTju24210231;     lLFnzmmTju24210231 = lLFnzmmTju65768299;     lLFnzmmTju65768299 = lLFnzmmTju18553949;     lLFnzmmTju18553949 = lLFnzmmTju32097639;     lLFnzmmTju32097639 = lLFnzmmTju19274482;     lLFnzmmTju19274482 = lLFnzmmTju84826380;     lLFnzmmTju84826380 = lLFnzmmTju68391314;     lLFnzmmTju68391314 = lLFnzmmTju73035452;     lLFnzmmTju73035452 = lLFnzmmTju92959690;     lLFnzmmTju92959690 = lLFnzmmTju28711414;     lLFnzmmTju28711414 = lLFnzmmTju68285711;     lLFnzmmTju68285711 = lLFnzmmTju50740465;     lLFnzmmTju50740465 = lLFnzmmTju99481550;     lLFnzmmTju99481550 = lLFnzmmTju58018614;     lLFnzmmTju58018614 = lLFnzmmTju7643847;     lLFnzmmTju7643847 = lLFnzmmTju8354459;     lLFnzmmTju8354459 = lLFnzmmTju54429808;     lLFnzmmTju54429808 = lLFnzmmTju59541302;     lLFnzmmTju59541302 = lLFnzmmTju3580766;     lLFnzmmTju3580766 = lLFnzmmTju3878976;     lLFnzmmTju3878976 = lLFnzmmTju84360953;     lLFnzmmTju84360953 = lLFnzmmTju88227642;     lLFnzmmTju88227642 = lLFnzmmTju65343917;     lLFnzmmTju65343917 = lLFnzmmTju96129252;     lLFnzmmTju96129252 = lLFnzmmTju94267738;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void VmYrZApxQD69303245() {     int fCsHKirTCx16654856 = 33606675;    int fCsHKirTCx48072877 = -145303765;    int fCsHKirTCx28483912 = -191429432;    int fCsHKirTCx96564385 = -22311289;    int fCsHKirTCx47002111 = -218418864;    int fCsHKirTCx51285500 = -301072165;    int fCsHKirTCx17432639 = -411744757;    int fCsHKirTCx97545937 = 19916550;    int fCsHKirTCx26607839 = -203027256;    int fCsHKirTCx9083261 = -168176919;    int fCsHKirTCx4776192 = -843454354;    int fCsHKirTCx95182470 = -774500786;    int fCsHKirTCx45436610 = -169105159;    int fCsHKirTCx97968318 = -113233168;    int fCsHKirTCx74860209 = -807961848;    int fCsHKirTCx77072319 = -146847995;    int fCsHKirTCx6862493 = -423535214;    int fCsHKirTCx96148131 = -605503747;    int fCsHKirTCx70697959 = -577012782;    int fCsHKirTCx26968851 = -209411053;    int fCsHKirTCx8259288 = -260989978;    int fCsHKirTCx19948176 = -654411033;    int fCsHKirTCx57955445 = -580064968;    int fCsHKirTCx75877548 = -450995735;    int fCsHKirTCx56411615 = -470045299;    int fCsHKirTCx34264019 = -720417437;    int fCsHKirTCx86409100 = -895161335;    int fCsHKirTCx85183890 = -38009392;    int fCsHKirTCx78838374 = 32635931;    int fCsHKirTCx94906802 = -978704143;    int fCsHKirTCx38060576 = -105748059;    int fCsHKirTCx90080962 = -156262880;    int fCsHKirTCx92272702 = -424675294;    int fCsHKirTCx84152327 = 22544816;    int fCsHKirTCx72382759 = -278693039;    int fCsHKirTCx58399971 = -806615371;    int fCsHKirTCx52131043 = -848082180;    int fCsHKirTCx68742237 = 582739;    int fCsHKirTCx10716266 = -870294194;    int fCsHKirTCx20849183 = -673203653;    int fCsHKirTCx78640806 = -497594665;    int fCsHKirTCx22835610 = -397279059;    int fCsHKirTCx37472919 = 89445744;    int fCsHKirTCx88337941 = -477631013;    int fCsHKirTCx98807078 = -324108767;    int fCsHKirTCx96874011 = -474391289;    int fCsHKirTCx38983940 = -736123370;    int fCsHKirTCx99091974 = -472282692;    int fCsHKirTCx5341031 = -114278246;    int fCsHKirTCx95994106 = -137451392;    int fCsHKirTCx1659150 = 33847846;    int fCsHKirTCx38909615 = -249087742;    int fCsHKirTCx42568463 = -259496512;    int fCsHKirTCx20780113 = -500121116;    int fCsHKirTCx61043958 = -813779675;    int fCsHKirTCx96706679 = -311982292;    int fCsHKirTCx90117432 = -565238797;    int fCsHKirTCx52606364 = -740433698;    int fCsHKirTCx40152770 = -552265990;    int fCsHKirTCx12738093 = -498001427;    int fCsHKirTCx64876399 = -405910830;    int fCsHKirTCx32248749 = -273735365;    int fCsHKirTCx18707564 = 87280619;    int fCsHKirTCx31701037 = -224323114;    int fCsHKirTCx71022684 = 37571139;    int fCsHKirTCx14695229 = -587191475;    int fCsHKirTCx2909769 = -249825492;    int fCsHKirTCx61284282 = -91649976;    int fCsHKirTCx25585559 = -834540129;    int fCsHKirTCx16460239 = 98653522;    int fCsHKirTCx24941276 = -298765816;    int fCsHKirTCx38120255 = -324117953;    int fCsHKirTCx85431865 = -735209553;    int fCsHKirTCx49848777 = -903809130;    int fCsHKirTCx48328045 = -711816389;    int fCsHKirTCx85423677 = -863710920;    int fCsHKirTCx82475257 = -643856777;    int fCsHKirTCx69617503 = -2433956;    int fCsHKirTCx77070469 = -26886969;    int fCsHKirTCx59537603 = -995654011;    int fCsHKirTCx95280078 = -984294068;    int fCsHKirTCx87317126 = -322878643;    int fCsHKirTCx79842859 = -923731146;    int fCsHKirTCx82844267 = -829912678;    int fCsHKirTCx93247653 = -912551989;    int fCsHKirTCx99150961 = -856660317;    int fCsHKirTCx47512499 = -896766368;    int fCsHKirTCx71492590 = -924554178;    int fCsHKirTCx23108370 = -163675510;    int fCsHKirTCx75676080 = -966710748;    int fCsHKirTCx68282539 = -141376574;    int fCsHKirTCx99524679 = -7648482;    int fCsHKirTCx28589468 = -447151272;    int fCsHKirTCx97978173 = -272292768;    int fCsHKirTCx55972783 = -167292824;    int fCsHKirTCx46392058 = -123859300;    int fCsHKirTCx4128047 = -384559679;    int fCsHKirTCx5771883 = -686231143;    int fCsHKirTCx17315258 = -415202152;    int fCsHKirTCx84111849 = 33606675;     fCsHKirTCx16654856 = fCsHKirTCx48072877;     fCsHKirTCx48072877 = fCsHKirTCx28483912;     fCsHKirTCx28483912 = fCsHKirTCx96564385;     fCsHKirTCx96564385 = fCsHKirTCx47002111;     fCsHKirTCx47002111 = fCsHKirTCx51285500;     fCsHKirTCx51285500 = fCsHKirTCx17432639;     fCsHKirTCx17432639 = fCsHKirTCx97545937;     fCsHKirTCx97545937 = fCsHKirTCx26607839;     fCsHKirTCx26607839 = fCsHKirTCx9083261;     fCsHKirTCx9083261 = fCsHKirTCx4776192;     fCsHKirTCx4776192 = fCsHKirTCx95182470;     fCsHKirTCx95182470 = fCsHKirTCx45436610;     fCsHKirTCx45436610 = fCsHKirTCx97968318;     fCsHKirTCx97968318 = fCsHKirTCx74860209;     fCsHKirTCx74860209 = fCsHKirTCx77072319;     fCsHKirTCx77072319 = fCsHKirTCx6862493;     fCsHKirTCx6862493 = fCsHKirTCx96148131;     fCsHKirTCx96148131 = fCsHKirTCx70697959;     fCsHKirTCx70697959 = fCsHKirTCx26968851;     fCsHKirTCx26968851 = fCsHKirTCx8259288;     fCsHKirTCx8259288 = fCsHKirTCx19948176;     fCsHKirTCx19948176 = fCsHKirTCx57955445;     fCsHKirTCx57955445 = fCsHKirTCx75877548;     fCsHKirTCx75877548 = fCsHKirTCx56411615;     fCsHKirTCx56411615 = fCsHKirTCx34264019;     fCsHKirTCx34264019 = fCsHKirTCx86409100;     fCsHKirTCx86409100 = fCsHKirTCx85183890;     fCsHKirTCx85183890 = fCsHKirTCx78838374;     fCsHKirTCx78838374 = fCsHKirTCx94906802;     fCsHKirTCx94906802 = fCsHKirTCx38060576;     fCsHKirTCx38060576 = fCsHKirTCx90080962;     fCsHKirTCx90080962 = fCsHKirTCx92272702;     fCsHKirTCx92272702 = fCsHKirTCx84152327;     fCsHKirTCx84152327 = fCsHKirTCx72382759;     fCsHKirTCx72382759 = fCsHKirTCx58399971;     fCsHKirTCx58399971 = fCsHKirTCx52131043;     fCsHKirTCx52131043 = fCsHKirTCx68742237;     fCsHKirTCx68742237 = fCsHKirTCx10716266;     fCsHKirTCx10716266 = fCsHKirTCx20849183;     fCsHKirTCx20849183 = fCsHKirTCx78640806;     fCsHKirTCx78640806 = fCsHKirTCx22835610;     fCsHKirTCx22835610 = fCsHKirTCx37472919;     fCsHKirTCx37472919 = fCsHKirTCx88337941;     fCsHKirTCx88337941 = fCsHKirTCx98807078;     fCsHKirTCx98807078 = fCsHKirTCx96874011;     fCsHKirTCx96874011 = fCsHKirTCx38983940;     fCsHKirTCx38983940 = fCsHKirTCx99091974;     fCsHKirTCx99091974 = fCsHKirTCx5341031;     fCsHKirTCx5341031 = fCsHKirTCx95994106;     fCsHKirTCx95994106 = fCsHKirTCx1659150;     fCsHKirTCx1659150 = fCsHKirTCx38909615;     fCsHKirTCx38909615 = fCsHKirTCx42568463;     fCsHKirTCx42568463 = fCsHKirTCx20780113;     fCsHKirTCx20780113 = fCsHKirTCx61043958;     fCsHKirTCx61043958 = fCsHKirTCx96706679;     fCsHKirTCx96706679 = fCsHKirTCx90117432;     fCsHKirTCx90117432 = fCsHKirTCx52606364;     fCsHKirTCx52606364 = fCsHKirTCx40152770;     fCsHKirTCx40152770 = fCsHKirTCx12738093;     fCsHKirTCx12738093 = fCsHKirTCx64876399;     fCsHKirTCx64876399 = fCsHKirTCx32248749;     fCsHKirTCx32248749 = fCsHKirTCx18707564;     fCsHKirTCx18707564 = fCsHKirTCx31701037;     fCsHKirTCx31701037 = fCsHKirTCx71022684;     fCsHKirTCx71022684 = fCsHKirTCx14695229;     fCsHKirTCx14695229 = fCsHKirTCx2909769;     fCsHKirTCx2909769 = fCsHKirTCx61284282;     fCsHKirTCx61284282 = fCsHKirTCx25585559;     fCsHKirTCx25585559 = fCsHKirTCx16460239;     fCsHKirTCx16460239 = fCsHKirTCx24941276;     fCsHKirTCx24941276 = fCsHKirTCx38120255;     fCsHKirTCx38120255 = fCsHKirTCx85431865;     fCsHKirTCx85431865 = fCsHKirTCx49848777;     fCsHKirTCx49848777 = fCsHKirTCx48328045;     fCsHKirTCx48328045 = fCsHKirTCx85423677;     fCsHKirTCx85423677 = fCsHKirTCx82475257;     fCsHKirTCx82475257 = fCsHKirTCx69617503;     fCsHKirTCx69617503 = fCsHKirTCx77070469;     fCsHKirTCx77070469 = fCsHKirTCx59537603;     fCsHKirTCx59537603 = fCsHKirTCx95280078;     fCsHKirTCx95280078 = fCsHKirTCx87317126;     fCsHKirTCx87317126 = fCsHKirTCx79842859;     fCsHKirTCx79842859 = fCsHKirTCx82844267;     fCsHKirTCx82844267 = fCsHKirTCx93247653;     fCsHKirTCx93247653 = fCsHKirTCx99150961;     fCsHKirTCx99150961 = fCsHKirTCx47512499;     fCsHKirTCx47512499 = fCsHKirTCx71492590;     fCsHKirTCx71492590 = fCsHKirTCx23108370;     fCsHKirTCx23108370 = fCsHKirTCx75676080;     fCsHKirTCx75676080 = fCsHKirTCx68282539;     fCsHKirTCx68282539 = fCsHKirTCx99524679;     fCsHKirTCx99524679 = fCsHKirTCx28589468;     fCsHKirTCx28589468 = fCsHKirTCx97978173;     fCsHKirTCx97978173 = fCsHKirTCx55972783;     fCsHKirTCx55972783 = fCsHKirTCx46392058;     fCsHKirTCx46392058 = fCsHKirTCx4128047;     fCsHKirTCx4128047 = fCsHKirTCx5771883;     fCsHKirTCx5771883 = fCsHKirTCx17315258;     fCsHKirTCx17315258 = fCsHKirTCx84111849;     fCsHKirTCx84111849 = fCsHKirTCx16654856;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void ShwmHtnFMd5948220() {     int IPhdguvUAP39041973 = -700797288;    int IPhdguvUAP32420378 = -93846819;    int IPhdguvUAP57253191 = -431083276;    int IPhdguvUAP11571074 = -28718820;    int IPhdguvUAP45176365 = -809475865;    int IPhdguvUAP66168617 = -161680542;    int IPhdguvUAP9588378 = -233732063;    int IPhdguvUAP73179796 = -450680094;    int IPhdguvUAP23770970 = -87223295;    int IPhdguvUAP846846 = 89081748;    int IPhdguvUAP42318051 = -840078755;    int IPhdguvUAP51085420 = 74753921;    int IPhdguvUAP12444790 = -787822479;    int IPhdguvUAP40583071 = -640941925;    int IPhdguvUAP11595487 = -435439561;    int IPhdguvUAP21328232 = -528515537;    int IPhdguvUAP56685844 = -700815034;    int IPhdguvUAP2124548 = 42753562;    int IPhdguvUAP11979591 = -712114907;    int IPhdguvUAP5485135 = -462045507;    int IPhdguvUAP9142395 = -252477287;    int IPhdguvUAP83763394 = -59177346;    int IPhdguvUAP61248768 = -756145560;    int IPhdguvUAP2377336 = 85011408;    int IPhdguvUAP91951862 = -91604424;    int IPhdguvUAP22567013 = -64311661;    int IPhdguvUAP33498521 = -652747828;    int IPhdguvUAP91095340 = -926463845;    int IPhdguvUAP85730935 = -311621189;    int IPhdguvUAP4063982 = -899000010;    int IPhdguvUAP82351381 = -187064211;    int IPhdguvUAP47622154 = -808334234;    int IPhdguvUAP73311372 = -954018789;    int IPhdguvUAP43541015 = -301582034;    int IPhdguvUAP48612124 = -342449462;    int IPhdguvUAP92841 = -22010747;    int IPhdguvUAP45570756 = -581030131;    int IPhdguvUAP22368338 = -967042733;    int IPhdguvUAP59024397 = -171340226;    int IPhdguvUAP41034897 = -809427682;    int IPhdguvUAP7398178 = 99227669;    int IPhdguvUAP11344001 = -155187750;    int IPhdguvUAP43023111 = -898084840;    int IPhdguvUAP87782061 = -474994662;    int IPhdguvUAP66790345 = -133252245;    int IPhdguvUAP4974294 = -656620384;    int IPhdguvUAP51281337 = -214533622;    int IPhdguvUAP43690649 = -228817683;    int IPhdguvUAP99800935 = -63994944;    int IPhdguvUAP93077852 = -279471651;    int IPhdguvUAP10528366 = -321228431;    int IPhdguvUAP12760872 = -679907024;    int IPhdguvUAP20882867 = 68592258;    int IPhdguvUAP81066657 = -775801925;    int IPhdguvUAP96805825 = -954483790;    int IPhdguvUAP55278578 = -541619942;    int IPhdguvUAP71171609 = -337701260;    int IPhdguvUAP54875856 = -416094685;    int IPhdguvUAP19619212 = -937114397;    int IPhdguvUAP22609352 = -645164205;    int IPhdguvUAP32670096 = -508932715;    int IPhdguvUAP18493038 = -307268218;    int IPhdguvUAP87448861 = -39058906;    int IPhdguvUAP19706988 = -188223286;    int IPhdguvUAP18495464 = -723854042;    int IPhdguvUAP94695897 = 68255479;    int IPhdguvUAP77774047 = 28772709;    int IPhdguvUAP68903775 = -386240445;    int IPhdguvUAP91970946 = -198492464;    int IPhdguvUAP11502647 = -313428814;    int IPhdguvUAP75757476 = -947485406;    int IPhdguvUAP34317506 = -733772301;    int IPhdguvUAP43100150 = -785906212;    int IPhdguvUAP70944693 = -902687226;    int IPhdguvUAP98086956 = -461273177;    int IPhdguvUAP97798393 = 2710463;    int IPhdguvUAP40740284 = -161092507;    int IPhdguvUAP73466707 = -181150899;    int IPhdguvUAP35586990 = -781736348;    int IPhdguvUAP86977568 = -434984040;    int IPhdguvUAP71285676 = -849778039;    int IPhdguvUAP89807872 = -323930145;    int IPhdguvUAP91294404 = -762468902;    int IPhdguvUAP92653082 = 67850462;    int IPhdguvUAP93535616 = -477771579;    int IPhdguvUAP69590510 = -507157187;    int IPhdguvUAP26739287 = -776926492;    int IPhdguvUAP92244715 = -78216864;    int IPhdguvUAP46735190 = -347098245;    int IPhdguvUAP93333545 = -800829521;    int IPhdguvUAP28921231 = -684309488;    int IPhdguvUAP90694900 = -64935447;    int IPhdguvUAP2749127 = 70071663;    int IPhdguvUAP36415045 = -526176022;    int IPhdguvUAP8364802 = -200494968;    int IPhdguvUAP88905139 = -593504113;    int IPhdguvUAP23895140 = -16128845;    int IPhdguvUAP23316123 = -609861555;    int IPhdguvUAP69286597 = -751140620;    int IPhdguvUAP72094447 = -700797288;     IPhdguvUAP39041973 = IPhdguvUAP32420378;     IPhdguvUAP32420378 = IPhdguvUAP57253191;     IPhdguvUAP57253191 = IPhdguvUAP11571074;     IPhdguvUAP11571074 = IPhdguvUAP45176365;     IPhdguvUAP45176365 = IPhdguvUAP66168617;     IPhdguvUAP66168617 = IPhdguvUAP9588378;     IPhdguvUAP9588378 = IPhdguvUAP73179796;     IPhdguvUAP73179796 = IPhdguvUAP23770970;     IPhdguvUAP23770970 = IPhdguvUAP846846;     IPhdguvUAP846846 = IPhdguvUAP42318051;     IPhdguvUAP42318051 = IPhdguvUAP51085420;     IPhdguvUAP51085420 = IPhdguvUAP12444790;     IPhdguvUAP12444790 = IPhdguvUAP40583071;     IPhdguvUAP40583071 = IPhdguvUAP11595487;     IPhdguvUAP11595487 = IPhdguvUAP21328232;     IPhdguvUAP21328232 = IPhdguvUAP56685844;     IPhdguvUAP56685844 = IPhdguvUAP2124548;     IPhdguvUAP2124548 = IPhdguvUAP11979591;     IPhdguvUAP11979591 = IPhdguvUAP5485135;     IPhdguvUAP5485135 = IPhdguvUAP9142395;     IPhdguvUAP9142395 = IPhdguvUAP83763394;     IPhdguvUAP83763394 = IPhdguvUAP61248768;     IPhdguvUAP61248768 = IPhdguvUAP2377336;     IPhdguvUAP2377336 = IPhdguvUAP91951862;     IPhdguvUAP91951862 = IPhdguvUAP22567013;     IPhdguvUAP22567013 = IPhdguvUAP33498521;     IPhdguvUAP33498521 = IPhdguvUAP91095340;     IPhdguvUAP91095340 = IPhdguvUAP85730935;     IPhdguvUAP85730935 = IPhdguvUAP4063982;     IPhdguvUAP4063982 = IPhdguvUAP82351381;     IPhdguvUAP82351381 = IPhdguvUAP47622154;     IPhdguvUAP47622154 = IPhdguvUAP73311372;     IPhdguvUAP73311372 = IPhdguvUAP43541015;     IPhdguvUAP43541015 = IPhdguvUAP48612124;     IPhdguvUAP48612124 = IPhdguvUAP92841;     IPhdguvUAP92841 = IPhdguvUAP45570756;     IPhdguvUAP45570756 = IPhdguvUAP22368338;     IPhdguvUAP22368338 = IPhdguvUAP59024397;     IPhdguvUAP59024397 = IPhdguvUAP41034897;     IPhdguvUAP41034897 = IPhdguvUAP7398178;     IPhdguvUAP7398178 = IPhdguvUAP11344001;     IPhdguvUAP11344001 = IPhdguvUAP43023111;     IPhdguvUAP43023111 = IPhdguvUAP87782061;     IPhdguvUAP87782061 = IPhdguvUAP66790345;     IPhdguvUAP66790345 = IPhdguvUAP4974294;     IPhdguvUAP4974294 = IPhdguvUAP51281337;     IPhdguvUAP51281337 = IPhdguvUAP43690649;     IPhdguvUAP43690649 = IPhdguvUAP99800935;     IPhdguvUAP99800935 = IPhdguvUAP93077852;     IPhdguvUAP93077852 = IPhdguvUAP10528366;     IPhdguvUAP10528366 = IPhdguvUAP12760872;     IPhdguvUAP12760872 = IPhdguvUAP20882867;     IPhdguvUAP20882867 = IPhdguvUAP81066657;     IPhdguvUAP81066657 = IPhdguvUAP96805825;     IPhdguvUAP96805825 = IPhdguvUAP55278578;     IPhdguvUAP55278578 = IPhdguvUAP71171609;     IPhdguvUAP71171609 = IPhdguvUAP54875856;     IPhdguvUAP54875856 = IPhdguvUAP19619212;     IPhdguvUAP19619212 = IPhdguvUAP22609352;     IPhdguvUAP22609352 = IPhdguvUAP32670096;     IPhdguvUAP32670096 = IPhdguvUAP18493038;     IPhdguvUAP18493038 = IPhdguvUAP87448861;     IPhdguvUAP87448861 = IPhdguvUAP19706988;     IPhdguvUAP19706988 = IPhdguvUAP18495464;     IPhdguvUAP18495464 = IPhdguvUAP94695897;     IPhdguvUAP94695897 = IPhdguvUAP77774047;     IPhdguvUAP77774047 = IPhdguvUAP68903775;     IPhdguvUAP68903775 = IPhdguvUAP91970946;     IPhdguvUAP91970946 = IPhdguvUAP11502647;     IPhdguvUAP11502647 = IPhdguvUAP75757476;     IPhdguvUAP75757476 = IPhdguvUAP34317506;     IPhdguvUAP34317506 = IPhdguvUAP43100150;     IPhdguvUAP43100150 = IPhdguvUAP70944693;     IPhdguvUAP70944693 = IPhdguvUAP98086956;     IPhdguvUAP98086956 = IPhdguvUAP97798393;     IPhdguvUAP97798393 = IPhdguvUAP40740284;     IPhdguvUAP40740284 = IPhdguvUAP73466707;     IPhdguvUAP73466707 = IPhdguvUAP35586990;     IPhdguvUAP35586990 = IPhdguvUAP86977568;     IPhdguvUAP86977568 = IPhdguvUAP71285676;     IPhdguvUAP71285676 = IPhdguvUAP89807872;     IPhdguvUAP89807872 = IPhdguvUAP91294404;     IPhdguvUAP91294404 = IPhdguvUAP92653082;     IPhdguvUAP92653082 = IPhdguvUAP93535616;     IPhdguvUAP93535616 = IPhdguvUAP69590510;     IPhdguvUAP69590510 = IPhdguvUAP26739287;     IPhdguvUAP26739287 = IPhdguvUAP92244715;     IPhdguvUAP92244715 = IPhdguvUAP46735190;     IPhdguvUAP46735190 = IPhdguvUAP93333545;     IPhdguvUAP93333545 = IPhdguvUAP28921231;     IPhdguvUAP28921231 = IPhdguvUAP90694900;     IPhdguvUAP90694900 = IPhdguvUAP2749127;     IPhdguvUAP2749127 = IPhdguvUAP36415045;     IPhdguvUAP36415045 = IPhdguvUAP8364802;     IPhdguvUAP8364802 = IPhdguvUAP88905139;     IPhdguvUAP88905139 = IPhdguvUAP23895140;     IPhdguvUAP23895140 = IPhdguvUAP23316123;     IPhdguvUAP23316123 = IPhdguvUAP69286597;     IPhdguvUAP69286597 = IPhdguvUAP72094447;     IPhdguvUAP72094447 = IPhdguvUAP39041973;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void bAdUdgBhvW42593194() {     int xVAKwZXHGW61429090 = -335201251;    int xVAKwZXHGW16767878 = -42389874;    int xVAKwZXHGW86022469 = -670737120;    int xVAKwZXHGW26577762 = -35126352;    int xVAKwZXHGW43350619 = -300532866;    int xVAKwZXHGW81051733 = -22288920;    int xVAKwZXHGW1744117 = -55719369;    int xVAKwZXHGW48813655 = -921276738;    int xVAKwZXHGW20934101 = 28580666;    int xVAKwZXHGW92610429 = -753659585;    int xVAKwZXHGW79859910 = -836703156;    int xVAKwZXHGW6988369 = -175991372;    int xVAKwZXHGW79452970 = -306539799;    int xVAKwZXHGW83197822 = -68650682;    int xVAKwZXHGW48330764 = -62917274;    int xVAKwZXHGW65584144 = -910183080;    int xVAKwZXHGW6509196 = -978094854;    int xVAKwZXHGW8100964 = -408989128;    int xVAKwZXHGW53261221 = -847217033;    int xVAKwZXHGW84001417 = -714679960;    int xVAKwZXHGW10025502 = -243964595;    int xVAKwZXHGW47578613 = -563943660;    int xVAKwZXHGW64542091 = -932226152;    int xVAKwZXHGW28877122 = -478981449;    int xVAKwZXHGW27492109 = -813163549;    int xVAKwZXHGW10870008 = -508205885;    int xVAKwZXHGW80587941 = -410334321;    int xVAKwZXHGW97006790 = -714918299;    int xVAKwZXHGW92623495 = -655878308;    int xVAKwZXHGW13221162 = -819295876;    int xVAKwZXHGW26642187 = -268380363;    int xVAKwZXHGW5163345 = -360405589;    int xVAKwZXHGW54350043 = -383362284;    int xVAKwZXHGW2929703 = -625708884;    int xVAKwZXHGW24841489 = -406205884;    int xVAKwZXHGW41785709 = -337406123;    int xVAKwZXHGW39010468 = -313978083;    int xVAKwZXHGW75994439 = -834668205;    int xVAKwZXHGW7332529 = -572386258;    int xVAKwZXHGW61220612 = -945651711;    int xVAKwZXHGW36155548 = -403949997;    int xVAKwZXHGW99852392 = 86903559;    int xVAKwZXHGW48573303 = -785615424;    int xVAKwZXHGW87226180 = -472358311;    int xVAKwZXHGW34773612 = 57604278;    int xVAKwZXHGW13074576 = -838849480;    int xVAKwZXHGW63578734 = -792943875;    int xVAKwZXHGW88289323 = 14647326;    int xVAKwZXHGW94260840 = -13711643;    int xVAKwZXHGW90161597 = -421491910;    int xVAKwZXHGW19397583 = -676304708;    int xVAKwZXHGW86612129 = -10726306;    int xVAKwZXHGW99197269 = -703318973;    int xVAKwZXHGW41353203 = 48517266;    int xVAKwZXHGW32567693 = 4812095;    int xVAKwZXHGW13850478 = -771257592;    int xVAKwZXHGW52225786 = -110163722;    int xVAKwZXHGW57145347 = -91755671;    int xVAKwZXHGW99085653 = -221962804;    int xVAKwZXHGW32480612 = -792326982;    int xVAKwZXHGW463793 = -611954600;    int xVAKwZXHGW4737327 = -340801070;    int xVAKwZXHGW56190159 = -165398431;    int xVAKwZXHGW7712940 = -152123459;    int xVAKwZXHGW65968243 = -385279223;    int xVAKwZXHGW74696566 = -376297567;    int xVAKwZXHGW52638326 = -792629089;    int xVAKwZXHGW76523268 = -680830915;    int xVAKwZXHGW58356334 = -662444798;    int xVAKwZXHGW6545055 = -725511151;    int xVAKwZXHGW26573677 = -496204997;    int xVAKwZXHGW30514757 = -43426649;    int xVAKwZXHGW768436 = -836602871;    int xVAKwZXHGW92040609 = -901565322;    int xVAKwZXHGW47845869 = -210729964;    int xVAKwZXHGW10173110 = -230868155;    int xVAKwZXHGW99005309 = -778328236;    int xVAKwZXHGW77315911 = -359867842;    int xVAKwZXHGW94103510 = -436585728;    int xVAKwZXHGW14417534 = -974314069;    int xVAKwZXHGW47291273 = -715262010;    int xVAKwZXHGW92298618 = -324981647;    int xVAKwZXHGW2745950 = -601206657;    int xVAKwZXHGW2461898 = -134386399;    int xVAKwZXHGW93823579 = -42991169;    int xVAKwZXHGW40030058 = -157654057;    int xVAKwZXHGW5966075 = -657086617;    int xVAKwZXHGW12996841 = -331879550;    int xVAKwZXHGW70362009 = -530520980;    int xVAKwZXHGW10991012 = -634948293;    int xVAKwZXHGW89559922 = -127242402;    int xVAKwZXHGW81865120 = -122222412;    int xVAKwZXHGW76908786 = -512705402;    int xVAKwZXHGW74851917 = -780059276;    int xVAKwZXHGW60756819 = -233697112;    int xVAKwZXHGW31418222 = 36851073;    int xVAKwZXHGW43662233 = -747698011;    int xVAKwZXHGW40860363 = -533491966;    int xVAKwZXHGW21257937 = 12920912;    int xVAKwZXHGW60077045 = -335201251;     xVAKwZXHGW61429090 = xVAKwZXHGW16767878;     xVAKwZXHGW16767878 = xVAKwZXHGW86022469;     xVAKwZXHGW86022469 = xVAKwZXHGW26577762;     xVAKwZXHGW26577762 = xVAKwZXHGW43350619;     xVAKwZXHGW43350619 = xVAKwZXHGW81051733;     xVAKwZXHGW81051733 = xVAKwZXHGW1744117;     xVAKwZXHGW1744117 = xVAKwZXHGW48813655;     xVAKwZXHGW48813655 = xVAKwZXHGW20934101;     xVAKwZXHGW20934101 = xVAKwZXHGW92610429;     xVAKwZXHGW92610429 = xVAKwZXHGW79859910;     xVAKwZXHGW79859910 = xVAKwZXHGW6988369;     xVAKwZXHGW6988369 = xVAKwZXHGW79452970;     xVAKwZXHGW79452970 = xVAKwZXHGW83197822;     xVAKwZXHGW83197822 = xVAKwZXHGW48330764;     xVAKwZXHGW48330764 = xVAKwZXHGW65584144;     xVAKwZXHGW65584144 = xVAKwZXHGW6509196;     xVAKwZXHGW6509196 = xVAKwZXHGW8100964;     xVAKwZXHGW8100964 = xVAKwZXHGW53261221;     xVAKwZXHGW53261221 = xVAKwZXHGW84001417;     xVAKwZXHGW84001417 = xVAKwZXHGW10025502;     xVAKwZXHGW10025502 = xVAKwZXHGW47578613;     xVAKwZXHGW47578613 = xVAKwZXHGW64542091;     xVAKwZXHGW64542091 = xVAKwZXHGW28877122;     xVAKwZXHGW28877122 = xVAKwZXHGW27492109;     xVAKwZXHGW27492109 = xVAKwZXHGW10870008;     xVAKwZXHGW10870008 = xVAKwZXHGW80587941;     xVAKwZXHGW80587941 = xVAKwZXHGW97006790;     xVAKwZXHGW97006790 = xVAKwZXHGW92623495;     xVAKwZXHGW92623495 = xVAKwZXHGW13221162;     xVAKwZXHGW13221162 = xVAKwZXHGW26642187;     xVAKwZXHGW26642187 = xVAKwZXHGW5163345;     xVAKwZXHGW5163345 = xVAKwZXHGW54350043;     xVAKwZXHGW54350043 = xVAKwZXHGW2929703;     xVAKwZXHGW2929703 = xVAKwZXHGW24841489;     xVAKwZXHGW24841489 = xVAKwZXHGW41785709;     xVAKwZXHGW41785709 = xVAKwZXHGW39010468;     xVAKwZXHGW39010468 = xVAKwZXHGW75994439;     xVAKwZXHGW75994439 = xVAKwZXHGW7332529;     xVAKwZXHGW7332529 = xVAKwZXHGW61220612;     xVAKwZXHGW61220612 = xVAKwZXHGW36155548;     xVAKwZXHGW36155548 = xVAKwZXHGW99852392;     xVAKwZXHGW99852392 = xVAKwZXHGW48573303;     xVAKwZXHGW48573303 = xVAKwZXHGW87226180;     xVAKwZXHGW87226180 = xVAKwZXHGW34773612;     xVAKwZXHGW34773612 = xVAKwZXHGW13074576;     xVAKwZXHGW13074576 = xVAKwZXHGW63578734;     xVAKwZXHGW63578734 = xVAKwZXHGW88289323;     xVAKwZXHGW88289323 = xVAKwZXHGW94260840;     xVAKwZXHGW94260840 = xVAKwZXHGW90161597;     xVAKwZXHGW90161597 = xVAKwZXHGW19397583;     xVAKwZXHGW19397583 = xVAKwZXHGW86612129;     xVAKwZXHGW86612129 = xVAKwZXHGW99197269;     xVAKwZXHGW99197269 = xVAKwZXHGW41353203;     xVAKwZXHGW41353203 = xVAKwZXHGW32567693;     xVAKwZXHGW32567693 = xVAKwZXHGW13850478;     xVAKwZXHGW13850478 = xVAKwZXHGW52225786;     xVAKwZXHGW52225786 = xVAKwZXHGW57145347;     xVAKwZXHGW57145347 = xVAKwZXHGW99085653;     xVAKwZXHGW99085653 = xVAKwZXHGW32480612;     xVAKwZXHGW32480612 = xVAKwZXHGW463793;     xVAKwZXHGW463793 = xVAKwZXHGW4737327;     xVAKwZXHGW4737327 = xVAKwZXHGW56190159;     xVAKwZXHGW56190159 = xVAKwZXHGW7712940;     xVAKwZXHGW7712940 = xVAKwZXHGW65968243;     xVAKwZXHGW65968243 = xVAKwZXHGW74696566;     xVAKwZXHGW74696566 = xVAKwZXHGW52638326;     xVAKwZXHGW52638326 = xVAKwZXHGW76523268;     xVAKwZXHGW76523268 = xVAKwZXHGW58356334;     xVAKwZXHGW58356334 = xVAKwZXHGW6545055;     xVAKwZXHGW6545055 = xVAKwZXHGW26573677;     xVAKwZXHGW26573677 = xVAKwZXHGW30514757;     xVAKwZXHGW30514757 = xVAKwZXHGW768436;     xVAKwZXHGW768436 = xVAKwZXHGW92040609;     xVAKwZXHGW92040609 = xVAKwZXHGW47845869;     xVAKwZXHGW47845869 = xVAKwZXHGW10173110;     xVAKwZXHGW10173110 = xVAKwZXHGW99005309;     xVAKwZXHGW99005309 = xVAKwZXHGW77315911;     xVAKwZXHGW77315911 = xVAKwZXHGW94103510;     xVAKwZXHGW94103510 = xVAKwZXHGW14417534;     xVAKwZXHGW14417534 = xVAKwZXHGW47291273;     xVAKwZXHGW47291273 = xVAKwZXHGW92298618;     xVAKwZXHGW92298618 = xVAKwZXHGW2745950;     xVAKwZXHGW2745950 = xVAKwZXHGW2461898;     xVAKwZXHGW2461898 = xVAKwZXHGW93823579;     xVAKwZXHGW93823579 = xVAKwZXHGW40030058;     xVAKwZXHGW40030058 = xVAKwZXHGW5966075;     xVAKwZXHGW5966075 = xVAKwZXHGW12996841;     xVAKwZXHGW12996841 = xVAKwZXHGW70362009;     xVAKwZXHGW70362009 = xVAKwZXHGW10991012;     xVAKwZXHGW10991012 = xVAKwZXHGW89559922;     xVAKwZXHGW89559922 = xVAKwZXHGW81865120;     xVAKwZXHGW81865120 = xVAKwZXHGW76908786;     xVAKwZXHGW76908786 = xVAKwZXHGW74851917;     xVAKwZXHGW74851917 = xVAKwZXHGW60756819;     xVAKwZXHGW60756819 = xVAKwZXHGW31418222;     xVAKwZXHGW31418222 = xVAKwZXHGW43662233;     xVAKwZXHGW43662233 = xVAKwZXHGW40860363;     xVAKwZXHGW40860363 = xVAKwZXHGW21257937;     xVAKwZXHGW21257937 = xVAKwZXHGW60077045;     xVAKwZXHGW60077045 = xVAKwZXHGW61429090;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void oCHrpTIivZ79238169() {     int ToVtwXKoeJ83816207 = 30394786;    int ToVtwXKoeJ1115379 = 9067071;    int ToVtwXKoeJ14791748 = -910390964;    int ToVtwXKoeJ41584451 = -41533884;    int ToVtwXKoeJ41524874 = -891589868;    int ToVtwXKoeJ95934850 = -982897298;    int ToVtwXKoeJ93899855 = -977706675;    int ToVtwXKoeJ24447514 = -291873382;    int ToVtwXKoeJ18097232 = -955615373;    int ToVtwXKoeJ84374014 = -496400918;    int ToVtwXKoeJ17401771 = -833327556;    int ToVtwXKoeJ62891318 = -426736666;    int ToVtwXKoeJ46461151 = -925257118;    int ToVtwXKoeJ25812575 = -596359439;    int ToVtwXKoeJ85066040 = -790394987;    int ToVtwXKoeJ9840057 = -191850622;    int ToVtwXKoeJ56332547 = -155374674;    int ToVtwXKoeJ14077380 = -860731819;    int ToVtwXKoeJ94542852 = -982319158;    int ToVtwXKoeJ62517701 = -967314414;    int ToVtwXKoeJ10908609 = -235451904;    int ToVtwXKoeJ11393832 = 31290027;    int ToVtwXKoeJ67835414 = -8306744;    int ToVtwXKoeJ55376909 = 57025693;    int ToVtwXKoeJ63032356 = -434722673;    int ToVtwXKoeJ99173002 = -952100109;    int ToVtwXKoeJ27677362 = -167920814;    int ToVtwXKoeJ2918241 = -503372752;    int ToVtwXKoeJ99516056 = 99864573;    int ToVtwXKoeJ22378341 = -739591743;    int ToVtwXKoeJ70932992 = -349696515;    int ToVtwXKoeJ62704535 = 87523057;    int ToVtwXKoeJ35388713 = -912705779;    int ToVtwXKoeJ62318389 = -949835734;    int ToVtwXKoeJ1070854 = -469962307;    int ToVtwXKoeJ83478578 = -652801500;    int ToVtwXKoeJ32450180 = -46926034;    int ToVtwXKoeJ29620540 = -702293677;    int ToVtwXKoeJ55640660 = -973432289;    int ToVtwXKoeJ81406326 = 18124260;    int ToVtwXKoeJ64912919 = -907127663;    int ToVtwXKoeJ88360783 = -771005132;    int ToVtwXKoeJ54123495 = -673146008;    int ToVtwXKoeJ86670299 = -469721960;    int ToVtwXKoeJ2756879 = -851539200;    int ToVtwXKoeJ21174858 = 78921425;    int ToVtwXKoeJ75876132 = -271354128;    int ToVtwXKoeJ32887998 = -841887665;    int ToVtwXKoeJ88720745 = 36571659;    int ToVtwXKoeJ87245343 = -563512169;    int ToVtwXKoeJ28266799 = 68619015;    int ToVtwXKoeJ60463386 = -441545588;    int ToVtwXKoeJ77511673 = -375230203;    int ToVtwXKoeJ1639748 = -227163543;    int ToVtwXKoeJ68329560 = -135892020;    int ToVtwXKoeJ72422376 = 99104759;    int ToVtwXKoeJ33279964 = -982626185;    int ToVtwXKoeJ59414839 = -867416658;    int ToVtwXKoeJ78552094 = -606811211;    int ToVtwXKoeJ42351871 = -939489759;    int ToVtwXKoeJ68257489 = -714976485;    int ToVtwXKoeJ90981615 = -374333923;    int ToVtwXKoeJ24931457 = -291737956;    int ToVtwXKoeJ95718891 = -116023631;    int ToVtwXKoeJ13441023 = -46704404;    int ToVtwXKoeJ54697235 = -820850614;    int ToVtwXKoeJ27502605 = -514030888;    int ToVtwXKoeJ84142761 = -975421385;    int ToVtwXKoeJ24741722 = -26397133;    int ToVtwXKoeJ1587463 = -37593488;    int ToVtwXKoeJ77389877 = -44924588;    int ToVtwXKoeJ26712008 = -453080997;    int ToVtwXKoeJ58436720 = -887299530;    int ToVtwXKoeJ13136526 = -900443418;    int ToVtwXKoeJ97604781 = 39813248;    int ToVtwXKoeJ22547826 = -464446772;    int ToVtwXKoeJ57270336 = -295563966;    int ToVtwXKoeJ81165115 = -538584785;    int ToVtwXKoeJ52620031 = -91435107;    int ToVtwXKoeJ41857498 = -413644098;    int ToVtwXKoeJ23296870 = -580745981;    int ToVtwXKoeJ94789363 = -326033149;    int ToVtwXKoeJ14197495 = -439944412;    int ToVtwXKoeJ12270713 = -336623259;    int ToVtwXKoeJ94111542 = -708210758;    int ToVtwXKoeJ10469606 = -908150927;    int ToVtwXKoeJ85192862 = -537246741;    int ToVtwXKoeJ33748966 = -585542236;    int ToVtwXKoeJ93988829 = -713943715;    int ToVtwXKoeJ28648477 = -469067066;    int ToVtwXKoeJ50198615 = -670175316;    int ToVtwXKoeJ73035341 = -179509376;    int ToVtwXKoeJ51068445 = 4517533;    int ToVtwXKoeJ13288789 = 66057470;    int ToVtwXKoeJ13148838 = -266899256;    int ToVtwXKoeJ73931304 = -432793740;    int ToVtwXKoeJ63429327 = -379267177;    int ToVtwXKoeJ58404604 = -457122377;    int ToVtwXKoeJ73229277 = -323017556;    int ToVtwXKoeJ48059643 = 30394786;     ToVtwXKoeJ83816207 = ToVtwXKoeJ1115379;     ToVtwXKoeJ1115379 = ToVtwXKoeJ14791748;     ToVtwXKoeJ14791748 = ToVtwXKoeJ41584451;     ToVtwXKoeJ41584451 = ToVtwXKoeJ41524874;     ToVtwXKoeJ41524874 = ToVtwXKoeJ95934850;     ToVtwXKoeJ95934850 = ToVtwXKoeJ93899855;     ToVtwXKoeJ93899855 = ToVtwXKoeJ24447514;     ToVtwXKoeJ24447514 = ToVtwXKoeJ18097232;     ToVtwXKoeJ18097232 = ToVtwXKoeJ84374014;     ToVtwXKoeJ84374014 = ToVtwXKoeJ17401771;     ToVtwXKoeJ17401771 = ToVtwXKoeJ62891318;     ToVtwXKoeJ62891318 = ToVtwXKoeJ46461151;     ToVtwXKoeJ46461151 = ToVtwXKoeJ25812575;     ToVtwXKoeJ25812575 = ToVtwXKoeJ85066040;     ToVtwXKoeJ85066040 = ToVtwXKoeJ9840057;     ToVtwXKoeJ9840057 = ToVtwXKoeJ56332547;     ToVtwXKoeJ56332547 = ToVtwXKoeJ14077380;     ToVtwXKoeJ14077380 = ToVtwXKoeJ94542852;     ToVtwXKoeJ94542852 = ToVtwXKoeJ62517701;     ToVtwXKoeJ62517701 = ToVtwXKoeJ10908609;     ToVtwXKoeJ10908609 = ToVtwXKoeJ11393832;     ToVtwXKoeJ11393832 = ToVtwXKoeJ67835414;     ToVtwXKoeJ67835414 = ToVtwXKoeJ55376909;     ToVtwXKoeJ55376909 = ToVtwXKoeJ63032356;     ToVtwXKoeJ63032356 = ToVtwXKoeJ99173002;     ToVtwXKoeJ99173002 = ToVtwXKoeJ27677362;     ToVtwXKoeJ27677362 = ToVtwXKoeJ2918241;     ToVtwXKoeJ2918241 = ToVtwXKoeJ99516056;     ToVtwXKoeJ99516056 = ToVtwXKoeJ22378341;     ToVtwXKoeJ22378341 = ToVtwXKoeJ70932992;     ToVtwXKoeJ70932992 = ToVtwXKoeJ62704535;     ToVtwXKoeJ62704535 = ToVtwXKoeJ35388713;     ToVtwXKoeJ35388713 = ToVtwXKoeJ62318389;     ToVtwXKoeJ62318389 = ToVtwXKoeJ1070854;     ToVtwXKoeJ1070854 = ToVtwXKoeJ83478578;     ToVtwXKoeJ83478578 = ToVtwXKoeJ32450180;     ToVtwXKoeJ32450180 = ToVtwXKoeJ29620540;     ToVtwXKoeJ29620540 = ToVtwXKoeJ55640660;     ToVtwXKoeJ55640660 = ToVtwXKoeJ81406326;     ToVtwXKoeJ81406326 = ToVtwXKoeJ64912919;     ToVtwXKoeJ64912919 = ToVtwXKoeJ88360783;     ToVtwXKoeJ88360783 = ToVtwXKoeJ54123495;     ToVtwXKoeJ54123495 = ToVtwXKoeJ86670299;     ToVtwXKoeJ86670299 = ToVtwXKoeJ2756879;     ToVtwXKoeJ2756879 = ToVtwXKoeJ21174858;     ToVtwXKoeJ21174858 = ToVtwXKoeJ75876132;     ToVtwXKoeJ75876132 = ToVtwXKoeJ32887998;     ToVtwXKoeJ32887998 = ToVtwXKoeJ88720745;     ToVtwXKoeJ88720745 = ToVtwXKoeJ87245343;     ToVtwXKoeJ87245343 = ToVtwXKoeJ28266799;     ToVtwXKoeJ28266799 = ToVtwXKoeJ60463386;     ToVtwXKoeJ60463386 = ToVtwXKoeJ77511673;     ToVtwXKoeJ77511673 = ToVtwXKoeJ1639748;     ToVtwXKoeJ1639748 = ToVtwXKoeJ68329560;     ToVtwXKoeJ68329560 = ToVtwXKoeJ72422376;     ToVtwXKoeJ72422376 = ToVtwXKoeJ33279964;     ToVtwXKoeJ33279964 = ToVtwXKoeJ59414839;     ToVtwXKoeJ59414839 = ToVtwXKoeJ78552094;     ToVtwXKoeJ78552094 = ToVtwXKoeJ42351871;     ToVtwXKoeJ42351871 = ToVtwXKoeJ68257489;     ToVtwXKoeJ68257489 = ToVtwXKoeJ90981615;     ToVtwXKoeJ90981615 = ToVtwXKoeJ24931457;     ToVtwXKoeJ24931457 = ToVtwXKoeJ95718891;     ToVtwXKoeJ95718891 = ToVtwXKoeJ13441023;     ToVtwXKoeJ13441023 = ToVtwXKoeJ54697235;     ToVtwXKoeJ54697235 = ToVtwXKoeJ27502605;     ToVtwXKoeJ27502605 = ToVtwXKoeJ84142761;     ToVtwXKoeJ84142761 = ToVtwXKoeJ24741722;     ToVtwXKoeJ24741722 = ToVtwXKoeJ1587463;     ToVtwXKoeJ1587463 = ToVtwXKoeJ77389877;     ToVtwXKoeJ77389877 = ToVtwXKoeJ26712008;     ToVtwXKoeJ26712008 = ToVtwXKoeJ58436720;     ToVtwXKoeJ58436720 = ToVtwXKoeJ13136526;     ToVtwXKoeJ13136526 = ToVtwXKoeJ97604781;     ToVtwXKoeJ97604781 = ToVtwXKoeJ22547826;     ToVtwXKoeJ22547826 = ToVtwXKoeJ57270336;     ToVtwXKoeJ57270336 = ToVtwXKoeJ81165115;     ToVtwXKoeJ81165115 = ToVtwXKoeJ52620031;     ToVtwXKoeJ52620031 = ToVtwXKoeJ41857498;     ToVtwXKoeJ41857498 = ToVtwXKoeJ23296870;     ToVtwXKoeJ23296870 = ToVtwXKoeJ94789363;     ToVtwXKoeJ94789363 = ToVtwXKoeJ14197495;     ToVtwXKoeJ14197495 = ToVtwXKoeJ12270713;     ToVtwXKoeJ12270713 = ToVtwXKoeJ94111542;     ToVtwXKoeJ94111542 = ToVtwXKoeJ10469606;     ToVtwXKoeJ10469606 = ToVtwXKoeJ85192862;     ToVtwXKoeJ85192862 = ToVtwXKoeJ33748966;     ToVtwXKoeJ33748966 = ToVtwXKoeJ93988829;     ToVtwXKoeJ93988829 = ToVtwXKoeJ28648477;     ToVtwXKoeJ28648477 = ToVtwXKoeJ50198615;     ToVtwXKoeJ50198615 = ToVtwXKoeJ73035341;     ToVtwXKoeJ73035341 = ToVtwXKoeJ51068445;     ToVtwXKoeJ51068445 = ToVtwXKoeJ13288789;     ToVtwXKoeJ13288789 = ToVtwXKoeJ13148838;     ToVtwXKoeJ13148838 = ToVtwXKoeJ73931304;     ToVtwXKoeJ73931304 = ToVtwXKoeJ63429327;     ToVtwXKoeJ63429327 = ToVtwXKoeJ58404604;     ToVtwXKoeJ58404604 = ToVtwXKoeJ73229277;     ToVtwXKoeJ73229277 = ToVtwXKoeJ48059643;     ToVtwXKoeJ48059643 = ToVtwXKoeJ83816207;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void ygFSlwYKHJ15883144() {     int mNvpdlMVuj6203325 = -704009177;    int mNvpdlMVuj85462878 = 60524017;    int mNvpdlMVuj43561027 = -50044809;    int mNvpdlMVuj56591139 = -47941415;    int mNvpdlMVuj39699128 = -382646869;    int mNvpdlMVuj10817968 = -843505676;    int mNvpdlMVuj86055594 = -799693981;    int mNvpdlMVuj81373 = -762470026;    int mNvpdlMVuj15260364 = -839811413;    int mNvpdlMVuj76137599 = -239142251;    int mNvpdlMVuj54943630 = -829951957;    int mNvpdlMVuj18794267 = -677481959;    int mNvpdlMVuj13469332 = -443974438;    int mNvpdlMVuj68427327 = -24068196;    int mNvpdlMVuj21801318 = -417872700;    int mNvpdlMVuj54095969 = -573518164;    int mNvpdlMVuj6155900 = -432654493;    int mNvpdlMVuj20053797 = -212474510;    int mNvpdlMVuj35824483 = -17421283;    int mNvpdlMVuj41033984 = -119948868;    int mNvpdlMVuj11791716 = -226939212;    int mNvpdlMVuj75209049 = -473476286;    int mNvpdlMVuj71128737 = -184387336;    int mNvpdlMVuj81876696 = -506967164;    int mNvpdlMVuj98572602 = -56281798;    int mNvpdlMVuj87475996 = -295994333;    int mNvpdlMVuj74766782 = 74492693;    int mNvpdlMVuj8829691 = -291827206;    int mNvpdlMVuj6408618 = -244392546;    int mNvpdlMVuj31535520 = -659887609;    int mNvpdlMVuj15223797 = -431012667;    int mNvpdlMVuj20245727 = -564548298;    int mNvpdlMVuj16427384 = -342049273;    int mNvpdlMVuj21707077 = -173962584;    int mNvpdlMVuj77300218 = -533718729;    int mNvpdlMVuj25171448 = -968196876;    int mNvpdlMVuj25889892 = -879873986;    int mNvpdlMVuj83246640 = -569919149;    int mNvpdlMVuj3948792 = -274478321;    int mNvpdlMVuj1592042 = -118099770;    int mNvpdlMVuj93670289 = -310305329;    int mNvpdlMVuj76869175 = -528913823;    int mNvpdlMVuj59673687 = -560676591;    int mNvpdlMVuj86114418 = -467085608;    int mNvpdlMVuj70740145 = -660682678;    int mNvpdlMVuj29275140 = -103307671;    int mNvpdlMVuj88173529 = -849764381;    int mNvpdlMVuj77486672 = -598422656;    int mNvpdlMVuj83180651 = 86854961;    int mNvpdlMVuj84329089 = -705532428;    int mNvpdlMVuj37136015 = -286457262;    int mNvpdlMVuj34314643 = -872364870;    int mNvpdlMVuj55826076 = -47141433;    int mNvpdlMVuj61926293 = -502844351;    int mNvpdlMVuj4091428 = -276596136;    int mNvpdlMVuj30994276 = -130532891;    int mNvpdlMVuj14334141 = -755088648;    int mNvpdlMVuj61684330 = -543077645;    int mNvpdlMVuj58018536 = -991659618;    int mNvpdlMVuj52223131 = 13347463;    int mNvpdlMVuj36051186 = -817998370;    int mNvpdlMVuj77225904 = -407866776;    int mNvpdlMVuj93672754 = -418077481;    int mNvpdlMVuj83724843 = -79923804;    int mNvpdlMVuj60913802 = -808129584;    int mNvpdlMVuj34697904 = -165403660;    int mNvpdlMVuj2366883 = -235432686;    int mNvpdlMVuj91762255 = -170011854;    int mNvpdlMVuj91127109 = -490349467;    int mNvpdlMVuj96629870 = -449675824;    int mNvpdlMVuj28206077 = -693644179;    int mNvpdlMVuj22909259 = -862735345;    int mNvpdlMVuj16105005 = -937996189;    int mNvpdlMVuj34232442 = -899321514;    int mNvpdlMVuj47363694 = -809643539;    int mNvpdlMVuj34922541 = -698025390;    int mNvpdlMVuj15535363 = -912799695;    int mNvpdlMVuj85014319 = -717301728;    int mNvpdlMVuj11136552 = -846284487;    int mNvpdlMVuj69297463 = -952974128;    int mNvpdlMVuj99302467 = -446229952;    int mNvpdlMVuj97280109 = -327084651;    int mNvpdlMVuj25649040 = -278682167;    int mNvpdlMVuj22079529 = -538860119;    int mNvpdlMVuj94399505 = -273430348;    int mNvpdlMVuj80909153 = -558647797;    int mNvpdlMVuj64419650 = -417406866;    int mNvpdlMVuj54501091 = -839204923;    int mNvpdlMVuj17615650 = -897366449;    int mNvpdlMVuj46305942 = -303185839;    int mNvpdlMVuj10837307 = -113108229;    int mNvpdlMVuj64205562 = -236796341;    int mNvpdlMVuj25228105 = -578259531;    int mNvpdlMVuj51725660 = -187825785;    int mNvpdlMVuj65540855 = -300101400;    int mNvpdlMVuj16444386 = -902438554;    int mNvpdlMVuj83196420 = -10836343;    int mNvpdlMVuj75948844 = -380752788;    int mNvpdlMVuj25200617 = -658956025;    int mNvpdlMVuj36042241 = -704009177;     mNvpdlMVuj6203325 = mNvpdlMVuj85462878;     mNvpdlMVuj85462878 = mNvpdlMVuj43561027;     mNvpdlMVuj43561027 = mNvpdlMVuj56591139;     mNvpdlMVuj56591139 = mNvpdlMVuj39699128;     mNvpdlMVuj39699128 = mNvpdlMVuj10817968;     mNvpdlMVuj10817968 = mNvpdlMVuj86055594;     mNvpdlMVuj86055594 = mNvpdlMVuj81373;     mNvpdlMVuj81373 = mNvpdlMVuj15260364;     mNvpdlMVuj15260364 = mNvpdlMVuj76137599;     mNvpdlMVuj76137599 = mNvpdlMVuj54943630;     mNvpdlMVuj54943630 = mNvpdlMVuj18794267;     mNvpdlMVuj18794267 = mNvpdlMVuj13469332;     mNvpdlMVuj13469332 = mNvpdlMVuj68427327;     mNvpdlMVuj68427327 = mNvpdlMVuj21801318;     mNvpdlMVuj21801318 = mNvpdlMVuj54095969;     mNvpdlMVuj54095969 = mNvpdlMVuj6155900;     mNvpdlMVuj6155900 = mNvpdlMVuj20053797;     mNvpdlMVuj20053797 = mNvpdlMVuj35824483;     mNvpdlMVuj35824483 = mNvpdlMVuj41033984;     mNvpdlMVuj41033984 = mNvpdlMVuj11791716;     mNvpdlMVuj11791716 = mNvpdlMVuj75209049;     mNvpdlMVuj75209049 = mNvpdlMVuj71128737;     mNvpdlMVuj71128737 = mNvpdlMVuj81876696;     mNvpdlMVuj81876696 = mNvpdlMVuj98572602;     mNvpdlMVuj98572602 = mNvpdlMVuj87475996;     mNvpdlMVuj87475996 = mNvpdlMVuj74766782;     mNvpdlMVuj74766782 = mNvpdlMVuj8829691;     mNvpdlMVuj8829691 = mNvpdlMVuj6408618;     mNvpdlMVuj6408618 = mNvpdlMVuj31535520;     mNvpdlMVuj31535520 = mNvpdlMVuj15223797;     mNvpdlMVuj15223797 = mNvpdlMVuj20245727;     mNvpdlMVuj20245727 = mNvpdlMVuj16427384;     mNvpdlMVuj16427384 = mNvpdlMVuj21707077;     mNvpdlMVuj21707077 = mNvpdlMVuj77300218;     mNvpdlMVuj77300218 = mNvpdlMVuj25171448;     mNvpdlMVuj25171448 = mNvpdlMVuj25889892;     mNvpdlMVuj25889892 = mNvpdlMVuj83246640;     mNvpdlMVuj83246640 = mNvpdlMVuj3948792;     mNvpdlMVuj3948792 = mNvpdlMVuj1592042;     mNvpdlMVuj1592042 = mNvpdlMVuj93670289;     mNvpdlMVuj93670289 = mNvpdlMVuj76869175;     mNvpdlMVuj76869175 = mNvpdlMVuj59673687;     mNvpdlMVuj59673687 = mNvpdlMVuj86114418;     mNvpdlMVuj86114418 = mNvpdlMVuj70740145;     mNvpdlMVuj70740145 = mNvpdlMVuj29275140;     mNvpdlMVuj29275140 = mNvpdlMVuj88173529;     mNvpdlMVuj88173529 = mNvpdlMVuj77486672;     mNvpdlMVuj77486672 = mNvpdlMVuj83180651;     mNvpdlMVuj83180651 = mNvpdlMVuj84329089;     mNvpdlMVuj84329089 = mNvpdlMVuj37136015;     mNvpdlMVuj37136015 = mNvpdlMVuj34314643;     mNvpdlMVuj34314643 = mNvpdlMVuj55826076;     mNvpdlMVuj55826076 = mNvpdlMVuj61926293;     mNvpdlMVuj61926293 = mNvpdlMVuj4091428;     mNvpdlMVuj4091428 = mNvpdlMVuj30994276;     mNvpdlMVuj30994276 = mNvpdlMVuj14334141;     mNvpdlMVuj14334141 = mNvpdlMVuj61684330;     mNvpdlMVuj61684330 = mNvpdlMVuj58018536;     mNvpdlMVuj58018536 = mNvpdlMVuj52223131;     mNvpdlMVuj52223131 = mNvpdlMVuj36051186;     mNvpdlMVuj36051186 = mNvpdlMVuj77225904;     mNvpdlMVuj77225904 = mNvpdlMVuj93672754;     mNvpdlMVuj93672754 = mNvpdlMVuj83724843;     mNvpdlMVuj83724843 = mNvpdlMVuj60913802;     mNvpdlMVuj60913802 = mNvpdlMVuj34697904;     mNvpdlMVuj34697904 = mNvpdlMVuj2366883;     mNvpdlMVuj2366883 = mNvpdlMVuj91762255;     mNvpdlMVuj91762255 = mNvpdlMVuj91127109;     mNvpdlMVuj91127109 = mNvpdlMVuj96629870;     mNvpdlMVuj96629870 = mNvpdlMVuj28206077;     mNvpdlMVuj28206077 = mNvpdlMVuj22909259;     mNvpdlMVuj22909259 = mNvpdlMVuj16105005;     mNvpdlMVuj16105005 = mNvpdlMVuj34232442;     mNvpdlMVuj34232442 = mNvpdlMVuj47363694;     mNvpdlMVuj47363694 = mNvpdlMVuj34922541;     mNvpdlMVuj34922541 = mNvpdlMVuj15535363;     mNvpdlMVuj15535363 = mNvpdlMVuj85014319;     mNvpdlMVuj85014319 = mNvpdlMVuj11136552;     mNvpdlMVuj11136552 = mNvpdlMVuj69297463;     mNvpdlMVuj69297463 = mNvpdlMVuj99302467;     mNvpdlMVuj99302467 = mNvpdlMVuj97280109;     mNvpdlMVuj97280109 = mNvpdlMVuj25649040;     mNvpdlMVuj25649040 = mNvpdlMVuj22079529;     mNvpdlMVuj22079529 = mNvpdlMVuj94399505;     mNvpdlMVuj94399505 = mNvpdlMVuj80909153;     mNvpdlMVuj80909153 = mNvpdlMVuj64419650;     mNvpdlMVuj64419650 = mNvpdlMVuj54501091;     mNvpdlMVuj54501091 = mNvpdlMVuj17615650;     mNvpdlMVuj17615650 = mNvpdlMVuj46305942;     mNvpdlMVuj46305942 = mNvpdlMVuj10837307;     mNvpdlMVuj10837307 = mNvpdlMVuj64205562;     mNvpdlMVuj64205562 = mNvpdlMVuj25228105;     mNvpdlMVuj25228105 = mNvpdlMVuj51725660;     mNvpdlMVuj51725660 = mNvpdlMVuj65540855;     mNvpdlMVuj65540855 = mNvpdlMVuj16444386;     mNvpdlMVuj16444386 = mNvpdlMVuj83196420;     mNvpdlMVuj83196420 = mNvpdlMVuj75948844;     mNvpdlMVuj75948844 = mNvpdlMVuj25200617;     mNvpdlMVuj25200617 = mNvpdlMVuj36042241;     mNvpdlMVuj36042241 = mNvpdlMVuj6203325;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void ApAfcNciwH52528118() {     int hBLtITMcph28590443 = -338413140;    int hBLtITMcph69810379 = -988019038;    int hBLtITMcph72330305 = -289698653;    int hBLtITMcph71597827 = -54348947;    int hBLtITMcph37873382 = -973703870;    int hBLtITMcph25701085 = -704114054;    int hBLtITMcph78211333 = -621681287;    int hBLtITMcph75715231 = -133066671;    int hBLtITMcph12423495 = -724007452;    int hBLtITMcph67901184 = 18116416;    int hBLtITMcph92485489 = -826576358;    int hBLtITMcph74697215 = -928227252;    int hBLtITMcph80477512 = 37308242;    int hBLtITMcph11042080 = -551776953;    int hBLtITMcph58536595 = -45350413;    int hBLtITMcph98351881 = -955185707;    int hBLtITMcph55979251 = -709934313;    int hBLtITMcph26030213 = -664217200;    int hBLtITMcph77106114 = -152523408;    int hBLtITMcph19550268 = -372583321;    int hBLtITMcph12674824 = -218426521;    int hBLtITMcph39024268 = -978242600;    int hBLtITMcph74422061 = -360467928;    int hBLtITMcph8376484 = 29039979;    int hBLtITMcph34112850 = -777840922;    int hBLtITMcph75778991 = -739888557;    int hBLtITMcph21856203 = -783093799;    int hBLtITMcph14741141 = -80281660;    int hBLtITMcph13301179 = -588649665;    int hBLtITMcph40692700 = -580183476;    int hBLtITMcph59514602 = -512328819;    int hBLtITMcph77786917 = -116619653;    int hBLtITMcph97466054 = -871392768;    int hBLtITMcph81095764 = -498089434;    int hBLtITMcph53529582 = -597475152;    int hBLtITMcph66864316 = -183592253;    int hBLtITMcph19329605 = -612821937;    int hBLtITMcph36872742 = -437544621;    int hBLtITMcph52256922 = -675524353;    int hBLtITMcph21777756 = -254323799;    int hBLtITMcph22427661 = -813482995;    int hBLtITMcph65377566 = -286822514;    int hBLtITMcph65223879 = -448207175;    int hBLtITMcph85558538 = -464449257;    int hBLtITMcph38723412 = -469826155;    int hBLtITMcph37375422 = -285536766;    int hBLtITMcph470927 = -328174634;    int hBLtITMcph22085347 = -354957647;    int hBLtITMcph77640556 = -962861737;    int hBLtITMcph81412835 = -847552687;    int hBLtITMcph46005232 = -641533539;    int hBLtITMcph8165901 = -203184152;    int hBLtITMcph34140480 = -819052663;    int hBLtITMcph22212839 = -778525160;    int hBLtITMcph39853295 = -417300251;    int hBLtITMcph89566174 = -360170541;    int hBLtITMcph95388318 = -527551110;    int hBLtITMcph63953822 = -218738632;    int hBLtITMcph37484978 = -276508025;    int hBLtITMcph62094391 = -133815314;    int hBLtITMcph3844883 = -921020255;    int hBLtITMcph63470193 = -441399628;    int hBLtITMcph62414052 = -544417006;    int hBLtITMcph71730794 = -43823976;    int hBLtITMcph8386582 = -469554765;    int hBLtITMcph14698573 = -609956706;    int hBLtITMcph77231161 = 43165516;    int hBLtITMcph99381748 = -464602324;    int hBLtITMcph57512497 = -954301802;    int hBLtITMcph91672278 = -861758161;    int hBLtITMcph79022277 = -242363770;    int hBLtITMcph19106510 = -172389693;    int hBLtITMcph73773290 = -988692848;    int hBLtITMcph55328358 = -898199610;    int hBLtITMcph97122606 = -559100327;    int hBLtITMcph47297257 = -931604007;    int hBLtITMcph73800389 = -430035425;    int hBLtITMcph88863522 = -896018671;    int hBLtITMcph69653072 = -501133866;    int hBLtITMcph96737428 = -392304157;    int hBLtITMcph75308064 = -311713923;    int hBLtITMcph99770855 = -328136153;    int hBLtITMcph37100585 = -117419923;    int hBLtITMcph31888344 = -741096979;    int hBLtITMcph94687468 = -938649937;    int hBLtITMcph51348702 = -209144667;    int hBLtITMcph43646438 = -297566990;    int hBLtITMcph75253216 = 7132391;    int hBLtITMcph41242469 = 19210816;    int hBLtITMcph63963408 = -137304611;    int hBLtITMcph71475998 = -656041143;    int hBLtITMcph55375783 = -294083305;    int hBLtITMcph99387763 = -61036596;    int hBLtITMcph90162531 = -441709039;    int hBLtITMcph17932874 = -333303545;    int hBLtITMcph58957468 = -272083367;    int hBLtITMcph2963514 = -742405508;    int hBLtITMcph93493084 = -304383199;    int hBLtITMcph77171956 = -994894493;    int hBLtITMcph24024839 = -338413140;     hBLtITMcph28590443 = hBLtITMcph69810379;     hBLtITMcph69810379 = hBLtITMcph72330305;     hBLtITMcph72330305 = hBLtITMcph71597827;     hBLtITMcph71597827 = hBLtITMcph37873382;     hBLtITMcph37873382 = hBLtITMcph25701085;     hBLtITMcph25701085 = hBLtITMcph78211333;     hBLtITMcph78211333 = hBLtITMcph75715231;     hBLtITMcph75715231 = hBLtITMcph12423495;     hBLtITMcph12423495 = hBLtITMcph67901184;     hBLtITMcph67901184 = hBLtITMcph92485489;     hBLtITMcph92485489 = hBLtITMcph74697215;     hBLtITMcph74697215 = hBLtITMcph80477512;     hBLtITMcph80477512 = hBLtITMcph11042080;     hBLtITMcph11042080 = hBLtITMcph58536595;     hBLtITMcph58536595 = hBLtITMcph98351881;     hBLtITMcph98351881 = hBLtITMcph55979251;     hBLtITMcph55979251 = hBLtITMcph26030213;     hBLtITMcph26030213 = hBLtITMcph77106114;     hBLtITMcph77106114 = hBLtITMcph19550268;     hBLtITMcph19550268 = hBLtITMcph12674824;     hBLtITMcph12674824 = hBLtITMcph39024268;     hBLtITMcph39024268 = hBLtITMcph74422061;     hBLtITMcph74422061 = hBLtITMcph8376484;     hBLtITMcph8376484 = hBLtITMcph34112850;     hBLtITMcph34112850 = hBLtITMcph75778991;     hBLtITMcph75778991 = hBLtITMcph21856203;     hBLtITMcph21856203 = hBLtITMcph14741141;     hBLtITMcph14741141 = hBLtITMcph13301179;     hBLtITMcph13301179 = hBLtITMcph40692700;     hBLtITMcph40692700 = hBLtITMcph59514602;     hBLtITMcph59514602 = hBLtITMcph77786917;     hBLtITMcph77786917 = hBLtITMcph97466054;     hBLtITMcph97466054 = hBLtITMcph81095764;     hBLtITMcph81095764 = hBLtITMcph53529582;     hBLtITMcph53529582 = hBLtITMcph66864316;     hBLtITMcph66864316 = hBLtITMcph19329605;     hBLtITMcph19329605 = hBLtITMcph36872742;     hBLtITMcph36872742 = hBLtITMcph52256922;     hBLtITMcph52256922 = hBLtITMcph21777756;     hBLtITMcph21777756 = hBLtITMcph22427661;     hBLtITMcph22427661 = hBLtITMcph65377566;     hBLtITMcph65377566 = hBLtITMcph65223879;     hBLtITMcph65223879 = hBLtITMcph85558538;     hBLtITMcph85558538 = hBLtITMcph38723412;     hBLtITMcph38723412 = hBLtITMcph37375422;     hBLtITMcph37375422 = hBLtITMcph470927;     hBLtITMcph470927 = hBLtITMcph22085347;     hBLtITMcph22085347 = hBLtITMcph77640556;     hBLtITMcph77640556 = hBLtITMcph81412835;     hBLtITMcph81412835 = hBLtITMcph46005232;     hBLtITMcph46005232 = hBLtITMcph8165901;     hBLtITMcph8165901 = hBLtITMcph34140480;     hBLtITMcph34140480 = hBLtITMcph22212839;     hBLtITMcph22212839 = hBLtITMcph39853295;     hBLtITMcph39853295 = hBLtITMcph89566174;     hBLtITMcph89566174 = hBLtITMcph95388318;     hBLtITMcph95388318 = hBLtITMcph63953822;     hBLtITMcph63953822 = hBLtITMcph37484978;     hBLtITMcph37484978 = hBLtITMcph62094391;     hBLtITMcph62094391 = hBLtITMcph3844883;     hBLtITMcph3844883 = hBLtITMcph63470193;     hBLtITMcph63470193 = hBLtITMcph62414052;     hBLtITMcph62414052 = hBLtITMcph71730794;     hBLtITMcph71730794 = hBLtITMcph8386582;     hBLtITMcph8386582 = hBLtITMcph14698573;     hBLtITMcph14698573 = hBLtITMcph77231161;     hBLtITMcph77231161 = hBLtITMcph99381748;     hBLtITMcph99381748 = hBLtITMcph57512497;     hBLtITMcph57512497 = hBLtITMcph91672278;     hBLtITMcph91672278 = hBLtITMcph79022277;     hBLtITMcph79022277 = hBLtITMcph19106510;     hBLtITMcph19106510 = hBLtITMcph73773290;     hBLtITMcph73773290 = hBLtITMcph55328358;     hBLtITMcph55328358 = hBLtITMcph97122606;     hBLtITMcph97122606 = hBLtITMcph47297257;     hBLtITMcph47297257 = hBLtITMcph73800389;     hBLtITMcph73800389 = hBLtITMcph88863522;     hBLtITMcph88863522 = hBLtITMcph69653072;     hBLtITMcph69653072 = hBLtITMcph96737428;     hBLtITMcph96737428 = hBLtITMcph75308064;     hBLtITMcph75308064 = hBLtITMcph99770855;     hBLtITMcph99770855 = hBLtITMcph37100585;     hBLtITMcph37100585 = hBLtITMcph31888344;     hBLtITMcph31888344 = hBLtITMcph94687468;     hBLtITMcph94687468 = hBLtITMcph51348702;     hBLtITMcph51348702 = hBLtITMcph43646438;     hBLtITMcph43646438 = hBLtITMcph75253216;     hBLtITMcph75253216 = hBLtITMcph41242469;     hBLtITMcph41242469 = hBLtITMcph63963408;     hBLtITMcph63963408 = hBLtITMcph71475998;     hBLtITMcph71475998 = hBLtITMcph55375783;     hBLtITMcph55375783 = hBLtITMcph99387763;     hBLtITMcph99387763 = hBLtITMcph90162531;     hBLtITMcph90162531 = hBLtITMcph17932874;     hBLtITMcph17932874 = hBLtITMcph58957468;     hBLtITMcph58957468 = hBLtITMcph2963514;     hBLtITMcph2963514 = hBLtITMcph93493084;     hBLtITMcph93493084 = hBLtITMcph77171956;     hBLtITMcph77171956 = hBLtITMcph24024839;     hBLtITMcph24024839 = hBLtITMcph28590443;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void XylzPmyJqE89173093() {     int RyFwtlvDue50977560 = 27182897;    int RyFwtlvDue54157879 = -936562093;    int RyFwtlvDue1099585 = -529352497;    int RyFwtlvDue86604515 = -60756479;    int RyFwtlvDue36047636 = -464760872;    int RyFwtlvDue40584202 = -564722432;    int RyFwtlvDue70367072 = -443668593;    int RyFwtlvDue51349090 = -603663315;    int RyFwtlvDue9586626 = -608203491;    int RyFwtlvDue59664768 = -824624917;    int RyFwtlvDue30027349 = -823200759;    int RyFwtlvDue30600165 = -78972546;    int RyFwtlvDue47485693 = -581409077;    int RyFwtlvDue53656832 = 20514290;    int RyFwtlvDue95271871 = -772828126;    int RyFwtlvDue42607794 = -236853249;    int RyFwtlvDue5802603 = -987214133;    int RyFwtlvDue32006629 = -15959891;    int RyFwtlvDue18387745 = -287625534;    int RyFwtlvDue98066550 = -625217775;    int RyFwtlvDue13557931 = -209913829;    int RyFwtlvDue2839487 = -383008913;    int RyFwtlvDue77715384 = -536548520;    int RyFwtlvDue34876271 = -534952878;    int RyFwtlvDue69653096 = -399400047;    int RyFwtlvDue64081986 = -83782781;    int RyFwtlvDue68945623 = -540680292;    int RyFwtlvDue20652591 = -968736113;    int RyFwtlvDue20193739 = -932906784;    int RyFwtlvDue49849879 = -500479343;    int RyFwtlvDue3805408 = -593644971;    int RyFwtlvDue35328108 = -768691007;    int RyFwtlvDue78504724 = -300736263;    int RyFwtlvDue40484451 = -822216285;    int RyFwtlvDue29758947 = -661231574;    int RyFwtlvDue8557186 = -498987629;    int RyFwtlvDue12769317 = -345769888;    int RyFwtlvDue90498842 = -305170093;    int RyFwtlvDue565054 = 23429616;    int RyFwtlvDue41963470 = -390547828;    int RyFwtlvDue51185032 = -216660661;    int RyFwtlvDue53885957 = -44731205;    int RyFwtlvDue70774071 = -335737759;    int RyFwtlvDue85002657 = -461812906;    int RyFwtlvDue6706678 = -278969633;    int RyFwtlvDue45475703 = -467765861;    int RyFwtlvDue12768324 = -906584887;    int RyFwtlvDue66684021 = -111492637;    int RyFwtlvDue72100461 = -912578436;    int RyFwtlvDue78496580 = -989572946;    int RyFwtlvDue54874448 = -996609816;    int RyFwtlvDue82017157 = -634003435;    int RyFwtlvDue12454883 = -490963893;    int RyFwtlvDue82499383 = 45794031;    int RyFwtlvDue75615162 = -558004366;    int RyFwtlvDue48138074 = -589808191;    int RyFwtlvDue76442495 = -300013573;    int RyFwtlvDue66223313 = -994399619;    int RyFwtlvDue16951420 = -661356432;    int RyFwtlvDue71965650 = -280978092;    int RyFwtlvDue71638579 = 75957860;    int RyFwtlvDue49714482 = -474932481;    int RyFwtlvDue31155351 = -670756531;    int RyFwtlvDue59736746 = -7724149;    int RyFwtlvDue55859361 = -130979946;    int RyFwtlvDue94699241 = 45490248;    int RyFwtlvDue52095440 = -778236283;    int RyFwtlvDue7001242 = -759192793;    int RyFwtlvDue23897885 = -318254136;    int RyFwtlvDue86714686 = -173840498;    int RyFwtlvDue29838478 = -891083361;    int RyFwtlvDue15303761 = -582044041;    int RyFwtlvDue31441575 = 60610493;    int RyFwtlvDue76424275 = -897077706;    int RyFwtlvDue46881519 = -308557114;    int RyFwtlvDue59671973 = -65182624;    int RyFwtlvDue32065415 = 52728845;    int RyFwtlvDue92712726 = 25264385;    int RyFwtlvDue28169593 = -155983246;    int RyFwtlvDue24177393 = -931634186;    int RyFwtlvDue51313662 = -177197894;    int RyFwtlvDue2261602 = -329187655;    int RyFwtlvDue48552130 = 43842322;    int RyFwtlvDue41697159 = -943333839;    int RyFwtlvDue94975431 = -503869527;    int RyFwtlvDue21788250 = -959641537;    int RyFwtlvDue22873226 = -177727115;    int RyFwtlvDue96005341 = -246530295;    int RyFwtlvDue64869289 = -164211919;    int RyFwtlvDue81620873 = 28576616;    int RyFwtlvDue32114691 = -98974057;    int RyFwtlvDue46546003 = -351370270;    int RyFwtlvDue73547423 = -643813661;    int RyFwtlvDue28599404 = -695592293;    int RyFwtlvDue70324891 = -366505689;    int RyFwtlvDue1470551 = -741728181;    int RyFwtlvDue22730607 = -373974674;    int RyFwtlvDue11037325 = -228013611;    int RyFwtlvDue29143296 = -230832961;    int RyFwtlvDue12007437 = 27182897;     RyFwtlvDue50977560 = RyFwtlvDue54157879;     RyFwtlvDue54157879 = RyFwtlvDue1099585;     RyFwtlvDue1099585 = RyFwtlvDue86604515;     RyFwtlvDue86604515 = RyFwtlvDue36047636;     RyFwtlvDue36047636 = RyFwtlvDue40584202;     RyFwtlvDue40584202 = RyFwtlvDue70367072;     RyFwtlvDue70367072 = RyFwtlvDue51349090;     RyFwtlvDue51349090 = RyFwtlvDue9586626;     RyFwtlvDue9586626 = RyFwtlvDue59664768;     RyFwtlvDue59664768 = RyFwtlvDue30027349;     RyFwtlvDue30027349 = RyFwtlvDue30600165;     RyFwtlvDue30600165 = RyFwtlvDue47485693;     RyFwtlvDue47485693 = RyFwtlvDue53656832;     RyFwtlvDue53656832 = RyFwtlvDue95271871;     RyFwtlvDue95271871 = RyFwtlvDue42607794;     RyFwtlvDue42607794 = RyFwtlvDue5802603;     RyFwtlvDue5802603 = RyFwtlvDue32006629;     RyFwtlvDue32006629 = RyFwtlvDue18387745;     RyFwtlvDue18387745 = RyFwtlvDue98066550;     RyFwtlvDue98066550 = RyFwtlvDue13557931;     RyFwtlvDue13557931 = RyFwtlvDue2839487;     RyFwtlvDue2839487 = RyFwtlvDue77715384;     RyFwtlvDue77715384 = RyFwtlvDue34876271;     RyFwtlvDue34876271 = RyFwtlvDue69653096;     RyFwtlvDue69653096 = RyFwtlvDue64081986;     RyFwtlvDue64081986 = RyFwtlvDue68945623;     RyFwtlvDue68945623 = RyFwtlvDue20652591;     RyFwtlvDue20652591 = RyFwtlvDue20193739;     RyFwtlvDue20193739 = RyFwtlvDue49849879;     RyFwtlvDue49849879 = RyFwtlvDue3805408;     RyFwtlvDue3805408 = RyFwtlvDue35328108;     RyFwtlvDue35328108 = RyFwtlvDue78504724;     RyFwtlvDue78504724 = RyFwtlvDue40484451;     RyFwtlvDue40484451 = RyFwtlvDue29758947;     RyFwtlvDue29758947 = RyFwtlvDue8557186;     RyFwtlvDue8557186 = RyFwtlvDue12769317;     RyFwtlvDue12769317 = RyFwtlvDue90498842;     RyFwtlvDue90498842 = RyFwtlvDue565054;     RyFwtlvDue565054 = RyFwtlvDue41963470;     RyFwtlvDue41963470 = RyFwtlvDue51185032;     RyFwtlvDue51185032 = RyFwtlvDue53885957;     RyFwtlvDue53885957 = RyFwtlvDue70774071;     RyFwtlvDue70774071 = RyFwtlvDue85002657;     RyFwtlvDue85002657 = RyFwtlvDue6706678;     RyFwtlvDue6706678 = RyFwtlvDue45475703;     RyFwtlvDue45475703 = RyFwtlvDue12768324;     RyFwtlvDue12768324 = RyFwtlvDue66684021;     RyFwtlvDue66684021 = RyFwtlvDue72100461;     RyFwtlvDue72100461 = RyFwtlvDue78496580;     RyFwtlvDue78496580 = RyFwtlvDue54874448;     RyFwtlvDue54874448 = RyFwtlvDue82017157;     RyFwtlvDue82017157 = RyFwtlvDue12454883;     RyFwtlvDue12454883 = RyFwtlvDue82499383;     RyFwtlvDue82499383 = RyFwtlvDue75615162;     RyFwtlvDue75615162 = RyFwtlvDue48138074;     RyFwtlvDue48138074 = RyFwtlvDue76442495;     RyFwtlvDue76442495 = RyFwtlvDue66223313;     RyFwtlvDue66223313 = RyFwtlvDue16951420;     RyFwtlvDue16951420 = RyFwtlvDue71965650;     RyFwtlvDue71965650 = RyFwtlvDue71638579;     RyFwtlvDue71638579 = RyFwtlvDue49714482;     RyFwtlvDue49714482 = RyFwtlvDue31155351;     RyFwtlvDue31155351 = RyFwtlvDue59736746;     RyFwtlvDue59736746 = RyFwtlvDue55859361;     RyFwtlvDue55859361 = RyFwtlvDue94699241;     RyFwtlvDue94699241 = RyFwtlvDue52095440;     RyFwtlvDue52095440 = RyFwtlvDue7001242;     RyFwtlvDue7001242 = RyFwtlvDue23897885;     RyFwtlvDue23897885 = RyFwtlvDue86714686;     RyFwtlvDue86714686 = RyFwtlvDue29838478;     RyFwtlvDue29838478 = RyFwtlvDue15303761;     RyFwtlvDue15303761 = RyFwtlvDue31441575;     RyFwtlvDue31441575 = RyFwtlvDue76424275;     RyFwtlvDue76424275 = RyFwtlvDue46881519;     RyFwtlvDue46881519 = RyFwtlvDue59671973;     RyFwtlvDue59671973 = RyFwtlvDue32065415;     RyFwtlvDue32065415 = RyFwtlvDue92712726;     RyFwtlvDue92712726 = RyFwtlvDue28169593;     RyFwtlvDue28169593 = RyFwtlvDue24177393;     RyFwtlvDue24177393 = RyFwtlvDue51313662;     RyFwtlvDue51313662 = RyFwtlvDue2261602;     RyFwtlvDue2261602 = RyFwtlvDue48552130;     RyFwtlvDue48552130 = RyFwtlvDue41697159;     RyFwtlvDue41697159 = RyFwtlvDue94975431;     RyFwtlvDue94975431 = RyFwtlvDue21788250;     RyFwtlvDue21788250 = RyFwtlvDue22873226;     RyFwtlvDue22873226 = RyFwtlvDue96005341;     RyFwtlvDue96005341 = RyFwtlvDue64869289;     RyFwtlvDue64869289 = RyFwtlvDue81620873;     RyFwtlvDue81620873 = RyFwtlvDue32114691;     RyFwtlvDue32114691 = RyFwtlvDue46546003;     RyFwtlvDue46546003 = RyFwtlvDue73547423;     RyFwtlvDue73547423 = RyFwtlvDue28599404;     RyFwtlvDue28599404 = RyFwtlvDue70324891;     RyFwtlvDue70324891 = RyFwtlvDue1470551;     RyFwtlvDue1470551 = RyFwtlvDue22730607;     RyFwtlvDue22730607 = RyFwtlvDue11037325;     RyFwtlvDue11037325 = RyFwtlvDue29143296;     RyFwtlvDue29143296 = RyFwtlvDue12007437;     RyFwtlvDue12007437 = RyFwtlvDue50977560;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void ZEdocjXEdx25818068() {     int RwYGJLgVOc73364677 = -707221066;    int RwYGJLgVOc38505380 = -885105147;    int RwYGJLgVOc29868863 = -769006341;    int RwYGJLgVOc1611205 = -67164010;    int RwYGJLgVOc34221890 = 44182127;    int RwYGJLgVOc55467319 = -425330810;    int RwYGJLgVOc62522811 = -265655899;    int RwYGJLgVOc26982948 = 25740041;    int RwYGJLgVOc6749757 = -492399530;    int RwYGJLgVOc51428353 = -567366250;    int RwYGJLgVOc67569209 = -819825160;    int RwYGJLgVOc86503113 = -329717839;    int RwYGJLgVOc14493874 = -100126397;    int RwYGJLgVOc96271584 = -507194467;    int RwYGJLgVOc32007149 = -400305839;    int RwYGJLgVOc86863707 = -618520792;    int RwYGJLgVOc55625954 = -164493953;    int RwYGJLgVOc37983045 = -467702582;    int RwYGJLgVOc59669376 = -422727659;    int RwYGJLgVOc76582834 = -877852229;    int RwYGJLgVOc14441038 = -201401138;    int RwYGJLgVOc66654705 = -887775226;    int RwYGJLgVOc81008707 = -712629113;    int RwYGJLgVOc61376058 = 1054264;    int RwYGJLgVOc5193344 = -20959171;    int RwYGJLgVOc52384980 = -527677004;    int RwYGJLgVOc16035044 = -298266785;    int RwYGJLgVOc26564041 = -757190567;    int RwYGJLgVOc27086300 = -177163903;    int RwYGJLgVOc59007059 = -420775209;    int RwYGJLgVOc48096212 = -674961123;    int RwYGJLgVOc92869299 = -320762362;    int RwYGJLgVOc59543395 = -830079758;    int RwYGJLgVOc99873138 = -46343135;    int RwYGJLgVOc5988312 = -724987997;    int RwYGJLgVOc50250055 = -814383006;    int RwYGJLgVOc6209029 = -78717840;    int RwYGJLgVOc44124943 = -172795565;    int RwYGJLgVOc48873185 = -377616416;    int RwYGJLgVOc62149185 = -526771858;    int RwYGJLgVOc79942402 = -719838327;    int RwYGJLgVOc42394349 = -902639896;    int RwYGJLgVOc76324263 = -223268343;    int RwYGJLgVOc84446776 = -459176555;    int RwYGJLgVOc74689944 = -88113111;    int RwYGJLgVOc53575985 = -649994957;    int RwYGJLgVOc25065722 = -384995140;    int RwYGJLgVOc11282696 = -968027628;    int RwYGJLgVOc66560366 = -862295134;    int RwYGJLgVOc75580326 = -31593205;    int RwYGJLgVOc63743665 = -251686093;    int RwYGJLgVOc55868415 = 35177283;    int RwYGJLgVOc90769285 = -162875123;    int RwYGJLgVOc42785929 = -229886778;    int RwYGJLgVOc11377030 = -698708481;    int RwYGJLgVOc6709973 = -819445841;    int RwYGJLgVOc57496673 = -72476035;    int RwYGJLgVOc68492805 = -670060606;    int RwYGJLgVOc96417861 = 53795161;    int RwYGJLgVOc81836910 = -428140869;    int RwYGJLgVOc39432275 = -27064025;    int RwYGJLgVOc35958770 = -508465333;    int RwYGJLgVOc99896648 = -797096056;    int RwYGJLgVOc47742698 = 28375679;    int RwYGJLgVOc3332141 = -892405127;    int RwYGJLgVOc74699910 = -399062798;    int RwYGJLgVOc26959719 = -499638081;    int RwYGJLgVOc14620735 = 46216737;    int RwYGJLgVOc90283272 = -782206470;    int RwYGJLgVOc81757094 = -585922834;    int RwYGJLgVOc80654678 = -439802952;    int RwYGJLgVOc11501011 = -991698389;    int RwYGJLgVOc89109860 = 9913834;    int RwYGJLgVOc97520191 = -895955802;    int RwYGJLgVOc96640431 = -58013902;    int RwYGJLgVOc72046689 = -298761242;    int RwYGJLgVOc90330441 = -564506884;    int RwYGJLgVOc96561930 = -153452558;    int RwYGJLgVOc86686113 = -910832625;    int RwYGJLgVOc51617358 = -370964215;    int RwYGJLgVOc27319259 = -42681865;    int RwYGJLgVOc4752348 = -330239157;    int RwYGJLgVOc60003675 = -894895433;    int RwYGJLgVOc51505974 = -45570699;    int RwYGJLgVOc95263394 = -69089117;    int RwYGJLgVOc92227797 = -610138407;    int RwYGJLgVOc2100014 = -57887239;    int RwYGJLgVOc16757467 = -500192981;    int RwYGJLgVOc88496108 = -347634654;    int RwYGJLgVOc99278339 = -905542157;    int RwYGJLgVOc92753382 = -641906971;    int RwYGJLgVOc37716224 = -408657235;    int RwYGJLgVOc47707082 = -126590726;    int RwYGJLgVOc67036275 = -949475548;    int RwYGJLgVOc22716910 = -399707833;    int RwYGJLgVOc43983632 = -111372994;    int RwYGJLgVOc42497700 = -5543840;    int RwYGJLgVOc28581566 = -151644022;    int RwYGJLgVOc81114636 = -566771429;    int RwYGJLgVOc99990034 = -707221066;     RwYGJLgVOc73364677 = RwYGJLgVOc38505380;     RwYGJLgVOc38505380 = RwYGJLgVOc29868863;     RwYGJLgVOc29868863 = RwYGJLgVOc1611205;     RwYGJLgVOc1611205 = RwYGJLgVOc34221890;     RwYGJLgVOc34221890 = RwYGJLgVOc55467319;     RwYGJLgVOc55467319 = RwYGJLgVOc62522811;     RwYGJLgVOc62522811 = RwYGJLgVOc26982948;     RwYGJLgVOc26982948 = RwYGJLgVOc6749757;     RwYGJLgVOc6749757 = RwYGJLgVOc51428353;     RwYGJLgVOc51428353 = RwYGJLgVOc67569209;     RwYGJLgVOc67569209 = RwYGJLgVOc86503113;     RwYGJLgVOc86503113 = RwYGJLgVOc14493874;     RwYGJLgVOc14493874 = RwYGJLgVOc96271584;     RwYGJLgVOc96271584 = RwYGJLgVOc32007149;     RwYGJLgVOc32007149 = RwYGJLgVOc86863707;     RwYGJLgVOc86863707 = RwYGJLgVOc55625954;     RwYGJLgVOc55625954 = RwYGJLgVOc37983045;     RwYGJLgVOc37983045 = RwYGJLgVOc59669376;     RwYGJLgVOc59669376 = RwYGJLgVOc76582834;     RwYGJLgVOc76582834 = RwYGJLgVOc14441038;     RwYGJLgVOc14441038 = RwYGJLgVOc66654705;     RwYGJLgVOc66654705 = RwYGJLgVOc81008707;     RwYGJLgVOc81008707 = RwYGJLgVOc61376058;     RwYGJLgVOc61376058 = RwYGJLgVOc5193344;     RwYGJLgVOc5193344 = RwYGJLgVOc52384980;     RwYGJLgVOc52384980 = RwYGJLgVOc16035044;     RwYGJLgVOc16035044 = RwYGJLgVOc26564041;     RwYGJLgVOc26564041 = RwYGJLgVOc27086300;     RwYGJLgVOc27086300 = RwYGJLgVOc59007059;     RwYGJLgVOc59007059 = RwYGJLgVOc48096212;     RwYGJLgVOc48096212 = RwYGJLgVOc92869299;     RwYGJLgVOc92869299 = RwYGJLgVOc59543395;     RwYGJLgVOc59543395 = RwYGJLgVOc99873138;     RwYGJLgVOc99873138 = RwYGJLgVOc5988312;     RwYGJLgVOc5988312 = RwYGJLgVOc50250055;     RwYGJLgVOc50250055 = RwYGJLgVOc6209029;     RwYGJLgVOc6209029 = RwYGJLgVOc44124943;     RwYGJLgVOc44124943 = RwYGJLgVOc48873185;     RwYGJLgVOc48873185 = RwYGJLgVOc62149185;     RwYGJLgVOc62149185 = RwYGJLgVOc79942402;     RwYGJLgVOc79942402 = RwYGJLgVOc42394349;     RwYGJLgVOc42394349 = RwYGJLgVOc76324263;     RwYGJLgVOc76324263 = RwYGJLgVOc84446776;     RwYGJLgVOc84446776 = RwYGJLgVOc74689944;     RwYGJLgVOc74689944 = RwYGJLgVOc53575985;     RwYGJLgVOc53575985 = RwYGJLgVOc25065722;     RwYGJLgVOc25065722 = RwYGJLgVOc11282696;     RwYGJLgVOc11282696 = RwYGJLgVOc66560366;     RwYGJLgVOc66560366 = RwYGJLgVOc75580326;     RwYGJLgVOc75580326 = RwYGJLgVOc63743665;     RwYGJLgVOc63743665 = RwYGJLgVOc55868415;     RwYGJLgVOc55868415 = RwYGJLgVOc90769285;     RwYGJLgVOc90769285 = RwYGJLgVOc42785929;     RwYGJLgVOc42785929 = RwYGJLgVOc11377030;     RwYGJLgVOc11377030 = RwYGJLgVOc6709973;     RwYGJLgVOc6709973 = RwYGJLgVOc57496673;     RwYGJLgVOc57496673 = RwYGJLgVOc68492805;     RwYGJLgVOc68492805 = RwYGJLgVOc96417861;     RwYGJLgVOc96417861 = RwYGJLgVOc81836910;     RwYGJLgVOc81836910 = RwYGJLgVOc39432275;     RwYGJLgVOc39432275 = RwYGJLgVOc35958770;     RwYGJLgVOc35958770 = RwYGJLgVOc99896648;     RwYGJLgVOc99896648 = RwYGJLgVOc47742698;     RwYGJLgVOc47742698 = RwYGJLgVOc3332141;     RwYGJLgVOc3332141 = RwYGJLgVOc74699910;     RwYGJLgVOc74699910 = RwYGJLgVOc26959719;     RwYGJLgVOc26959719 = RwYGJLgVOc14620735;     RwYGJLgVOc14620735 = RwYGJLgVOc90283272;     RwYGJLgVOc90283272 = RwYGJLgVOc81757094;     RwYGJLgVOc81757094 = RwYGJLgVOc80654678;     RwYGJLgVOc80654678 = RwYGJLgVOc11501011;     RwYGJLgVOc11501011 = RwYGJLgVOc89109860;     RwYGJLgVOc89109860 = RwYGJLgVOc97520191;     RwYGJLgVOc97520191 = RwYGJLgVOc96640431;     RwYGJLgVOc96640431 = RwYGJLgVOc72046689;     RwYGJLgVOc72046689 = RwYGJLgVOc90330441;     RwYGJLgVOc90330441 = RwYGJLgVOc96561930;     RwYGJLgVOc96561930 = RwYGJLgVOc86686113;     RwYGJLgVOc86686113 = RwYGJLgVOc51617358;     RwYGJLgVOc51617358 = RwYGJLgVOc27319259;     RwYGJLgVOc27319259 = RwYGJLgVOc4752348;     RwYGJLgVOc4752348 = RwYGJLgVOc60003675;     RwYGJLgVOc60003675 = RwYGJLgVOc51505974;     RwYGJLgVOc51505974 = RwYGJLgVOc95263394;     RwYGJLgVOc95263394 = RwYGJLgVOc92227797;     RwYGJLgVOc92227797 = RwYGJLgVOc2100014;     RwYGJLgVOc2100014 = RwYGJLgVOc16757467;     RwYGJLgVOc16757467 = RwYGJLgVOc88496108;     RwYGJLgVOc88496108 = RwYGJLgVOc99278339;     RwYGJLgVOc99278339 = RwYGJLgVOc92753382;     RwYGJLgVOc92753382 = RwYGJLgVOc37716224;     RwYGJLgVOc37716224 = RwYGJLgVOc47707082;     RwYGJLgVOc47707082 = RwYGJLgVOc67036275;     RwYGJLgVOc67036275 = RwYGJLgVOc22716910;     RwYGJLgVOc22716910 = RwYGJLgVOc43983632;     RwYGJLgVOc43983632 = RwYGJLgVOc42497700;     RwYGJLgVOc42497700 = RwYGJLgVOc28581566;     RwYGJLgVOc28581566 = RwYGJLgVOc81114636;     RwYGJLgVOc81114636 = RwYGJLgVOc99990034;     RwYGJLgVOc99990034 = RwYGJLgVOc73364677;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void ypkgBPYWao62463042() {     int GRPUIZsvKp95751794 = -341625029;    int GRPUIZsvKp22852880 = -833648202;    int GRPUIZsvKp58638141 = 91339815;    int GRPUIZsvKp16617893 = -73571542;    int GRPUIZsvKp32396145 = -546874874;    int GRPUIZsvKp70350435 = -285939188;    int GRPUIZsvKp54678550 = -87643205;    int GRPUIZsvKp2616807 = -444856603;    int GRPUIZsvKp3912888 = -376595569;    int GRPUIZsvKp43191938 = -310107583;    int GRPUIZsvKp5111069 = -816449561;    int GRPUIZsvKp42406063 = -580463132;    int GRPUIZsvKp81502054 = -718843717;    int GRPUIZsvKp38886336 = 65096776;    int GRPUIZsvKp68742426 = -27783553;    int GRPUIZsvKp31119620 = 99811666;    int GRPUIZsvKp5449307 = -441773773;    int GRPUIZsvKp43959462 = -919445272;    int GRPUIZsvKp951007 = -557829784;    int GRPUIZsvKp55099117 = -30486682;    int GRPUIZsvKp15324145 = -192888446;    int GRPUIZsvKp30469923 = -292541539;    int GRPUIZsvKp84302030 = -888709705;    int GRPUIZsvKp87875845 = -562938593;    int GRPUIZsvKp40733590 = -742518296;    int GRPUIZsvKp40687975 = -971571228;    int GRPUIZsvKp63124464 = -55853278;    int GRPUIZsvKp32475491 = -545645020;    int GRPUIZsvKp33978861 = -521421022;    int GRPUIZsvKp68164238 = -341071076;    int GRPUIZsvKp92387017 = -756277275;    int GRPUIZsvKp50410490 = -972833717;    int GRPUIZsvKp40582066 = -259423253;    int GRPUIZsvKp59261826 = -370469985;    int GRPUIZsvKp82217676 = -788744419;    int GRPUIZsvKp91942924 = -29778382;    int GRPUIZsvKp99648740 = -911665791;    int GRPUIZsvKp97751044 = -40421037;    int GRPUIZsvKp97181316 = -778662448;    int GRPUIZsvKp82334899 = -662995887;    int GRPUIZsvKp8699774 = -123015993;    int GRPUIZsvKp30902740 = -660548587;    int GRPUIZsvKp81874455 = -110798926;    int GRPUIZsvKp83890895 = -456540204;    int GRPUIZsvKp42673211 = -997256588;    int GRPUIZsvKp61676267 = -832224052;    int GRPUIZsvKp37363119 = -963405393;    int GRPUIZsvKp55881370 = -724562619;    int GRPUIZsvKp61020271 = -812011832;    int GRPUIZsvKp72664072 = -173613464;    int GRPUIZsvKp72612881 = -606762370;    int GRPUIZsvKp29719672 = -395641999;    int GRPUIZsvKp69083689 = -934786353;    int GRPUIZsvKp3072474 = -505567586;    int GRPUIZsvKp47138898 = -839412596;    int GRPUIZsvKp65281871 = 50916510;    int GRPUIZsvKp38550850 = -944938498;    int GRPUIZsvKp70762296 = -345721593;    int GRPUIZsvKp75884302 = -331053247;    int GRPUIZsvKp91708169 = -575303646;    int GRPUIZsvKp7225972 = -130085910;    int GRPUIZsvKp22203059 = -541998186;    int GRPUIZsvKp68637946 = -923435581;    int GRPUIZsvKp35748650 = 64475506;    int GRPUIZsvKp50804920 = -553830308;    int GRPUIZsvKp54700579 = -843615844;    int GRPUIZsvKp1823997 = -221039880;    int GRPUIZsvKp22240228 = -248373733;    int GRPUIZsvKp56668660 = -146158805;    int GRPUIZsvKp76799502 = -998005171;    int GRPUIZsvKp31470879 = 11477457;    int GRPUIZsvKp7698262 = -301352737;    int GRPUIZsvKp46778145 = -40782825;    int GRPUIZsvKp18616108 = -894833898;    int GRPUIZsvKp46399344 = -907470689;    int GRPUIZsvKp84421405 = -532339859;    int GRPUIZsvKp48595468 = -81742614;    int GRPUIZsvKp411135 = -332169501;    int GRPUIZsvKp45202634 = -565682005;    int GRPUIZsvKp79057323 = -910294244;    int GRPUIZsvKp3324857 = 91834164;    int GRPUIZsvKp7243094 = -331290659;    int GRPUIZsvKp71455220 = -733633188;    int GRPUIZsvKp61314789 = -247807559;    int GRPUIZsvKp95551356 = -734308706;    int GRPUIZsvKp62667346 = -260635277;    int GRPUIZsvKp81326801 = 61952636;    int GRPUIZsvKp37509592 = -753855667;    int GRPUIZsvKp12122929 = -531057389;    int GRPUIZsvKp16935805 = -739660929;    int GRPUIZsvKp53392074 = -84839885;    int GRPUIZsvKp28886445 = -465944199;    int GRPUIZsvKp21866742 = -709367791;    int GRPUIZsvKp5473147 = -103358802;    int GRPUIZsvKp75108927 = -432909977;    int GRPUIZsvKp86496714 = -581017808;    int GRPUIZsvKp62264794 = -737113006;    int GRPUIZsvKp46125806 = -75274433;    int GRPUIZsvKp33085976 = -902709897;    int GRPUIZsvKp87972632 = -341625029;     GRPUIZsvKp95751794 = GRPUIZsvKp22852880;     GRPUIZsvKp22852880 = GRPUIZsvKp58638141;     GRPUIZsvKp58638141 = GRPUIZsvKp16617893;     GRPUIZsvKp16617893 = GRPUIZsvKp32396145;     GRPUIZsvKp32396145 = GRPUIZsvKp70350435;     GRPUIZsvKp70350435 = GRPUIZsvKp54678550;     GRPUIZsvKp54678550 = GRPUIZsvKp2616807;     GRPUIZsvKp2616807 = GRPUIZsvKp3912888;     GRPUIZsvKp3912888 = GRPUIZsvKp43191938;     GRPUIZsvKp43191938 = GRPUIZsvKp5111069;     GRPUIZsvKp5111069 = GRPUIZsvKp42406063;     GRPUIZsvKp42406063 = GRPUIZsvKp81502054;     GRPUIZsvKp81502054 = GRPUIZsvKp38886336;     GRPUIZsvKp38886336 = GRPUIZsvKp68742426;     GRPUIZsvKp68742426 = GRPUIZsvKp31119620;     GRPUIZsvKp31119620 = GRPUIZsvKp5449307;     GRPUIZsvKp5449307 = GRPUIZsvKp43959462;     GRPUIZsvKp43959462 = GRPUIZsvKp951007;     GRPUIZsvKp951007 = GRPUIZsvKp55099117;     GRPUIZsvKp55099117 = GRPUIZsvKp15324145;     GRPUIZsvKp15324145 = GRPUIZsvKp30469923;     GRPUIZsvKp30469923 = GRPUIZsvKp84302030;     GRPUIZsvKp84302030 = GRPUIZsvKp87875845;     GRPUIZsvKp87875845 = GRPUIZsvKp40733590;     GRPUIZsvKp40733590 = GRPUIZsvKp40687975;     GRPUIZsvKp40687975 = GRPUIZsvKp63124464;     GRPUIZsvKp63124464 = GRPUIZsvKp32475491;     GRPUIZsvKp32475491 = GRPUIZsvKp33978861;     GRPUIZsvKp33978861 = GRPUIZsvKp68164238;     GRPUIZsvKp68164238 = GRPUIZsvKp92387017;     GRPUIZsvKp92387017 = GRPUIZsvKp50410490;     GRPUIZsvKp50410490 = GRPUIZsvKp40582066;     GRPUIZsvKp40582066 = GRPUIZsvKp59261826;     GRPUIZsvKp59261826 = GRPUIZsvKp82217676;     GRPUIZsvKp82217676 = GRPUIZsvKp91942924;     GRPUIZsvKp91942924 = GRPUIZsvKp99648740;     GRPUIZsvKp99648740 = GRPUIZsvKp97751044;     GRPUIZsvKp97751044 = GRPUIZsvKp97181316;     GRPUIZsvKp97181316 = GRPUIZsvKp82334899;     GRPUIZsvKp82334899 = GRPUIZsvKp8699774;     GRPUIZsvKp8699774 = GRPUIZsvKp30902740;     GRPUIZsvKp30902740 = GRPUIZsvKp81874455;     GRPUIZsvKp81874455 = GRPUIZsvKp83890895;     GRPUIZsvKp83890895 = GRPUIZsvKp42673211;     GRPUIZsvKp42673211 = GRPUIZsvKp61676267;     GRPUIZsvKp61676267 = GRPUIZsvKp37363119;     GRPUIZsvKp37363119 = GRPUIZsvKp55881370;     GRPUIZsvKp55881370 = GRPUIZsvKp61020271;     GRPUIZsvKp61020271 = GRPUIZsvKp72664072;     GRPUIZsvKp72664072 = GRPUIZsvKp72612881;     GRPUIZsvKp72612881 = GRPUIZsvKp29719672;     GRPUIZsvKp29719672 = GRPUIZsvKp69083689;     GRPUIZsvKp69083689 = GRPUIZsvKp3072474;     GRPUIZsvKp3072474 = GRPUIZsvKp47138898;     GRPUIZsvKp47138898 = GRPUIZsvKp65281871;     GRPUIZsvKp65281871 = GRPUIZsvKp38550850;     GRPUIZsvKp38550850 = GRPUIZsvKp70762296;     GRPUIZsvKp70762296 = GRPUIZsvKp75884302;     GRPUIZsvKp75884302 = GRPUIZsvKp91708169;     GRPUIZsvKp91708169 = GRPUIZsvKp7225972;     GRPUIZsvKp7225972 = GRPUIZsvKp22203059;     GRPUIZsvKp22203059 = GRPUIZsvKp68637946;     GRPUIZsvKp68637946 = GRPUIZsvKp35748650;     GRPUIZsvKp35748650 = GRPUIZsvKp50804920;     GRPUIZsvKp50804920 = GRPUIZsvKp54700579;     GRPUIZsvKp54700579 = GRPUIZsvKp1823997;     GRPUIZsvKp1823997 = GRPUIZsvKp22240228;     GRPUIZsvKp22240228 = GRPUIZsvKp56668660;     GRPUIZsvKp56668660 = GRPUIZsvKp76799502;     GRPUIZsvKp76799502 = GRPUIZsvKp31470879;     GRPUIZsvKp31470879 = GRPUIZsvKp7698262;     GRPUIZsvKp7698262 = GRPUIZsvKp46778145;     GRPUIZsvKp46778145 = GRPUIZsvKp18616108;     GRPUIZsvKp18616108 = GRPUIZsvKp46399344;     GRPUIZsvKp46399344 = GRPUIZsvKp84421405;     GRPUIZsvKp84421405 = GRPUIZsvKp48595468;     GRPUIZsvKp48595468 = GRPUIZsvKp411135;     GRPUIZsvKp411135 = GRPUIZsvKp45202634;     GRPUIZsvKp45202634 = GRPUIZsvKp79057323;     GRPUIZsvKp79057323 = GRPUIZsvKp3324857;     GRPUIZsvKp3324857 = GRPUIZsvKp7243094;     GRPUIZsvKp7243094 = GRPUIZsvKp71455220;     GRPUIZsvKp71455220 = GRPUIZsvKp61314789;     GRPUIZsvKp61314789 = GRPUIZsvKp95551356;     GRPUIZsvKp95551356 = GRPUIZsvKp62667346;     GRPUIZsvKp62667346 = GRPUIZsvKp81326801;     GRPUIZsvKp81326801 = GRPUIZsvKp37509592;     GRPUIZsvKp37509592 = GRPUIZsvKp12122929;     GRPUIZsvKp12122929 = GRPUIZsvKp16935805;     GRPUIZsvKp16935805 = GRPUIZsvKp53392074;     GRPUIZsvKp53392074 = GRPUIZsvKp28886445;     GRPUIZsvKp28886445 = GRPUIZsvKp21866742;     GRPUIZsvKp21866742 = GRPUIZsvKp5473147;     GRPUIZsvKp5473147 = GRPUIZsvKp75108927;     GRPUIZsvKp75108927 = GRPUIZsvKp86496714;     GRPUIZsvKp86496714 = GRPUIZsvKp62264794;     GRPUIZsvKp62264794 = GRPUIZsvKp46125806;     GRPUIZsvKp46125806 = GRPUIZsvKp33085976;     GRPUIZsvKp33085976 = GRPUIZsvKp87972632;     GRPUIZsvKp87972632 = GRPUIZsvKp95751794;}
// Junk Finished

// Junk Code By Troll Face & Thaisen's Gen
void sANyCQIqXf79259345() {     int BgQvKadmNQ63202066 = -555407093;    int BgQvKadmNQ48762913 = -419654342;    int BgQvKadmNQ85153769 = -216711259;    int BgQvKadmNQ18373869 = -723064984;    int BgQvKadmNQ87098766 = -8593596;    int BgQvKadmNQ75626754 = -642864120;    int BgQvKadmNQ44166008 = -828403248;    int BgQvKadmNQ54689947 = -733677117;    int BgQvKadmNQ62981862 = -264737927;    int BgQvKadmNQ37083358 = -387786179;    int BgQvKadmNQ80728837 = -517284040;    int BgQvKadmNQ15683766 = -571002493;    int BgQvKadmNQ67683301 = -943678967;    int BgQvKadmNQ50710515 = -461692423;    int BgQvKadmNQ54514889 = -997821737;    int BgQvKadmNQ87465403 = -132045812;    int BgQvKadmNQ77253748 = -849726213;    int BgQvKadmNQ10613735 = -492612609;    int BgQvKadmNQ22689834 = -926137127;    int BgQvKadmNQ67277524 = -57060291;    int BgQvKadmNQ10168453 = -586588301;    int BgQvKadmNQ43325933 = -413856170;    int BgQvKadmNQ4214563 = -168020257;    int BgQvKadmNQ68336181 = -800943638;    int BgQvKadmNQ49716431 = -135832892;    int BgQvKadmNQ88386452 = -803402320;    int BgQvKadmNQ21197552 = -793204268;    int BgQvKadmNQ99972128 = -914044503;    int BgQvKadmNQ71475920 = -696777666;    int BgQvKadmNQ51215958 = -748568138;    int BgQvKadmNQ38409524 = 99073301;    int BgQvKadmNQ7635138 = -775317281;    int BgQvKadmNQ26105257 = -938879328;    int BgQvKadmNQ30569836 = -690322414;    int BgQvKadmNQ76245308 = -127668672;    int BgQvKadmNQ10251297 = -496688464;    int BgQvKadmNQ43205238 = -952521695;    int BgQvKadmNQ63555787 = -941076131;    int BgQvKadmNQ755957 = -483439502;    int BgQvKadmNQ74776685 = -201573803;    int BgQvKadmNQ44306981 = 70875703;    int BgQvKadmNQ96733362 = -875703885;    int BgQvKadmNQ67333068 = -236042308;    int BgQvKadmNQ98665985 = -935945448;    int BgQvKadmNQ56638687 = -862655044;    int BgQvKadmNQ29996046 = -706265100;    int BgQvKadmNQ89872161 = -766056895;    int BgQvKadmNQ45673275 = -494425737;    int BgQvKadmNQ69439503 = -979698204;    int BgQvKadmNQ34388021 = -544131891;    int BgQvKadmNQ46164860 = -49029670;    int BgQvKadmNQ25457483 = -258674697;    int BgQvKadmNQ72124319 = -462624081;    int BgQvKadmNQ89812550 = -843026036;    int BgQvKadmNQ69090892 = -494416847;    int BgQvKadmNQ19876134 = -41550923;    int BgQvKadmNQ44548350 = -151634085;    int BgQvKadmNQ16817589 = -415767622;    int BgQvKadmNQ68657437 = -487232093;    int BgQvKadmNQ98712314 = -205191277;    int BgQvKadmNQ54429203 = -849659852;    int BgQvKadmNQ44193879 = -914358746;    int BgQvKadmNQ83214026 = 63100548;    int BgQvKadmNQ11765905 = -516169789;    int BgQvKadmNQ98673833 = -386859480;    int BgQvKadmNQ73093700 = -741966760;    int BgQvKadmNQ89578508 = -632123166;    int BgQvKadmNQ37113465 = -153356553;    int BgQvKadmNQ74465207 = -234023751;    int BgQvKadmNQ44263592 = -401133274;    int BgQvKadmNQ44260165 = -179524117;    int BgQvKadmNQ13697962 = -908650083;    int BgQvKadmNQ9857778 = 90826893;    int BgQvKadmNQ47913148 = -624563325;    int BgQvKadmNQ22970544 = -27935994;    int BgQvKadmNQ13435091 = -710884416;    int BgQvKadmNQ75992864 = -77813863;    int BgQvKadmNQ5548577 = -232074810;    int BgQvKadmNQ11697495 = -938288594;    int BgQvKadmNQ19720385 = -429567793;    int BgQvKadmNQ98514290 = 62654575;    int BgQvKadmNQ75524277 = -198778532;    int BgQvKadmNQ30532626 = -934346299;    int BgQvKadmNQ37087900 = -52645775;    int BgQvKadmNQ5051099 = -599538469;    int BgQvKadmNQ12952042 = -642252003;    int BgQvKadmNQ35510818 = -212693201;    int BgQvKadmNQ36292706 = 4146708;    int BgQvKadmNQ61478943 = -95905567;    int BgQvKadmNQ56369174 = 13882250;    int BgQvKadmNQ65702946 = -245054379;    int BgQvKadmNQ26387649 = -436754073;    int BgQvKadmNQ94898349 = -353844039;    int BgQvKadmNQ2043642 = -178248226;    int BgQvKadmNQ20347482 = -351913951;    int BgQvKadmNQ113102 = -14765552;    int BgQvKadmNQ13519336 = -838804433;    int BgQvKadmNQ55567163 = -719872519;    int BgQvKadmNQ99992152 = -449085968;    int BgQvKadmNQ83544986 = -555407093;     BgQvKadmNQ63202066 = BgQvKadmNQ48762913;     BgQvKadmNQ48762913 = BgQvKadmNQ85153769;     BgQvKadmNQ85153769 = BgQvKadmNQ18373869;     BgQvKadmNQ18373869 = BgQvKadmNQ87098766;     BgQvKadmNQ87098766 = BgQvKadmNQ75626754;     BgQvKadmNQ75626754 = BgQvKadmNQ44166008;     BgQvKadmNQ44166008 = BgQvKadmNQ54689947;     BgQvKadmNQ54689947 = BgQvKadmNQ62981862;     BgQvKadmNQ62981862 = BgQvKadmNQ37083358;     BgQvKadmNQ37083358 = BgQvKadmNQ80728837;     BgQvKadmNQ80728837 = BgQvKadmNQ15683766;     BgQvKadmNQ15683766 = BgQvKadmNQ67683301;     BgQvKadmNQ67683301 = BgQvKadmNQ50710515;     BgQvKadmNQ50710515 = BgQvKadmNQ54514889;     BgQvKadmNQ54514889 = BgQvKadmNQ87465403;     BgQvKadmNQ87465403 = BgQvKadmNQ77253748;     BgQvKadmNQ77253748 = BgQvKadmNQ10613735;     BgQvKadmNQ10613735 = BgQvKadmNQ22689834;     BgQvKadmNQ22689834 = BgQvKadmNQ67277524;     BgQvKadmNQ67277524 = BgQvKadmNQ10168453;     BgQvKadmNQ10168453 = BgQvKadmNQ43325933;     BgQvKadmNQ43325933 = BgQvKadmNQ4214563;     BgQvKadmNQ4214563 = BgQvKadmNQ68336181;     BgQvKadmNQ68336181 = BgQvKadmNQ49716431;     BgQvKadmNQ49716431 = BgQvKadmNQ88386452;     BgQvKadmNQ88386452 = BgQvKadmNQ21197552;     BgQvKadmNQ21197552 = BgQvKadmNQ99972128;     BgQvKadmNQ99972128 = BgQvKadmNQ71475920;     BgQvKadmNQ71475920 = BgQvKadmNQ51215958;     BgQvKadmNQ51215958 = BgQvKadmNQ38409524;     BgQvKadmNQ38409524 = BgQvKadmNQ7635138;     BgQvKadmNQ7635138 = BgQvKadmNQ26105257;     BgQvKadmNQ26105257 = BgQvKadmNQ30569836;     BgQvKadmNQ30569836 = BgQvKadmNQ76245308;     BgQvKadmNQ76245308 = BgQvKadmNQ10251297;     BgQvKadmNQ10251297 = BgQvKadmNQ43205238;     BgQvKadmNQ43205238 = BgQvKadmNQ63555787;     BgQvKadmNQ63555787 = BgQvKadmNQ755957;     BgQvKadmNQ755957 = BgQvKadmNQ74776685;     BgQvKadmNQ74776685 = BgQvKadmNQ44306981;     BgQvKadmNQ44306981 = BgQvKadmNQ96733362;     BgQvKadmNQ96733362 = BgQvKadmNQ67333068;     BgQvKadmNQ67333068 = BgQvKadmNQ98665985;     BgQvKadmNQ98665985 = BgQvKadmNQ56638687;     BgQvKadmNQ56638687 = BgQvKadmNQ29996046;     BgQvKadmNQ29996046 = BgQvKadmNQ89872161;     BgQvKadmNQ89872161 = BgQvKadmNQ45673275;     BgQvKadmNQ45673275 = BgQvKadmNQ69439503;     BgQvKadmNQ69439503 = BgQvKadmNQ34388021;     BgQvKadmNQ34388021 = BgQvKadmNQ46164860;     BgQvKadmNQ46164860 = BgQvKadmNQ25457483;     BgQvKadmNQ25457483 = BgQvKadmNQ72124319;     BgQvKadmNQ72124319 = BgQvKadmNQ89812550;     BgQvKadmNQ89812550 = BgQvKadmNQ69090892;     BgQvKadmNQ69090892 = BgQvKadmNQ19876134;     BgQvKadmNQ19876134 = BgQvKadmNQ44548350;     BgQvKadmNQ44548350 = BgQvKadmNQ16817589;     BgQvKadmNQ16817589 = BgQvKadmNQ68657437;     BgQvKadmNQ68657437 = BgQvKadmNQ98712314;     BgQvKadmNQ98712314 = BgQvKadmNQ54429203;     BgQvKadmNQ54429203 = BgQvKadmNQ44193879;     BgQvKadmNQ44193879 = BgQvKadmNQ83214026;     BgQvKadmNQ83214026 = BgQvKadmNQ11765905;     BgQvKadmNQ11765905 = BgQvKadmNQ98673833;     BgQvKadmNQ98673833 = BgQvKadmNQ73093700;     BgQvKadmNQ73093700 = BgQvKadmNQ89578508;     BgQvKadmNQ89578508 = BgQvKadmNQ37113465;     BgQvKadmNQ37113465 = BgQvKadmNQ74465207;     BgQvKadmNQ74465207 = BgQvKadmNQ44263592;     BgQvKadmNQ44263592 = BgQvKadmNQ44260165;     BgQvKadmNQ44260165 = BgQvKadmNQ13697962;     BgQvKadmNQ13697962 = BgQvKadmNQ9857778;     BgQvKadmNQ9857778 = BgQvKadmNQ47913148;     BgQvKadmNQ47913148 = BgQvKadmNQ22970544;     BgQvKadmNQ22970544 = BgQvKadmNQ13435091;     BgQvKadmNQ13435091 = BgQvKadmNQ75992864;     BgQvKadmNQ75992864 = BgQvKadmNQ5548577;     BgQvKadmNQ5548577 = BgQvKadmNQ11697495;     BgQvKadmNQ11697495 = BgQvKadmNQ19720385;     BgQvKadmNQ19720385 = BgQvKadmNQ98514290;     BgQvKadmNQ98514290 = BgQvKadmNQ75524277;     BgQvKadmNQ75524277 = BgQvKadmNQ30532626;     BgQvKadmNQ30532626 = BgQvKadmNQ37087900;     BgQvKadmNQ37087900 = BgQvKadmNQ5051099;     BgQvKadmNQ5051099 = BgQvKadmNQ12952042;     BgQvKadmNQ12952042 = BgQvKadmNQ35510818;     BgQvKadmNQ35510818 = BgQvKadmNQ36292706;     BgQvKadmNQ36292706 = BgQvKadmNQ61478943;     BgQvKadmNQ61478943 = BgQvKadmNQ56369174;     BgQvKadmNQ56369174 = BgQvKadmNQ65702946;     BgQvKadmNQ65702946 = BgQvKadmNQ26387649;     BgQvKadmNQ26387649 = BgQvKadmNQ94898349;     BgQvKadmNQ94898349 = BgQvKadmNQ2043642;     BgQvKadmNQ2043642 = BgQvKadmNQ20347482;     BgQvKadmNQ20347482 = BgQvKadmNQ113102;     BgQvKadmNQ113102 = BgQvKadmNQ13519336;     BgQvKadmNQ13519336 = BgQvKadmNQ55567163;     BgQvKadmNQ55567163 = BgQvKadmNQ99992152;     BgQvKadmNQ99992152 = BgQvKadmNQ83544986;     BgQvKadmNQ83544986 = BgQvKadmNQ63202066;}
// Junk Finished
