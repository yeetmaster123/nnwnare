

extern void NetvarHook();
