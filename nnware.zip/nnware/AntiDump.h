#pragma once

namespace AntiDump
{
	void ErasePEHeader();
	void InvalidatePESize();
}