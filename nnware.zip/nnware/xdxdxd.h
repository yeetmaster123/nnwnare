


extern bool menu_open;
