#pragma once

namespace SDK
{
	class CBaseWeapon;
}



extern void ApplyStickerHooks(SDK::CBaseWeapon* item);