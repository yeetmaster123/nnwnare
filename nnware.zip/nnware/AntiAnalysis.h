#pragma once

namespace AntiAnalysis
{
	bool CheckBlacklistedProcesses();
}