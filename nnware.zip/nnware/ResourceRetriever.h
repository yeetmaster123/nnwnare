#pragma once

#include "ForumInterface.h"

class ResourceRetriever
{
public:
	ResourceRetriever();
	~ResourceRetriever();
};

